import { u as useRuntimeConfig, l as logger, f as logCloudServiceCall, c as defineEventHandler, v as validateError, x as readFormData, J as uploadMaterialAdminSchema, K as uploadMaterialSchema, z as pool, w as withTransaction, e as validateSuccess } from '../../../_/nitro.mjs';
import { randomUUID } from 'node:crypto';
import { a as fileLog } from '../../../_/fileLogger.mjs';
import { s as serverFetch } from '../../../_/request.mjs';
import { s as speechToText } from '../../../_/speechToText.mjs';
import { t as textToSpeech, e as extractAudioMeta, g as generateLearningContent, a as generateTitle } from '../../../_/audioMeta.mjs';
import { u as uploadWithKey } from '../../../_/oss.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/mysql2/promise.js';
import 'node:url';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/zod/index.js';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/jose/dist/webapi/index.js';
import 'node:fs/promises';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/@alicloud/pop-core/index.js';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/ws/wrapper.mjs';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/music-metadata/lib/index.js';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/ali-oss/lib/client.js';

const SYSTEM_PROMPT = `\u4F60\u662F\u4E00\u4E2A\u5185\u5BB9\u5BA1\u6838\u52A9\u624B\u3002\u4F60\u9700\u8981\u5BF9\u7528\u6237\u63D0\u4EA4\u7684\u82F1\u6587\u5B66\u4E60\u6750\u6599\u6587\u672C\u8FDB\u884C\u5BA1\u6838\uFF0C\u5224\u65AD\u5176\u662F\u5426\u5408\u89C4\u3002

\u5BA1\u6838\u89C4\u5219\uFF1A
1. \u5185\u5BB9\u4E0D\u5F97\u5305\u542B\u6D89\u9EC4\u3001\u8272\u60C5\u3001\u6027\u6697\u793A\u7B49\u4E0D\u826F\u4FE1\u606F
2. \u5185\u5BB9\u4E0D\u5F97\u5305\u542B\u6D89\u653F\u3001\u66B4\u529B\u3001\u6050\u6016\u4E3B\u4E49\u3001\u4EC7\u6068\u8A00\u8BBA\u7B49\u5185\u5BB9
3. \u5185\u5BB9\u5E94\u8BE5\u662F\u4E2A\u4EBA\u72EC\u767D\u3001\u8DA3\u5473\u6587\u7AE0\u3001\u65B0\u95FB\u62A5\u9053\u7B49\u975E\u5BF9\u8BDD\u7C7B\u82F1\u6587\u6587\u672C
4. \u5185\u5BB9\u5E94\u8BE5\u662F\u9002\u5408\u8BED\u8A00\u5B66\u4E60\u7684\u6B63\u5E38\u82F1\u8BED\u6750\u6599

\u8BF7\u4EE5 JSON \u683C\u5F0F\u8FD4\u56DE\u5BA1\u6838\u7ED3\u679C\uFF0C\u683C\u5F0F\u5982\u4E0B\uFF1A
{"safe": true, "reason": null}

\u5982\u679C\u4E0D\u5408\u89C4\uFF0C\u683C\u5F0F\u5982\u4E0B\uFF1A
{"safe": false, "reason": "\u5177\u4F53\u4E0D\u5408\u89C4\u539F\u56E0"}

\u53EA\u8FD4\u56DE JSON\uFF0C\u4E0D\u8981\u8FD4\u56DE\u4EFB\u4F55\u5176\u4ED6\u5185\u5BB9\u3002`;
async function moderateText(text) {
  var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j;
  const config = useRuntimeConfig();
  const ds = config.deepseek;
  if (!(ds == null ? void 0 : ds.apiKey) || !(ds == null ? void 0 : ds.baseUrl) || !(ds == null ? void 0 : ds.model)) {
    logger.error("[contentModeration] DeepSeek \u914D\u7F6E\u4E0D\u5B8C\u6574");
    return { safe: false, reason: "\u5185\u5BB9\u5BA1\u6838\u670D\u52A1\u914D\u7F6E\u7F3A\u5931" };
  }
  const url = `${ds.baseUrl.replace(/\/+$/, "")}/chat/completions`;
  let callStart = 0;
  try {
    callStart = Date.now();
    const resp = await serverFetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${ds.apiKey}`
      },
      body: JSON.stringify({
        model: ds.model,
        messages: [
          { role: "system", content: SYSTEM_PROMPT },
          { role: "user", content: text }
        ],
        temperature: 0,
        max_tokens: 200
      }),
      timeout: 15e3,
      tag: "[contentModeration]"
    });
    if (!resp.ok) {
      const body = await resp.text();
      logger.error(`[contentModeration] API \u8FD4\u56DE ${resp.status}: ${body}`);
      void logCloudServiceCall({
        service: "deepseek",
        operation: "moderateText",
        success: false,
        durationMs: Date.now() - callStart,
        errorMessage: `HTTP ${resp.status}`
      });
      return { safe: false, reason: "\u5185\u5BB9\u5BA1\u6838\u670D\u52A1\u6682\u65F6\u4E0D\u53EF\u7528" };
    }
    const data = await resp.json();
    if (data == null ? void 0 : data.usage) {
      fileLog("ai", "info", "[contentModeration] Token \u7528\u91CF", {
        promptTokens: data.usage.prompt_tokens,
        completionTokens: data.usage.completion_tokens,
        totalTokens: data.usage.total_tokens
      });
    }
    void logCloudServiceCall({
      service: "deepseek",
      operation: "moderateText",
      success: true,
      durationMs: Date.now() - callStart,
      promptTokens: (_b = (_a = data == null ? void 0 : data.usage) == null ? void 0 : _a.prompt_tokens) != null ? _b : null,
      completionTokens: (_d = (_c = data == null ? void 0 : data.usage) == null ? void 0 : _c.completion_tokens) != null ? _d : null,
      totalTokens: (_f = (_e = data == null ? void 0 : data.usage) == null ? void 0 : _e.total_tokens) != null ? _f : null
    });
    const content = (_j = (_i = (_h = (_g = data == null ? void 0 : data.choices) == null ? void 0 : _g[0]) == null ? void 0 : _h.message) == null ? void 0 : _i.content) != null ? _j : "";
    const cleaned = content.replace(/```json?\n?/g, "").trim();
    const result = JSON.parse(cleaned);
    return {
      safe: !!result.safe,
      reason: result.safe ? null : result.reason || "\u5185\u5BB9\u4E0D\u5408\u89C4"
    };
  } catch (err) {
    void logCloudServiceCall({
      service: "deepseek",
      operation: "moderateText",
      success: false,
      durationMs: callStart ? Date.now() - callStart : 0,
      errorMessage: String(err).substring(0, 500)
    });
    logger.error("[contentModeration] \u5BA1\u6838\u8C03\u7528\u5931\u8D25:", err);
    return { safe: false, reason: "\u5185\u5BB9\u5BA1\u6838\u670D\u52A1\u6682\u65F6\u4E0D\u53EF\u7528" };
  }
}

function tokenize(text) {
  if (!text.trim()) return /* @__PURE__ */ new Set();
  const normalized = text.toLowerCase().replace(/[^a-z0-9\s'-]/g, " ").split(/\s+/).filter((w) => w.length > 0);
  return new Set(normalized);
}
function compareTextSimilarity(original, recognized, threshold = 0.4) {
  const setA = tokenize(original);
  const setB = tokenize(recognized);
  if (setA.size === 0 || setB.size === 0) {
    return { score: 0, passed: false };
  }
  let intersection = 0;
  for (const word of setA) {
    if (setB.has(word)) intersection++;
  }
  const union = setA.size + setB.size - intersection;
  const score = union === 0 ? 0 : intersection / union;
  return { score, passed: score >= threshold };
}

const USER_MAX_DURATION = 180;
const ADMIN_MAX_DURATION = 600;
const USER_MAX_SIZE = 2 * 1024 * 1024;
const ADMIN_MAX_SIZE = 5 * 1024 * 1024;
function getExt(filename) {
  var _a;
  return ((_a = filename.split(".").pop()) == null ? void 0 : _a.toLowerCase()) || "mp3";
}
function extToFormat(filename) {
  const ext = getExt(filename);
  if (["wav", "aac", "opus", "mp4"].includes(ext))
    return ext;
  return "mp3";
}
async function createUploadRecord(userId, title, textContent, voice, isPublic) {
  const [res] = await pool.execute(
    `INSERT INTO material_upload_record (user_id, title, text_content, voice, is_public, status)
     VALUES (?, ?, ?, ?, ?, 'processing')`,
    [userId, title, textContent, voice, isPublic]
  );
  return res.insertId;
}
async function updateRecordFailed(recordId, error) {
  await pool.execute(
    `UPDATE material_upload_record SET status = 'failed', error_message = ? WHERE id = ?`,
    [error.substring(0, 500), recordId]
  );
}
async function updateRecordSuccess(recordId, segmentId) {
  await pool.execute(
    `UPDATE material_upload_record SET status = 'success', segment_id = ? WHERE id = ?`,
    [segmentId, recordId]
  );
}
const upload_post = defineEventHandler(
  async (event) => {
    var _a, _b;
    const user = event.context.user;
    if (!user) return validateError("\u672A\u767B\u5F55", 401);
    const formData = await readFormData(event);
    const textContent = formData.get("textContent");
    const voice = formData.get("voice") || "en-US-AriaNeural";
    const isPublic = Number(formData.get("isPublic"));
    const unitIdRaw = formData.get("unitId");
    const audioFile = formData.get("audio");
    const isAdmin = user.role === 1;
    const finalUnitId = isAdmin && unitIdRaw ? Number(unitIdRaw) : 0;
    const schema = isAdmin ? uploadMaterialAdminSchema : uploadMaterialSchema;
    const parseInput = { textContent, isPublic, voice };
    if (isAdmin) parseInput.unitId = finalUnitId;
    const parsed = schema.safeParse(parseInput);
    if (!parsed.success) {
      return validateError(((_a = parsed.error.issues[0]) == null ? void 0 : _a.message) || "\u53C2\u6570\u6821\u9A8C\u5931\u8D25");
    }
    if (!textContent) return validateError("\u6750\u6599\u6587\u672C\u4E0D\u80FD\u4E3A\u7A7A");
    const fallbackTitle = textContent.length > 50 ? textContent.slice(0, 50) + "..." : textContent;
    const recordId = await createUploadRecord(user.id, fallbackTitle, textContent, voice, isPublic);
    logger.info(
      `[material upload] \u5F00\u59CB\u5904\u7406 user=${user.id} record=${recordId} ${audioFile ? "\u7528\u6237\u4E0A\u4F20\u97F3\u9891" : "TTS\u5408\u6210"} \u6587\u672C${textContent.length}\u5B57`
    );
    const mod1 = await moderateText(textContent);
    if (!mod1.safe) {
      await updateRecordFailed(recordId, `\u6750\u6599\u5185\u5BB9\u4E0D\u5408\u89C4: ${mod1.reason}`);
      return validateError(`\u6750\u6599\u5185\u5BB9\u4E0D\u5408\u89C4: ${mod1.reason}`);
    }
    let audioBuffer;
    let mediaType;
    if (audioFile && audioFile instanceof File && audioFile.size > 0) {
      audioBuffer = Buffer.from(await audioFile.arrayBuffer());
      mediaType = "user_material";
      const sttResult = await speechToText(audioBuffer, extToFormat(audioFile.name));
      if (!sttResult.success) {
        await updateRecordFailed(recordId, `\u97F3\u9891\u8BC6\u522B\u5931\u8D25: ${sttResult.error}`);
        return validateError(`\u97F3\u9891\u8BC6\u522B\u5931\u8D25: ${sttResult.error}`);
      }
      const recognizedText = (_b = sttResult.text) != null ? _b : "";
      if (recognizedText.trim()) {
        const mod2 = await moderateText(recognizedText);
        if (!mod2.safe) {
          await updateRecordFailed(recordId, `\u97F3\u9891\u5185\u5BB9\u4E0D\u5408\u89C4: ${mod2.reason}`);
          return validateError(`\u97F3\u9891\u5185\u5BB9\u4E0D\u5408\u89C4: ${mod2.reason}`);
        }
        const sim = compareTextSimilarity(textContent, recognizedText);
        if (!sim.passed) {
          await updateRecordFailed(
            recordId,
            `\u97F3\u9891\u5185\u5BB9\u4E0E\u6750\u6599\u6587\u672C\u4E0D\u5339\u914D\uFF08\u76F8\u4F3C\u5EA6 ${(sim.score * 100).toFixed(0)}%\uFF09`
          );
          return validateError(
            `\u97F3\u9891\u5185\u5BB9\u4E0E\u6750\u6599\u6587\u672C\u4E0D\u5339\u914D\uFF08\u76F8\u4F3C\u5EA6 ${(sim.score * 100).toFixed(0)}%\uFF09`
          );
        }
      }
    } else {
      const ttsResult = await textToSpeech(textContent, voice);
      if (!ttsResult.success || !ttsResult.audio) {
        await updateRecordFailed(recordId, "\u97F3\u9891\u751F\u6210\u5931\u8D25");
        return validateError("\u97F3\u9891\u751F\u6210\u5931\u8D25\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5");
      }
      audioBuffer = ttsResult.audio;
      mediaType = "tts";
    }
    const ext = audioFile && audioFile instanceof File ? getExt(audioFile.name) : "mp3";
    const ossKey = `audio/material/${randomUUID()}.${ext}`;
    const bucket = useRuntimeConfig().oss.bucket;
    try {
      await uploadWithKey(audioBuffer, ossKey);
    } catch (err) {
      logger.error("[material upload] OSS \u4E0A\u4F20\u5931\u8D25:", err);
      await updateRecordFailed(recordId, "\u6587\u4EF6\u4E0A\u4F20\u5931\u8D25");
      return validateError("\u6587\u4EF6\u4E0A\u4F20\u5931\u8D25\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5", 500);
    }
    const originalName = audioFile && audioFile instanceof File ? audioFile.name : "tts.mp3";
    const [mediaRes] = await pool.execute(
      `INSERT INTO media (uploader_id, type, storage_type, bucket, object_key, original_name, mime_type, size_bytes, status)
     VALUES (?, ?, 'oss', ?, ?, ?, ?, ?, 1)`,
      [user.id, mediaType, bucket, ossKey, originalName, `audio/${ext}`, audioBuffer.length]
    );
    const segmentMediaId = mediaRes.insertId;
    const meta = await extractAudioMeta(audioBuffer);
    if (!meta) {
      await pool.execute("UPDATE media SET status = 0 WHERE id = ?", [segmentMediaId]);
      await updateRecordFailed(recordId, "\u65E0\u6CD5\u89E3\u6790\u97F3\u9891\u4FE1\u606F");
      return validateError("\u65E0\u6CD5\u89E3\u6790\u97F3\u9891\u4FE1\u606F");
    }
    const maxDuration = isAdmin ? ADMIN_MAX_DURATION : USER_MAX_DURATION;
    const maxSize = isAdmin ? ADMIN_MAX_SIZE : USER_MAX_SIZE;
    if (meta.duration > maxDuration) {
      await pool.execute("UPDATE media SET status = 0 WHERE id = ?", [segmentMediaId]);
      await updateRecordFailed(recordId, `\u97F3\u9891\u65F6\u957F\u8D85\u9650: ${meta.duration.toFixed(1)}s`);
      return validateError(`\u97F3\u9891\u65F6\u957F ${meta.duration.toFixed(1)}s \u8D85\u8FC7\u9650\u5236\uFF08${maxDuration}s\uFF09`);
    }
    if (meta.size > maxSize) {
      await pool.execute("UPDATE media SET status = 0 WHERE id = ?", [segmentMediaId]);
      await updateRecordFailed(recordId, `\u97F3\u9891\u5927\u5C0F\u8D85\u9650: ${(meta.size / 1024 / 1024).toFixed(1)}MB`);
      return validateError(`\u97F3\u9891\u5927\u5C0F ${(meta.size / 1024 / 1024).toFixed(1)}MB \u8D85\u8FC7\u9650\u5236`);
    }
    await pool.execute("UPDATE media SET duration = ? WHERE id = ?", [
      meta.duration,
      segmentMediaId
    ]);
    const aiResult = await generateLearningContent(textContent);
    if (!aiResult.success || !aiResult.vocabulary || !aiResult.questions) {
      await pool.execute("UPDATE media SET status = 0 WHERE id = ?", [segmentMediaId]);
      await updateRecordFailed(recordId, "AI \u5185\u5BB9\u751F\u6210\u5931\u8D25");
      return validateError("AI \u5185\u5BB9\u751F\u6210\u5931\u8D25\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5");
    }
    const vocabulary = aiResult.vocabulary;
    const questions = aiResult.questions;
    const titleResult = await generateTitle(textContent);
    let title;
    if (titleResult.success && titleResult.title) {
      title = titleResult.title;
    } else {
      logger.warn("[material upload] \u6807\u9898\u751F\u6210\u5931\u8D25\uFF0C\u964D\u7EA7\u4E3A\u6587\u672C\u622A\u53D6:", titleResult.error);
      title = textContent.length > 50 ? textContent.slice(0, 50) + "..." : textContent;
    }
    let segmentId;
    try {
      segmentId = await withTransaction(async (conn) => {
        var _a2, _b2, _c, _d, _e;
        const [segRes] = await conn.execute(
          `INSERT INTO segment (unit_id, title, textContent, translation, questions, is_public, media_id, sort_order)
         VALUES (?, ?, ?, ?, ?, ?, ?, 0)`,
          [
            finalUnitId,
            title,
            textContent,
            (_a2 = aiResult.translation) != null ? _a2 : "",
            JSON.stringify(questions),
            isPublic,
            segmentMediaId
          ]
        );
        const newSegmentId = segRes.insertId;
        let vocabIndex = 0;
        for (const vocab of vocabulary) {
          let vocabMediaId = null;
          const vocabTts = await textToSpeech(vocab.word);
          if (vocabTts.success && vocabTts.audio) {
            const vocabKey = `audio/vocab/${randomUUID()}.mp3`;
            try {
              await uploadWithKey(vocabTts.audio, vocabKey);
            } catch {
            }
            const [vmRes] = await conn.execute(
              `INSERT INTO media (uploader_id, type, storage_type, bucket, object_key, mime_type, size_bytes, duration, status)
             VALUES (NULL, 'vocab_audio', 'oss', ?, ?, 'audio/mpeg', ?, 0, 1)`,
              [bucket, vocabKey, vocabTts.audio.length]
            );
            vocabMediaId = vmRes.insertId;
          }
          await conn.execute(
            `INSERT INTO vocabulary (segment_id, word, forms, phonetic, meaning, exampleSentence, exampleTranslation, media_id, sort_order)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [
              newSegmentId,
              vocab.word,
              (_b2 = vocab.forms) != null ? _b2 : null,
              (_c = vocab.phonetic) != null ? _c : null,
              vocab.meaning,
              (_d = vocab.exampleSentence) != null ? _d : null,
              (_e = vocab.exampleTranslation) != null ? _e : null,
              vocabMediaId,
              vocabIndex++
            ]
          );
        }
        return newSegmentId;
      });
    } catch (err) {
      logger.error("[material upload] \u4E8B\u52A1\u5931\u8D25:", err);
      await pool.execute("UPDATE media SET status = 0 WHERE id = ?", [segmentMediaId]);
      await updateRecordFailed(recordId, "\u5165\u5E93\u5931\u8D25");
      return validateError("\u5165\u5E93\u5931\u8D25\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5", 500);
    }
    await updateRecordSuccess(recordId, segmentId);
    if (title !== fallbackTitle) {
      await pool.execute("UPDATE material_upload_record SET title = ? WHERE id = ?", [
        title,
        recordId
      ]);
    }
    logger.info(`[material upload] \u4E0A\u4F20\u6210\u529F record=${recordId} segment=${segmentId} title=${title}`);
    return validateSuccess({ segmentId, title }, "\u6750\u6599\u4E0A\u4F20\u6210\u529F");
  }
);

export { upload_post as default };
//# sourceMappingURL=upload.post.mjs.map
