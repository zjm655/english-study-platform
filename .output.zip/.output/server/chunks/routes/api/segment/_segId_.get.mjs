import { c as defineEventHandler, i as getRouterParam, v as validateError, q as query, e as validateSuccess } from '../../../_/nitro.mjs';
import { M as MATERIAL_EXPIRE, s as signUrl, W as WORD_EXPIRE } from '../../../_/oss.mjs';
import { m as mapProgressRow, D as DEFAULT_PROGRESS } from '../../../_/progress.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/mysql2/promise.js';
import 'node:url';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/zod/index.js';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/jose/dist/webapi/index.js';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/ali-oss/lib/client.js';
import '../../../_/fileLogger.mjs';
import 'node:fs/promises';

async function signFromMedia(objectKey, expires = MATERIAL_EXPIRE) {
  if (!objectKey) return null;
  return signUrl(objectKey, expires);
}
const _segId__get = defineEventHandler(async (event) => {
  var _a;
  const userId = event.context.user.id;
  const segId = Number(getRouterParam(event, "segId"));
  if (!segId || isNaN(segId)) {
    return validateError("\u65E0\u6548\u7684\u7247\u6BB5ID");
  }
  const segments = await query(
    `SELECT s.*, m.object_key AS seg_media_key, m.duration AS seg_media_duration
     FROM segment s
     LEFT JOIN media m ON s.media_id = m.id
     WHERE s.id = ? AND s.deleted_at IS NULL`,
    [segId]
  );
  const segment = segments[0];
  if (!segment) {
    return validateError("\u7247\u6BB5\u4E0D\u5B58\u5728", 404);
  }
  const units = await query("SELECT id, title FROM unit WHERE id = ?", [segment.unit_id]);
  const unit = units[0];
  if (!unit) {
    return validateError("\u5355\u5143\u4E0D\u5B58\u5728", 404);
  }
  const vocabRows = await query(
    `SELECT v.*, m.object_key AS vocab_media_key, m.duration AS vocab_media_duration
     FROM vocabulary v
     LEFT JOIN media m ON v.media_id = m.id
     WHERE v.segment_id = ?
     ORDER BY v.sort_order`,
    [segId]
  );
  const vocabulary = await Promise.all(
    vocabRows.map(async (v) => ({
      id: v.id,
      word: v.word,
      forms: v.forms,
      phonetic: v.phonetic,
      meaning: v.meaning,
      audioUrl: await signFromMedia(v.vocab_media_key, WORD_EXPIRE),
      duration: v.vocab_media_duration ? Number(v.vocab_media_duration) : null
    }))
  );
  const progressRows = await query(
    "SELECT * FROM user_progress WHERE user_id = ? AND segment_id = ?",
    [userId, segId]
  );
  const progressRow = progressRows[0];
  const progress = progressRow ? mapProgressRow(progressRow) : { ...DEFAULT_PROGRESS };
  const progressConverted = {
    ...progress,
    updatedAt: progress.updatedAt instanceof Date ? progress.updatedAt.toISOString() : (_a = progress.updatedAt) != null ? _a : void 0
  };
  const result = {
    id: segment.id,
    title: segment.title,
    audioUrl: await signFromMedia(segment.seg_media_key, MATERIAL_EXPIRE),
    duration: segment.seg_media_duration ? Number(segment.seg_media_duration) : null,
    textContent: segment.textContent,
    translation: segment.translation,
    questions: segment.questions,
    unitId: unit.id,
    unitTitle: unit.title,
    vocabulary,
    progress: progressConverted
  };
  return validateSuccess(result, "\u83B7\u53D6\u6210\u529F");
});

export { _segId__get as default };
//# sourceMappingURL=_segId_.get.mjs.map
