import { c as defineEventHandler, g as getQuery, q as query, e as validateSuccess } from '../../_/nitro.mjs';
import { s as signUrl, R as RECORDING_EXPIRE } from '../../_/oss.mjs';
import { r as rowToRecording } from '../../_/recording.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/mysql2/promise.js';
import 'node:url';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/zod/index.js';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/jose/dist/webapi/index.js';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/ali-oss/lib/client.js';
import '../../_/fileLogger.mjs';
import 'node:fs/promises';

const index_get = defineEventHandler(async (event) => {
  var _a, _b;
  const userId = event.context.user.id;
  const queryParams = getQuery(event);
  const segmentId = Number(queryParams.segmentId);
  const phase = Number(queryParams.phase);
  const page = Math.max(1, Number(queryParams.page) || 1);
  const size = Math.max(1, Math.min(50, Number(queryParams.size) || 3));
  const offset = (page - 1) * size;
  const countRows = await query(
    `SELECT COUNT(*) as total FROM recording r
     WHERE r.user_id = ? AND r.segment_id = ? AND r.phase = ? AND r.deleted_at IS NULL`,
    [userId, segmentId, phase]
  );
  const total = (_b = (_a = countRows[0]) == null ? void 0 : _a.total) != null ? _b : 0;
  const rows = await query(
    `SELECT r.*, m.object_key AS rec_media_key
     FROM recording r
     LEFT JOIN media m ON r.media_id = m.id
     WHERE r.user_id = ? AND r.segment_id = ? AND r.phase = ? AND r.deleted_at IS NULL
     ORDER BY r.createdAt DESC
     LIMIT ? OFFSET ?`,
    [userId, segmentId, phase, size, offset]
  );
  const results = await Promise.all(
    rows.map(async (row) => {
      const signedPath = row.rec_media_key ? await signUrl(row.rec_media_key, RECORDING_EXPIRE) : null;
      return rowToRecording(row, signedPath);
    })
  );
  const items = results.filter((r) => r !== null);
  return validateSuccess({ items, total, page, size }, "\u83B7\u53D6\u6210\u529F");
});

export { index_get as default };
//# sourceMappingURL=index.get.mjs.map
