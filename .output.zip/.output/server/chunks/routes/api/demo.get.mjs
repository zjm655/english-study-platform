import { c as defineEventHandler } from '../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/mysql2/promise.js';
import 'node:url';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/zod/index.js';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/jose/dist/webapi/index.js';

const demo_get = defineEventHandler(() => {
  return {
    code: 200,
    message: "\u6210\u529F\u83B7\u53D6\uFF01",
    data: {
      title: "\u8FD9\u91CC\u4EC0\u4E48\u4E5F\u6CA1\u6709\uFF01"
    }
  };
});

export { demo_get as default };
//# sourceMappingURL=demo.get.mjs.map
