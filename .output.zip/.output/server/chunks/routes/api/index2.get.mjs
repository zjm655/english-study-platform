import { c as defineEventHandler, g as getQuery, q as query, e as validateSuccess } from '../../_/nitro.mjs';
import { M as MATERIAL_EXPIRE, s as signUrl } from '../../_/oss.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/mysql2/promise.js';
import 'node:url';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/zod/index.js';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/jose/dist/webapi/index.js';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/ali-oss/lib/client.js';
import '../../_/fileLogger.mjs';
import 'node:fs/promises';

const index_get = defineEventHandler(async (event) => {
  const userId = event.context.user.id;
  const rawLevel = getQuery(event).level;
  const hasLevel = rawLevel !== void 0 && rawLevel !== "";
  const level = Number(rawLevel);
  const validLevel = hasLevel && !isNaN(level);
  const units = validLevel ? await query(
    `SELECT u.*, m.object_key AS unit_media_key
         FROM unit u
         LEFT JOIN media m ON u.cover_media_id = m.id
         WHERE u.level = ?
         ORDER BY u.sort_order`,
    [level]
  ) : await query(
    `SELECT u.*, m.object_key AS unit_media_key
         FROM unit u
         LEFT JOIN media m ON u.cover_media_id = m.id
         ORDER BY u.level, u.sort_order`
  );
  const progressRows = validLevel ? await query(
    `SELECT DISTINCT up.segment_id, s.unit_id
         FROM user_progress up
         JOIN segment s ON up.segment_id = s.id AND s.deleted_at IS NULL
         WHERE up.user_id = ? AND s.unit_id IN (SELECT id FROM unit WHERE level = ?)`,
    [userId, level]
  ) : await query(
    `SELECT DISTINCT up.segment_id, s.unit_id
         FROM user_progress up
         JOIN segment s ON up.segment_id = s.id AND s.deleted_at IS NULL
         WHERE up.user_id = ?`,
    [userId]
  );
  const progressMap = /* @__PURE__ */ new Map();
  for (const row of progressRows) {
    if (!progressMap.has(row.unit_id)) progressMap.set(row.unit_id, /* @__PURE__ */ new Set());
    progressMap.get(row.unit_id).add(row.segment_id);
  }
  const segmentCounts = validLevel ? await query(
    `SELECT unit_id, COUNT(*) as count FROM segment WHERE unit_id IN (SELECT id FROM unit WHERE level = ?) AND deleted_at IS NULL GROUP BY unit_id`,
    [level]
  ) : await query(
    `SELECT unit_id, COUNT(*) as count FROM segment WHERE deleted_at IS NULL GROUP BY unit_id`
  );
  const countMap = new Map(segmentCounts.map((r) => [r.unit_id, r.count]));
  const result = await Promise.all(
    units.map(async (unit) => {
      var _a, _b, _c;
      const totalSegments = (_a = countMap.get(unit.id)) != null ? _a : 0;
      const completedSegments = (_c = (_b = progressMap.get(unit.id)) == null ? void 0 : _b.size) != null ? _c : 0;
      const progress = {
        totalSegments,
        completedSegments,
        percent: totalSegments > 0 ? Math.round(completedSegments / totalSegments * 100) : 0
      };
      return {
        id: unit.id,
        title: unit.title,
        description: unit.description,
        level: unit.level,
        sortOrder: unit.sort_order,
        audioUrl: await signFromMedia(unit.unit_media_key, MATERIAL_EXPIRE),
        progress
      };
    })
  );
  return validateSuccess(result, "\u83B7\u53D6\u6210\u529F");
});
async function signFromMedia(objectKey, expires = MATERIAL_EXPIRE) {
  if (objectKey) return signUrl(objectKey, expires);
  return null;
}

export { index_get as default };
//# sourceMappingURL=index2.get.mjs.map
