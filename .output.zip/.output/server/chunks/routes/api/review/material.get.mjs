import { c as defineEventHandler, v as validateError, I as reviewQuerySchema, g as getQuery, q as query, e as validateSuccess } from '../../../_/nitro.mjs';
import { s as signUrl, M as MATERIAL_EXPIRE } from '../../../_/oss.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/mysql2/promise.js';
import 'node:url';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/zod/index.js';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/jose/dist/webapi/index.js';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/ali-oss/lib/client.js';
import '../../../_/fileLogger.mjs';
import 'node:fs/promises';

function parseQuestions(raw) {
  if (raw === null) return null;
  if (Array.isArray(raw)) return raw;
  try {
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : null;
  } catch {
    return null;
  }
}
function rowsToReviewMaterial(rows, signedAudioUrls) {
  return rows.map((row, i) => {
    var _a;
    return {
      id: row.id,
      title: row.title,
      audioUrl: (_a = signedAudioUrls[i]) != null ? _a : null,
      questions: parseQuestions(row.questions),
      duration: row.seg_media_duration ? Number(row.seg_media_duration) : null
    };
  });
}
const material_get = defineEventHandler(async (event) => {
  var _a, _b, _c, _d;
  const userId = (_a = event.context.user) == null ? void 0 : _a.id;
  if (!userId) {
    return validateError("\u672A\u767B\u5F55", 401);
  }
  const result = reviewQuerySchema.safeParse(getQuery(event));
  if (!result.success) {
    return validateError(((_b = result.error.issues[0]) == null ? void 0 : _b.message) || "\u53C2\u6570\u6821\u9A8C\u5931\u8D25", 400);
  }
  const { limit = 5, offset = 0, keyword } = result.data;
  const keywordPattern = keyword ? `%${keyword}%` : null;
  const keywordClause = keywordPattern ? "AND s.title LIKE ?" : "";
  const keywordParams = keywordPattern ? [keywordPattern] : [];
  const countResult = await query(
    `SELECT COUNT(*) AS total
     FROM user_progress up
     JOIN segment s ON up.segment_id = s.id AND s.deleted_at IS NULL
     WHERE up.user_id = ? AND up.phase2_done = 1 AND up.deleted_at IS NULL
     ${keywordClause}`,
    [userId, ...keywordParams]
  );
  const total = (_d = (_c = countResult[0]) == null ? void 0 : _c.total) != null ? _d : 0;
  const rows = await query(
    `SELECT s.id, s.title, s.questions,
            m.object_key AS seg_media_key, m.duration AS seg_media_duration
     FROM user_progress up
     JOIN segment s ON up.segment_id = s.id AND s.deleted_at IS NULL
     LEFT JOIN media m ON s.media_id = m.id
     WHERE up.user_id = ? AND up.phase2_done = 1 AND up.deleted_at IS NULL
     ${keywordClause}
     ORDER BY up.updatedAt DESC
     LIMIT ? OFFSET ?`,
    [userId, ...keywordParams, limit, offset]
  );
  const signedAudioUrls = await Promise.all(
    rows.map((row) => row.seg_media_key ? signUrl(row.seg_media_key, MATERIAL_EXPIRE) : null)
  );
  const items = rowsToReviewMaterial(rows, signedAudioUrls);
  return validateSuccess({ items, total }, "\u83B7\u53D6\u6750\u6599\u590D\u4E60\u5217\u8868\u6210\u529F");
});

export { material_get as default, rowsToReviewMaterial };
//# sourceMappingURL=material.get.mjs.map
