import { c as defineEventHandler, v as validateError, I as reviewQuerySchema, g as getQuery, q as query, e as validateSuccess } from '../../../_/nitro.mjs';
import { s as signUrl, W as WORD_EXPIRE } from '../../../_/oss.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/mysql2/promise.js';
import 'node:url';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/zod/index.js';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/jose/dist/webapi/index.js';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/ali-oss/lib/client.js';
import '../../../_/fileLogger.mjs';
import 'node:fs/promises';

function rowsToReviewVocab(rows, signedAudioUrls) {
  return rows.map((row, i) => {
    var _a;
    return {
      id: row.id,
      segmentId: row.segment_id,
      word: row.word,
      phonetic: row.phonetic,
      meaning: row.meaning,
      forms: row.forms,
      exampleSentence: row.exampleSentence,
      exampleTranslation: row.exampleTranslation,
      audioUrl: (_a = signedAudioUrls[i]) != null ? _a : null
    };
  });
}
const vocab_get = defineEventHandler(async (event) => {
  var _a, _b, _c, _d;
  const userId = (_a = event.context.user) == null ? void 0 : _a.id;
  if (!userId) {
    return validateError("\u672A\u767B\u5F55", 401);
  }
  const result = reviewQuerySchema.safeParse(getQuery(event));
  if (!result.success) {
    return validateError(((_b = result.error.issues[0]) == null ? void 0 : _b.message) || "\u53C2\u6570\u6821\u9A8C\u5931\u8D25", 400);
  }
  const { limit = 10, offset = 0, keyword } = result.data;
  const keywordPattern = keyword ? `%${keyword}%` : null;
  const progressRows = await query(
    `SELECT up.segment_id FROM user_progress up
     JOIN segment s ON up.segment_id = s.id AND s.deleted_at IS NULL
     WHERE up.user_id = ? AND up.phase2_done = 1 AND up.deleted_at IS NULL
     ORDER BY up.updatedAt DESC`,
    [userId]
  );
  if (progressRows.length === 0) {
    return validateSuccess({ items: [], total: 0 }, "\u83B7\u53D6\u6210\u529F");
  }
  const segmentIds = progressRows.map((r) => r.segment_id);
  const placeholders = segmentIds.map(() => "?").join(", ");
  const keywordClause = keywordPattern ? "AND (v.word LIKE ? OR v.meaning LIKE ?)" : "";
  const keywordParams = keywordPattern ? [keywordPattern, keywordPattern] : [];
  const countResult = await query(
    `SELECT COUNT(*) AS total
     FROM vocabulary v
     WHERE v.segment_id IN (${placeholders})
     ${keywordClause}`,
    [...segmentIds, ...keywordParams]
  );
  const total = (_d = (_c = countResult[0]) == null ? void 0 : _c.total) != null ? _d : 0;
  const vocabRows = await query(
    `SELECT v.*, m.object_key AS vocab_media_key
     FROM vocabulary v
     LEFT JOIN media m ON v.media_id = m.id
     WHERE v.segment_id IN (${placeholders})
     ${keywordClause}
     ORDER BY v.segment_id, v.sort_order
     LIMIT ? OFFSET ?`,
    [...segmentIds, ...keywordParams, limit, offset]
  );
  const signedAudioUrls = await Promise.all(
    vocabRows.map(
      (row) => row.vocab_media_key ? signUrl(row.vocab_media_key, WORD_EXPIRE) : null
    )
  );
  return validateSuccess(
    { items: rowsToReviewVocab(vocabRows, signedAudioUrls), total },
    "\u83B7\u53D6\u6210\u529F"
  );
});

export { vocab_get as default, rowsToReviewVocab };
//# sourceMappingURL=vocab.get.mjs.map
