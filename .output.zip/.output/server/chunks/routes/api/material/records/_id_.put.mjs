import { c as defineEventHandler, v as validateError, i as getRouterParam, n as readBody, G as updateMaterialRecordSchema, q as query, z as pool, e as validateSuccess } from '../../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/mysql2/promise.js';
import 'node:url';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/zod/index.js';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/jose/dist/webapi/index.js';

const _id__put = defineEventHandler(async (event) => {
  var _a, _b, _c;
  const user = event.context.user;
  if (!user) return validateError("\u672A\u767B\u5F55", 401);
  const id = Number(getRouterParam(event, "id"));
  if (isNaN(id) || id <= 0) return validateError("\u65E0\u6548\u7684\u8BB0\u5F55ID");
  const body = await readBody(event);
  const parsed = updateMaterialRecordSchema.safeParse(body);
  if (!parsed.success) {
    return validateError(((_a = parsed.error.issues[0]) == null ? void 0 : _a.message) || "\u53C2\u6570\u6821\u9A8C\u5931\u8D25");
  }
  const { isPublic } = parsed.data;
  const rows = await query(
    "SELECT segment_id FROM material_upload_record WHERE id = ? AND user_id = ?",
    [id, user.id]
  );
  if (!rows.length) return validateError("\u8BB0\u5F55\u4E0D\u5B58\u5728\u6216\u65E0\u6743\u9650", 404);
  const segmentId = (_c = (_b = rows[0]) == null ? void 0 : _b.segment_id) != null ? _c : null;
  await pool.execute("UPDATE material_upload_record SET is_public = ? WHERE id = ?", [isPublic, id]);
  if (segmentId) {
    await pool.execute("UPDATE segment SET is_public = ? WHERE id = ?", [isPublic, segmentId]);
  }
  return validateSuccess(null, "\u66F4\u65B0\u6210\u529F");
});

export { _id__put as default };
//# sourceMappingURL=_id_.put.mjs.map
