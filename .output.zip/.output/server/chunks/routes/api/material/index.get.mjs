import { c as defineEventHandler, v as validateError, g as getQuery, q as query, e as validateSuccess } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/mysql2/promise.js';
import 'node:url';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/zod/index.js';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/jose/dist/webapi/index.js';

const index_get = defineEventHandler(
  async (event) => {
    const user = event.context.user;
    if (!user) return validateError("\u672A\u767B\u5F55", 401);
    const q = getQuery(event);
    const limit = Math.min(Number(q.limit) || 20, 100);
    const offset = Math.max(Number(q.offset) || 0, 0);
    const rows = await query(
      `SELECT id, title, status, error_message, segment_id, is_public, createdAt
     FROM material_upload_record
     WHERE user_id = ?
     ORDER BY createdAt DESC
     LIMIT ? OFFSET ?`,
      [user.id, limit, offset]
    );
    const list = rows.map((r) => ({
      id: r.id,
      title: r.title,
      status: r.status,
      error_message: r.error_message,
      segment_id: r.segment_id,
      is_public: r.is_public,
      createdAt: r.createdAt
    }));
    return validateSuccess(list);
  }
);

export { index_get as default };
//# sourceMappingURL=index.get.mjs.map
