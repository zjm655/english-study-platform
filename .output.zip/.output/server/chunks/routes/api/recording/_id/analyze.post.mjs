import { c as defineEventHandler, v as validateError, i as getRouterParam, q as query, n as readBody, l as logger, w as withTransaction, e as validateSuccess } from '../../../../_/nitro.mjs';
import { r as rowToRecording } from '../../../../_/recording.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/mysql2/promise.js';
import 'node:url';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/zod/index.js';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/jose/dist/webapi/index.js';

function scoreToStatus(score) {
  if (score >= 80) return "correct";
  if (score >= 60) return "minor";
  if (score >= 40) return "wrong";
  return "missing";
}
function processEvaluationResult(input) {
  const wordScores = input.wordScores.map((w) => ({
    word: w.word,
    score: w.score,
    status: scoreToStatus(w.score)
  }));
  const feedback = generateFeedback(input.score);
  return {
    score: input.score,
    feedback,
    recognizedText: input.recognizedText,
    wordScores
  };
}
function generateFeedback(overall) {
  if (overall >= 85) {
    return "\u6574\u4F53\u8868\u73B0\u4F18\u79C0\uFF0C\u53D1\u97F3\u6E05\u6670\u51C6\u786E\uFF0C\u7EE7\u7EED\u4FDD\u6301\uFF01";
  } else if (overall >= 70) {
    return "\u6574\u4F53\u8868\u73B0\u826F\u597D\uFF0C\u53D1\u97F3\u57FA\u672C\u51C6\u786E\uFF0C\u53EF\u4EE5\u8FDB\u4E00\u6B65\u4F18\u5316\u8BED\u8C03\u3002";
  } else if (overall >= 50) {
    return "\u6574\u4F53\u8868\u73B0\u4E00\u822C\uFF0C\u90E8\u5206\u53D1\u97F3\u9700\u8981\u52A0\u5F3A\uFF0C\u5EFA\u8BAE\u591A\u542C\u591A\u7EC3\u3002";
  } else if (overall > 0) {
    return "\u8BF7\u591A\u7EC3\u4E60\uFF0C\u6CE8\u610F\u6BCF\u4E2A\u5355\u8BCD\u7684\u6807\u51C6\u53D1\u97F3\uFF0C\u5EFA\u8BAE\u8DDF\u8BFB\u6A21\u4EFF\u3002";
  }
  return "";
}

const analyze_post = defineEventHandler(async (event) => {
  var _a;
  const userId = (_a = event.context.user) == null ? void 0 : _a.id;
  if (!userId) return validateError("\u672A\u767B\u5F55", 401);
  const id = Number(getRouterParam(event, "id"));
  if (!id || isNaN(id)) {
    return validateError("\u65E0\u6548\u7684\u5F55\u97F3ID");
  }
  const recordings = await query(
    "SELECT * FROM recording WHERE id = ? AND deleted_at IS NULL",
    [id]
  );
  const recording = recordings[0];
  if (!recording) {
    return validateError("\u5F55\u97F3\u4E0D\u5B58\u5728", 404);
  }
  if (recording.user_id !== userId) {
    return validateError("\u65E0\u6743\u9650\u8BBF\u95EE\u8BE5\u5F55\u97F3", 403);
  }
  const body = await readBody(event);
  const evalResult = body == null ? void 0 : body.result;
  if (!evalResult || typeof evalResult.score !== "number") {
    return validateError("\u7F3A\u5C11\u6709\u6548\u7684\u8BC4\u6D4B\u7ED3\u679C\u6570\u636E", 400);
  }
  logger.info(`[recording analyze] \u4FDD\u5B58\u5206\u6790\u7ED3\u679C id=${id} score=${evalResult.score}`);
  const parsed = processEvaluationResult(evalResult);
  let updatedRecording;
  try {
    updatedRecording = await withTransaction(async (conn) => {
      var _a2;
      await conn.execute(
        `UPDATE recording
         SET score = ?, feedback = ?, wordScores = ?, rawResult = ?
         WHERE id = ?`,
        [
          parsed.score,
          parsed.feedback,
          JSON.stringify(parsed.wordScores),
          (_a2 = evalResult.rawResult) != null ? _a2 : null,
          id
        ]
      );
      const [rows] = await conn.execute(
        "SELECT * FROM recording WHERE id = ? AND deleted_at IS NULL",
        [id]
      );
      return rowToRecording(rows[0]);
    });
  } catch (err) {
    logger.error("[recording analyze] \u4E8B\u52A1\u5931\u8D25:", err);
    return validateError("\u5206\u6790\u4FDD\u5B58\u5931\u8D25\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5", 500);
  }
  if (!updatedRecording) {
    return validateError("\u5206\u6790\u4FDD\u5B58\u5931\u8D25", 500);
  }
  logger.info(`[recording analyze] \u5206\u6790\u5B8C\u6210 id=${id} score=${parsed.score}`);
  return validateSuccess(updatedRecording, "\u5206\u6790\u5B8C\u6210");
});

export { analyze_post as default };
//# sourceMappingURL=analyze.post.mjs.map
