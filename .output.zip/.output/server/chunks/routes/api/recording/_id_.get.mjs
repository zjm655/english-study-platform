import { c as defineEventHandler, i as getRouterParam, v as validateError, q as query, e as validateSuccess } from '../../../_/nitro.mjs';
import { s as signUrl, R as RECORDING_EXPIRE } from '../../../_/oss.mjs';
import { r as rowToRecording } from '../../../_/recording.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/mysql2/promise.js';
import 'node:url';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/zod/index.js';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/jose/dist/webapi/index.js';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/ali-oss/lib/client.js';
import '../../../_/fileLogger.mjs';
import 'node:fs/promises';

const _id__get = defineEventHandler(async (event) => {
  const userId = event.context.user.id;
  const id = Number(getRouterParam(event, "id"));
  if (!id || isNaN(id)) {
    return validateError("\u65E0\u6548\u7684\u5F55\u97F3ID");
  }
  const rows = await query(
    `SELECT r.*, m.object_key AS rec_media_key
     FROM recording r
     LEFT JOIN media m ON r.media_id = m.id
     WHERE r.id = ? AND r.user_id = ? AND r.deleted_at IS NULL`,
    [id, userId]
  );
  const row = rows[0];
  if (!row) {
    return validateError("\u5F55\u97F3\u4E0D\u5B58\u5728", 404);
  }
  const signedPath = row.rec_media_key ? await signUrl(row.rec_media_key, RECORDING_EXPIRE) : null;
  const recording = rowToRecording(row, signedPath);
  return validateSuccess(recording, "\u83B7\u53D6\u6210\u529F");
});

export { _id__get as default };
//# sourceMappingURL=_id_.get.mjs.map
