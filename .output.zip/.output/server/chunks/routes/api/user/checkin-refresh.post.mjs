import { c as defineEventHandler, w as withTransaction, e as validateSuccess } from '../../../_/nitro.mjs';
import { g as getStats, i as isStreakBroken } from '../../../_/checkinHelper.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/mysql2/promise.js';
import 'node:url';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/zod/index.js';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/jose/dist/webapi/index.js';

const checkinRefresh_post = defineEventHandler(async (event) => {
  const userId = event.context.user.id;
  const now = /* @__PURE__ */ new Date();
  const stats = await withTransaction(async (conn) => {
    const current = await getStats(conn, userId);
    if (current.currentStreakDays > 0 && isStreakBroken(current.lastCheckinTime, now)) {
      await conn.execute(
        "UPDATE user_checkin_stats SET current_streak_days = 0 WHERE user_id = ?",
        [userId]
      );
      return { ...current, currentStreakDays: 0 };
    }
    return current;
  });
  return validateSuccess(stats, "\u8FDE\u7EED\u5929\u6570\u5DF2\u5237\u65B0");
});

export { checkinRefresh_post as default };
//# sourceMappingURL=checkin-refresh.post.mjs.map
