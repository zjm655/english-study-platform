import { c as defineEventHandler, v as validateError, n as readBody, M as favWordSchema, w as withTransaction, e as validateSuccess, l as logger } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/mysql2/promise.js';
import 'node:url';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/zod/index.js';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/jose/dist/webapi/index.js';

const favWord_post = defineEventHandler(async (event) => {
  var _a, _b;
  const userId = (_a = event.context.user) == null ? void 0 : _a.id;
  if (!userId) return validateError("\u672A\u767B\u5F55", 401);
  const body = await readBody(event);
  const parsed = favWordSchema.safeParse(body);
  if (!parsed.success) {
    return validateError(((_b = parsed.error.issues[0]) == null ? void 0 : _b.message) || "\u53C2\u6570\u6821\u9A8C\u5931\u8D25");
  }
  const { vocabularyId } = parsed.data;
  try {
    const isFav = await withTransaction(async (conn) => {
      const [vocabRows] = await conn.execute(
        "SELECT id FROM vocabulary WHERE id = ? LIMIT 1",
        [vocabularyId]
      );
      if (vocabRows.length === 0) {
        throw new Error("NOT_FOUND:\u5355\u8BCD\u4E0D\u5B58\u5728");
      }
      const [existing] = await conn.execute(
        "SELECT id, deleted_at FROM user_fav_word WHERE user_id = ? AND vocabulary_id = ? LIMIT 1",
        [userId, vocabularyId]
      );
      if (existing.length === 0) {
        await conn.execute("INSERT INTO user_fav_word (user_id, vocabulary_id) VALUES (?, ?)", [
          userId,
          vocabularyId
        ]);
        return true;
      }
      const record = existing[0];
      if (!record) throw new Error("DATA_ERROR");
      if (record.deleted_at === null) {
        await conn.execute("UPDATE user_fav_word SET deleted_at = NOW() WHERE id = ?", [record.id]);
        return false;
      }
      await conn.execute("UPDATE user_fav_word SET deleted_at = NULL WHERE id = ?", [record.id]);
      return true;
    });
    return validateSuccess({ isFav }, isFav ? "\u6536\u85CF\u6210\u529F" : "\u5DF2\u53D6\u6D88\u6536\u85CF");
  } catch (err) {
    const msg = err instanceof Error ? err.message : "";
    if (msg.startsWith("NOT_FOUND:")) return validateError(msg.slice(10), 404);
    logger.error("[fav-word]", err);
    return validateError("\u64CD\u4F5C\u5931\u8D25\uFF0C\u8BF7\u91CD\u8BD5");
  }
});

export { favWord_post as default };
//# sourceMappingURL=fav-word.post.mjs.map
