import { c as defineEventHandler, n as readBody, N as loginSchema, v as validateError, q as query, O as signToken, P as setCookie, e as validateSuccess } from '../../../_/nitro.mjs';
import bcrypt from 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/bcrypt/bcrypt.js';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/mysql2/promise.js';
import 'node:url';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/zod/index.js';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/jose/dist/webapi/index.js';

const login_post = defineEventHandler(async (event) => {
  var _a, _b;
  const body = await readBody(event);
  const result = loginSchema.safeParse(body);
  if (!result.success) {
    const errorMessage = ((_b = (_a = result.error) == null ? void 0 : _a.issues[0]) == null ? void 0 : _b.message) || "\u53C2\u6570\u6821\u9A8C\u5931\u8D25";
    return validateError(errorMessage, 401);
  }
  const { account, password } = result.data;
  const rows = await query(
    "SELECT id, account, nickname, email, role, status, deleted_at, passwordHash, avatarUrl, level FROM user WHERE account = ?",
    [account]
  );
  const user = rows[0];
  if (!user) {
    return validateError("\u8D26\u53F7\u4E0D\u5B58\u5728", 401);
  }
  if (user.deleted_at) {
    return validateError("\u8D26\u53F7\u5DF2\u6CE8\u9500", 401);
  }
  if (user.status === 0) {
    return validateError("\u8D26\u53F7\u5DF2\u88AB\u5C01\u7981\uFF0C\u8BF7\u8054\u7CFB\u7BA1\u7406\u5458", 403);
  }
  const isMatch = await bcrypt.compare(password, user.passwordHash);
  if (!isMatch) {
    return validateError("\u5BC6\u7801\u9519\u8BEF", 401);
  }
  const token = await signToken({ id: user.id, role: user.role });
  setCookie(event, "token", token, {
    httpOnly: true,
    secure: true,
    sameSite: "lax",
    maxAge: 60 * 60 * 24 * 7,
    path: "/"
  });
  const { passwordHash, ...safeInfo } = user;
  return validateSuccess(safeInfo, "\u767B\u5F55\u6210\u529F\uFF01", 200);
});

export { login_post as default };
//# sourceMappingURL=login.post.mjs.map
