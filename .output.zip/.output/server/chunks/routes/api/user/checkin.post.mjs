import { c as defineEventHandler, w as withTransaction, e as validateSuccess } from '../../../_/nitro.mjs';
import { f as formatDate, a as formatDatetime, g as getStats } from '../../../_/checkinHelper.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/mysql2/promise.js';
import 'node:url';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/zod/index.js';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/jose/dist/webapi/index.js';

const checkin_post = defineEventHandler(async (event) => {
  const userId = event.context.user.id;
  const now = /* @__PURE__ */ new Date();
  const todayStr = formatDate(now);
  const nowStr = formatDatetime(now);
  const result = await withTransaction(async (conn) => {
    const [logRows] = await conn.execute(
      "SELECT * FROM user_checkin_log WHERE user_id = ? AND checkin_date = ?",
      [userId, todayStr]
    );
    const todayLog = logRows[0];
    if (todayLog && todayLog.checked_in === 1) {
      return {
        alreadyCheckedIn: true,
        stats: await getStats(conn, userId)
      };
    }
    if (todayLog) {
      await conn.execute(
        "UPDATE user_checkin_log SET checked_in = 1 WHERE id = ?",
        [todayLog.id]
      );
    } else {
      await conn.execute(
        "INSERT INTO user_checkin_log (user_id, checkin_date, checked_in) VALUES (?, ?, 1)",
        [userId, todayStr]
      );
    }
    const stats = await getStats(conn, userId);
    const lastCheckinTime = stats.lastCheckinTime;
    let newStreak;
    if (!lastCheckinTime) {
      newStreak = 1;
    } else {
      const lastDate = new Date(lastCheckinTime);
      const yesterday = new Date(now);
      yesterday.setDate(now.getDate() - 1);
      const isConsecutive = lastDate.getFullYear() === yesterday.getFullYear() && lastDate.getMonth() === yesterday.getMonth() && lastDate.getDate() === yesterday.getDate();
      newStreak = isConsecutive ? stats.currentStreakDays + 1 : 1;
    }
    const newMax = Math.max(newStreak, stats.maxStreakDays);
    await conn.execute(
      `UPDATE user_checkin_stats
       SET total_checkin_days = total_checkin_days + 1,
           last_checkin_time = ?,
           current_streak_days = ?,
           max_streak_days = ?
       WHERE user_id = ?`,
      [nowStr, newStreak, newMax, userId]
    );
    return {
      alreadyCheckedIn: false,
      stats: {
        totalCheckinDays: stats.totalCheckinDays + 1,
        lastCheckinTime: nowStr,
        currentStreakDays: newStreak,
        maxStreakDays: newMax,
        totalStudySeconds: stats.totalStudySeconds
      }
    };
  });
  if (result.alreadyCheckedIn) {
    return validateSuccess(result.stats, "\u4ECA\u65E5\u5DF2\u7B7E\u5230");
  }
  return validateSuccess(result.stats, "\u7B7E\u5230\u6210\u529F");
});

export { checkin_post as default };
//# sourceMappingURL=checkin.post.mjs.map
