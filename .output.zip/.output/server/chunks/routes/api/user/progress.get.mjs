import { c as defineEventHandler, v as validateError, q as query, e as validateSuccess } from '../../../_/nitro.mjs';
import { m as mapProgressRow } from '../../../_/progress.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/mysql2/promise.js';
import 'node:url';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/zod/index.js';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/jose/dist/webapi/index.js';

const progress_get = defineEventHandler(async (event) => {
  var _a, _b, _c;
  const userId = (_a = event.context.user) == null ? void 0 : _a.id;
  if (!userId) {
    return validateError("\u672A\u767B\u5F55", 401);
  }
  const rows = await query(
    `SELECT up.*, s.title as segmentTitle, s.unit_id, u.title as unitTitle
     FROM user_progress up
     JOIN segment s ON up.segment_id = s.id AND s.deleted_at IS NULL
     JOIN unit u ON s.unit_id = u.id
     WHERE up.user_id = ? AND up.deleted_at IS NULL
     ORDER BY u.level, u.sort_order, s.sort_order`,
    [userId]
  );
  const totalSegments = rows.length;
  const completedPhases = rows.reduce(
    (acc, row) => {
      return {
        phase1: acc.phase1 + (row.phase1_done ? 1 : 0),
        phase2: acc.phase2 + (row.phase2_done ? 1 : 0),
        phase3: acc.phase3 + (row.phase3_done ? 1 : 0),
        phase4: acc.phase4 + (row.phase4_done ? 1 : 0)
      };
    },
    { phase1: 0, phase2: 0, phase3: 0, phase4: 0 }
  );
  const allSegmentsRows = await query(
    "SELECT COUNT(*) as total FROM segment WHERE deleted_at IS NULL"
  );
  const totalSegmentsAll = (_c = (_b = allSegmentsRows[0]) == null ? void 0 : _b.total) != null ? _c : 0;
  const completedSegments = rows.filter(
    (row) => row.phase1_done && row.phase2_done && row.phase3_done && row.phase4_done
  ).length;
  return validateSuccess(
    {
      summary: {
        totalSegmentsAll,
        progressRecords: totalSegments,
        completedSegments,
        completedPhases,
        overallPercent: totalSegmentsAll > 0 ? Math.round(completedSegments / totalSegmentsAll * 100) : 0
      },
      details: rows.map((row) => ({
        segmentId: row.segment_id,
        segmentTitle: row.segmentTitle,
        unitId: row.unit_id,
        unitTitle: row.unitTitle,
        ...mapProgressRow(row)
      }))
    },
    "\u83B7\u53D6\u7528\u6237\u8FDB\u5EA6\u6210\u529F",
    200
  );
});

export { progress_get as default };
//# sourceMappingURL=progress.get.mjs.map
