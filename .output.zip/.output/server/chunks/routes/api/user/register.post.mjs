import { c as defineEventHandler, n as readBody, S as registerSchema, v as validateError, q as query, z as pool, e as validateSuccess } from '../../../_/nitro.mjs';
import bcrypt from 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/bcrypt/bcrypt.js';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/mysql2/promise.js';
import 'node:url';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/zod/index.js';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/jose/dist/webapi/index.js';

const register_post = defineEventHandler(async (event) => {
  var _a, _b;
  const body = await readBody(event);
  const result = registerSchema.safeParse(body);
  if (!result.success) {
    const errorMessage = ((_b = (_a = result.error) == null ? void 0 : _a.issues[0]) == null ? void 0 : _b.message) || "\u53C2\u6570\u6821\u9A8C\u5931\u8D25";
    return validateError(errorMessage);
  }
  const { account, password1, nickname, email } = result.data;
  const accountRows = await query("SELECT id FROM user WHERE account = ?", [account]);
  if (accountRows.length > 0) {
    return validateError("\u8BE5\u8D26\u53F7\u5DF2\u6CE8\u518C\uFF0C\u8BF7\u76F4\u63A5\u767B\u5F55");
  }
  if (email) {
    const emailRows = await query("SELECT id FROM user WHERE email = ?", [email]);
    if (emailRows.length > 0) {
      return validateError("\u8BE5\u90AE\u7BB1\u5DF2\u7ED1\u5B9A\u5176\u4ED6\u8D26\u53F7");
    }
  }
  const passwordHash = await bcrypt.hash(password1, 10);
  const [insertResult] = await pool.execute(
    "INSERT INTO user (account, passwordHash, nickname, email) VALUES (?, ?, ?, ?)",
    [account, passwordHash, nickname || null, email || null]
  );
  await pool.execute("INSERT INTO user_checkin_stats (user_id) VALUES (?)", [insertResult.insertId]);
  return validateSuccess(null, "\u6CE8\u518C\u6210\u529F\uFF01");
});

export { register_post as default };
//# sourceMappingURL=register.post.mjs.map
