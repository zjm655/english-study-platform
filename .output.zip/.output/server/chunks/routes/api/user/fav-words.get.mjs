import { c as defineEventHandler, v as validateError, q as query, e as validateSuccess } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/mysql2/promise.js';
import 'node:url';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/zod/index.js';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/jose/dist/webapi/index.js';

const favWords_get = defineEventHandler(async (event) => {
  var _a;
  const userId = (_a = event.context.user) == null ? void 0 : _a.id;
  if (!userId) return validateError("\u672A\u767B\u5F55", 401);
  const rows = await query(
    "SELECT vocabulary_id FROM user_fav_word WHERE user_id = ? AND deleted_at IS NULL",
    [userId]
  );
  const ids = rows.map((r) => r.vocabulary_id);
  return validateSuccess(ids, "\u83B7\u53D6\u6210\u529F");
});

export { favWords_get as default };
//# sourceMappingURL=fav-words.get.mjs.map
