import { c as defineEventHandler, v as validateError, n as readBody, Q as progressSchema, w as withTransaction, e as validateSuccess } from '../../../_/nitro.mjs';
import { m as mapProgressRow } from '../../../_/progress.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/mysql2/promise.js';
import 'node:url';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/zod/index.js';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/jose/dist/webapi/index.js';

const progress_put = defineEventHandler(async (event) => {
  var _a, _b, _c;
  const userId = (_a = event.context.user) == null ? void 0 : _a.id;
  if (!userId) {
    return validateError("\u672A\u767B\u5F55", 401);
  }
  const body = await readBody(event);
  const parseResult = progressSchema.safeParse(body);
  if (!parseResult.success) {
    const errorMessage = ((_c = (_b = parseResult.error) == null ? void 0 : _b.issues[0]) == null ? void 0 : _c.message) || "\u53C2\u6570\u6821\u9A8C\u5931\u8D25";
    return validateError(errorMessage);
  }
  const { segmentId, phase, done, score } = parseResult.data;
  const result = await withTransaction(async (conn) => {
    const [existingRows] = await conn.execute(
      "SELECT * FROM user_progress WHERE user_id = ? AND segment_id = ? AND deleted_at IS NULL",
      [userId, segmentId]
    );
    const existing = existingRows;
    if (existing.length === 0) {
      const fields = ["user_id", "segment_id", `phase${phase}_done`];
      const values = [userId, segmentId, done ? 1 : 0];
      if ((phase === 3 || phase === 4) && score !== void 0) {
        fields.push(`phase${phase}_score`);
        values.push(score);
      }
      await conn.execute(
        `INSERT INTO user_progress (${fields.join(", ")}) VALUES (${fields.map(() => "?").join(", ")})`,
        values
      );
    } else {
      const updates = [`phase${phase}_done = ?`];
      const values = [done ? 1 : 0];
      if ((phase === 3 || phase === 4) && score !== void 0) {
        updates.push(`phase${phase}_score = GREATEST(COALESCE(phase${phase}_score, 0), ?)`);
        values.push(score);
      }
      values.push(userId, segmentId);
      await conn.execute(
        `UPDATE user_progress SET ${updates.join(", ")} WHERE user_id = ? AND segment_id = ? AND deleted_at IS NULL`,
        values
      );
    }
    const [updatedRows] = await conn.execute(
      "SELECT * FROM user_progress WHERE user_id = ? AND segment_id = ? AND deleted_at IS NULL",
      [userId, segmentId]
    );
    return updatedRows[0];
  });
  if (!result) {
    return validateError("\u66F4\u65B0\u8FDB\u5EA6\u5931\u8D25", 500);
  }
  return validateSuccess(
    {
      segmentId: result.segment_id,
      ...mapProgressRow(result)
    },
    "\u66F4\u65B0\u8FDB\u5EA6\u6210\u529F",
    200
  );
});

export { progress_put as default };
//# sourceMappingURL=progress.put.mjs.map
