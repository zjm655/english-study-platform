import { c as defineEventHandler, v as validateError, i as getRouterParam, q as query, e as validateSuccess } from '../../../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/mysql2/promise.js';
import 'node:url';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/zod/index.js';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/jose/dist/webapi/index.js';

const status_get = defineEventHandler(async (event) => {
  var _a;
  const userId = (_a = event.context.user) == null ? void 0 : _a.id;
  if (!userId) return validateError("\u672A\u767B\u5F55", 401);
  const segId = Number(getRouterParam(event, "segId"));
  if (!segId || isNaN(segId)) {
    return validateError("\u65E0\u6548\u7684\u7247\u6BB5ID");
  }
  const rows = await query(
    "SELECT id FROM user_fav_segment WHERE user_id = ? AND segment_id = ? AND deleted_at IS NULL",
    [userId, segId]
  );
  return validateSuccess({ isFav: rows.length > 0 }, "\u83B7\u53D6\u6210\u529F");
});

export { status_get as default };
//# sourceMappingURL=status.get.mjs.map
