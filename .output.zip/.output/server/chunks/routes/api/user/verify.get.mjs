import { c as defineEventHandler, q as query, v as validateError, O as signToken, P as setCookie, e as validateSuccess } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/mysql2/promise.js';
import 'node:url';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/zod/index.js';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/jose/dist/webapi/index.js';

const verify_get = defineEventHandler(async (event) => {
  const userId = event.context.user.id;
  const rows = await query(
    "SELECT id, account, nickname, email, role, passwordHash, avatarUrl, level FROM user WHERE id = ?",
    [userId]
  );
  const user = rows[0];
  if (!user) {
    return validateError("\u8D26\u53F7\u4E0D\u5B58\u5728", 401);
  }
  const token = await signToken({ id: user.id, role: user.role });
  setCookie(event, "token", token, {
    httpOnly: true,
    secure: true,
    sameSite: "lax",
    maxAge: 60 * 60 * 24 * 7,
    path: "/"
  });
  const { passwordHash, ...safeInfo } = user;
  return validateSuccess(safeInfo, "\u767B\u5F55\u72B6\u6001\u6821\u9A8C\u901A\u8FC7\uFF01", 200);
});

export { verify_get as default };
//# sourceMappingURL=verify.get.mjs.map
