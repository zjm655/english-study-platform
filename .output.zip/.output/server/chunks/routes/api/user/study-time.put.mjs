import { c as defineEventHandler, n as readBody, T as studyTimeSchema, v as validateError, w as withTransaction, e as validateSuccess } from '../../../_/nitro.mjs';
import { f as formatDate, g as getStats } from '../../../_/checkinHelper.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/mysql2/promise.js';
import 'node:url';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/zod/index.js';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/jose/dist/webapi/index.js';

const MAX_STUDY_SECONDS_PER_REPORT = 3600;
const studyTime_put = defineEventHandler(async (event) => {
  var _a, _b;
  const userId = event.context.user.id;
  const body = await readBody(event);
  const result = studyTimeSchema.safeParse(body);
  if (!result.success) {
    const errorMessage = ((_b = (_a = result.error) == null ? void 0 : _a.issues[0]) == null ? void 0 : _b.message) || "\u53C2\u6570\u6821\u9A8C\u5931\u8D25";
    return validateError(errorMessage);
  }
  const reportedSeconds = result.data.studySeconds;
  const todayStr = formatDate(/* @__PURE__ */ new Date());
  const stats = await withTransaction(async (conn) => {
    const [logRows] = await conn.execute(
      "SELECT * FROM user_checkin_log WHERE user_id = ? AND checkin_date = ?",
      [userId, todayStr]
    );
    const todayLog = logRows[0];
    if (!todayLog) {
      await conn.execute(
        "INSERT IGNORE INTO user_checkin_log (user_id, checkin_date, checked_in) VALUES (?, ?, 0)",
        [userId, todayStr]
      );
      return getStats(conn, userId);
    }
    const updatedAt = new Date(todayLog.updatedAt);
    const now = /* @__PURE__ */ new Date();
    const intervalSeconds = (now.getTime() - updatedAt.getTime()) / 1e3;
    if (intervalSeconds < 10) {
      return getStats(conn, userId);
    }
    let actualSeconds = reportedSeconds;
    if (intervalSeconds < reportedSeconds - 10) {
      return getStats(conn, userId);
    }
    if (actualSeconds > intervalSeconds) {
      actualSeconds = Math.min(actualSeconds, MAX_STUDY_SECONDS_PER_REPORT);
    }
    const addSeconds = Math.floor(actualSeconds);
    if (addSeconds <= 0) {
      return getStats(conn, userId);
    }
    await conn.execute(
      "UPDATE user_checkin_log SET study_seconds = study_seconds + ? WHERE id = ?",
      [addSeconds, todayLog.id]
    );
    await conn.execute(
      "UPDATE user_checkin_stats SET total_study_seconds = total_study_seconds + ? WHERE user_id = ?",
      [addSeconds, userId]
    );
    return getStats(conn, userId);
  });
  return validateSuccess(stats, "\u66F4\u65B0\u6210\u529F");
});

export { studyTime_put as default };
//# sourceMappingURL=study-time.put.mjs.map
