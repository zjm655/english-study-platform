import { c as defineEventHandler, v as validateError, q as query, e as validateSuccess } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/mysql2/promise.js';
import 'node:url';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/zod/index.js';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/jose/dist/webapi/index.js';

const stats_get = defineEventHandler(async (event) => {
  var _a, _b, _c, _d, _e, _f;
  const userId = (_a = event.context.user) == null ? void 0 : _a.id;
  if (!userId) {
    return validateError("\u672A\u767B\u5F55");
  }
  const completedRows = await query(
    `SELECT COUNT(*) as cnt FROM user_progress WHERE user_id = ? AND phase4_done = 1`,
    [userId]
  );
  const completedSegments = Number((_c = (_b = completedRows[0]) == null ? void 0 : _b.cnt) != null ? _c : 0);
  const scoreRows = await query(
    `SELECT AVG(score) as avg_score FROM recording WHERE user_id = ? AND phase = 3 AND score IS NOT NULL`,
    [userId]
  );
  const avgDubbingScore = ((_d = scoreRows[0]) == null ? void 0 : _d.avg_score) != null ? Math.round(Number(scoreRows[0].avg_score) * 10) / 10 : null;
  const timeRows = await query(
    `SELECT MAX(updatedAt) as last_time FROM user_progress WHERE user_id = ?`,
    [userId]
  );
  const lastStudyTime = (_f = (_e = timeRows[0]) == null ? void 0 : _e.last_time) != null ? _f : null;
  return validateSuccess({
    completedSegments,
    avgDubbingScore,
    lastStudyTime
  });
});

export { stats_get as default };
//# sourceMappingURL=stats.get.mjs.map
