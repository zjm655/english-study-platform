import { c as defineEventHandler, q as query, e as validateSuccess } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/mysql2/promise.js';
import 'node:url';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/zod/index.js';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/jose/dist/webapi/index.js';

const checkinStats_get = defineEventHandler(async (event) => {
  const userId = event.context.user.id;
  const rows = await query("SELECT * FROM user_checkin_stats WHERE user_id = ?", [
    userId
  ]);
  if (!rows.length) {
    return validateSuccess(null, "\u6682\u65E0\u6253\u5361\u6570\u636E", 200);
  }
  const row = rows[0];
  const stats = {
    totalCheckinDays: row.total_checkin_days,
    lastCheckinTime: row.last_checkin_time,
    currentStreakDays: row.current_streak_days,
    maxStreakDays: row.max_streak_days,
    totalStudySeconds: row.total_study_seconds
  };
  return validateSuccess(stats, "\u83B7\u53D6\u6210\u529F", 200);
});

export { checkinStats_get as default };
//# sourceMappingURL=checkin-stats.get.mjs.map
