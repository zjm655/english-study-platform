import { c as defineEventHandler, v as validateError, x as readFormData, H as uploadRecordingSchema, l as logger, w as withTransaction, u as useRuntimeConfig, e as validateSuccess, z as pool } from '../../_/nitro.mjs';
import { randomUUID } from 'node:crypto';
import { u as uploadWithKey, s as signUrl, R as RECORDING_EXPIRE } from '../../_/oss.mjs';
import { s as speechToText } from '../../_/speechToText.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/mysql2/promise.js';
import 'node:url';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/zod/index.js';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/jose/dist/webapi/index.js';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/ali-oss/lib/client.js';
import '../../_/fileLogger.mjs';
import 'node:fs/promises';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/@alicloud/pop-core/index.js';
import '../../_/request.mjs';

const MAX_FILE_SIZE = 50 * 1024 * 1024;
const MIME_TO_STT_FORMAT = {
  "audio/webm": "opus",
  "audio/ogg": "opus",
  "audio/wav": "wav",
  "audio/x-wav": "wav",
  "audio/mp3": "mp3",
  "audio/mpeg": "mp3"
};
const AUDIO_SIGNATURES = {
  "audio/webm": [26, 69, 223, 163],
  // EBML
  "audio/ogg": [79, 103, 103, 83],
  // OggS
  "audio/wav": [82, 73, 70, 70],
  // RIFF
  "audio/x-wav": [82, 73, 70, 70]
  // RIFF
};
const MP3_SIGNATURES = [
  [73, 68, 51],
  // "ID3"
  [255, 251],
  [255, 243],
  [255, 242]
  // 帧同步
];
const index_post = defineEventHandler(
  async (event) => {
    var _a, _b;
    const userId = (_a = event.context.user) == null ? void 0 : _a.id;
    if (!userId) return validateError("\u672A\u767B\u5F55", 401);
    const formData = await readFormData(event);
    const file = formData.get("audio");
    const segmentId = Number(formData.get("segmentId"));
    const phase = Number(formData.get("phase"));
    const duration = Number(formData.get("duration"));
    if (isNaN(segmentId) || isNaN(phase) || isNaN(duration)) {
      return validateError("\u53C2\u6570\u683C\u5F0F\u9519\u8BEF", 400);
    }
    if (!file || !(file instanceof File)) {
      return validateError("\u672A\u4E0A\u4F20\u5F55\u97F3\u6587\u4EF6");
    }
    if (file.size === 0) return validateError("\u6587\u4EF6\u4E3A\u7A7A");
    if (file.size > MAX_FILE_SIZE) return validateError("\u6587\u4EF6\u5927\u5C0F\u8D85\u8FC7\u9650\u5236(50MB)");
    const mimeType = file.type;
    const allowedMimes = [...Object.keys(AUDIO_SIGNATURES), "audio/mp3", "audio/mpeg"];
    if (!allowedMimes.includes(mimeType)) {
      return validateError("\u4E0D\u652F\u6301\u7684\u97F3\u9891\u683C\u5F0F");
    }
    const fileBuffer = Buffer.from(await file.arrayBuffer());
    if (!verifyMagicBytes(fileBuffer, mimeType)) {
      return validateError("\u6587\u4EF6\u5185\u5BB9\u4E0E\u58F0\u660E\u7C7B\u578B\u4E0D\u5339\u914D");
    }
    const parseResult = uploadRecordingSchema.safeParse({ segmentId, phase, duration });
    if (!parseResult.success) {
      return validateError(((_b = parseResult.error.issues[0]) == null ? void 0 : _b.message) || "\u53C2\u6570\u6821\u9A8C\u5931\u8D25");
    }
    logger.info(
      `[recording upload] \u6536\u5230\u5F55\u97F3\u4E0A\u4F20 user=${userId} segment=${segmentId} phase=${phase} ${mimeType} ${file.size}B`
    );
    const ext = mimeType === "audio/webm" ? "webm" : mimeType === "audio/ogg" ? "ogg" : mimeType === "audio/wav" || mimeType === "audio/x-wav" ? "wav" : "mp3";
    const ossKey = `audio/recordings/${randomUUID()}.${ext}`;
    try {
      await uploadWithKey(fileBuffer, ossKey);
    } catch (err) {
      logger.error("[recording upload] OSS \u4E0A\u4F20\u5931\u8D25:", err);
      return validateError("\u6587\u4EF6\u4E0A\u4F20\u5931\u8D25\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5", 500);
    }
    let result;
    try {
      result = await withTransaction(async (conn) => {
        const [mediaRes] = await conn.execute(
          `INSERT INTO media (uploader_id, type, storage_type, bucket, object_key, original_name, mime_type, size_bytes, duration, status)
         VALUES (?, 'recording', 'oss', ?, ?, ?, ?, ?, ?, 1)`,
          [
            userId,
            useRuntimeConfig().oss.bucket,
            ossKey,
            `${randomUUID()}.${ext}`,
            mimeType,
            file.size,
            duration
          ]
        );
        const mediaId = mediaRes.insertId;
        const [recRes] = await conn.execute(
          "INSERT INTO recording (user_id, segment_id, phase, media_id, duration) VALUES (?, ?, ?, ?, ?)",
          [userId, segmentId, phase, mediaId, duration]
        );
        const [rows] = await conn.execute(
          `SELECT r.*, m.object_key AS rec_media_key
         FROM recording r
         LEFT JOIN media m ON r.media_id = m.id
         WHERE r.id = ? AND r.deleted_at IS NULL`,
          [recRes.insertId]
        );
        const row = rows[0];
        const signedUrl = await signUrl(row.rec_media_key, RECORDING_EXPIRE);
        return {
          id: row.id,
          audioPath: signedUrl,
          duration: Number(row.duration),
          createdAt: row.createdAt
        };
      });
    } catch (err) {
      logger.error("[recording upload] \u4E8B\u52A1\u5931\u8D25:", err);
      return validateError("\u4E0A\u4F20\u5931\u8D25\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5", 500);
    }
    if (!result) {
      return validateError("\u4E0A\u4F20\u5931\u8D25", 500);
    }
    recognizeAudio(fileBuffer, mimeType, result.id).catch((err) => {
      logger.error("[recording upload] ASR \u5F02\u6B65\u8BC6\u522B\u5931\u8D25:", err);
    });
    logger.info(`[recording upload] \u4E0A\u4F20\u6210\u529F id=${result.id} key=${ossKey}`);
    return validateSuccess(result, "\u4E0A\u4F20\u6210\u529F");
  }
);
async function recognizeAudio(audioBuffer, mimeType, recordingId) {
  const format = MIME_TO_STT_FORMAT[mimeType] || "mp3";
  const sttResult = await speechToText(
    audioBuffer,
    format
  );
  if (sttResult.success && sttResult.text) {
    await pool.execute("UPDATE recording SET recognizedText = ? WHERE id = ?", [
      sttResult.text,
      recordingId
    ]);
    logger.log("[recording upload] ASR \u8BC6\u522B\u5B8C\u6210:", sttResult.text.slice(0, 60));
  } else {
    logger.warn("[recording upload] ASR \u8BC6\u522B\u65E0\u7ED3\u679C:", sttResult.error);
  }
}
function verifyMagicBytes(buf, mimeType) {
  if (mimeType === "audio/mp3" || mimeType === "audio/mpeg") {
    return MP3_SIGNATURES.some((sig) => sig.every((byte, i) => buf[i] === byte));
  }
  const expected = AUDIO_SIGNATURES[mimeType];
  if (!expected) return false;
  return expected.every((byte, i) => buf[i] === byte);
}

export { index_post as default };
//# sourceMappingURL=index.post.mjs.map
