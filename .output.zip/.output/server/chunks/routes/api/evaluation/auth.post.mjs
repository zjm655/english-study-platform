import { c as defineEventHandler, v as validateError, u as useRuntimeConfig, l as logger, F as getRequestIP, e as validateSuccess } from '../../../_/nitro.mjs';
import crypto from 'node:crypto';
import { s as serverFetch } from '../../../_/request.mjs';
import { networkInterfaces } from 'node:os';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/mysql2/promise.js';
import 'node:url';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/zod/index.js';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/jose/dist/webapi/index.js';
import '../../../_/fileLogger.mjs';
import 'node:fs/promises';

function getMachineIp() {
  const interfaces = networkInterfaces();
  for (const name of Object.keys(interfaces)) {
    const iface = interfaces[name];
    if (!iface) continue;
    for (const info of iface) {
      if (info.family === "IPv4" && !info.internal) {
        return info.address;
      }
    }
  }
  return "127.0.0.1";
}
const auth_post = defineEventHandler(
  async (event) => {
    var _a, _b;
    const userId = (_a = event.context.user) == null ? void 0 : _a.id;
    if (!userId) return validateError("\u672A\u767B\u5F55", 401);
    const { aiContent } = useRuntimeConfig();
    const { appId, appSecret, authUrl } = aiContent;
    if (!appId || !appSecret || !authUrl) {
      logger.error("[evaluation auth] aiContent \u914D\u7F6E\u4E0D\u5B8C\u6574");
      return validateError("\u8BC4\u6D4B\u670D\u52A1\u914D\u7F6E\u4E0D\u5B8C\u6574", 500);
    }
    const timestamp = Math.floor(Date.now() / 1e3).toString();
    const requestIp = (_b = getRequestIP(event, { xForwardedFor: true })) != null ? _b : "";
    const userClientIp = requestIp && requestIp !== "127.0.0.1" && requestIp !== "::1" && requestIp !== "::ffff:127.0.0.1" ? requestIp : getMachineIp();
    const signMap = {
      app_secret: appSecret,
      appid: appId,
      timestamp,
      user_client_ip: userClientIp,
      user_id: String(userId)
    };
    const signStr = Object.keys(signMap).sort().map((k) => `${k}=${signMap[k]}`).join("&");
    const requestSign = crypto.createHash("md5").update(signStr, "utf8").digest("hex");
    try {
      const body = new URLSearchParams({
        appid: appId,
        timestamp,
        user_id: String(userId),
        user_client_ip: userClientIp,
        request_sign: requestSign,
        warrant_available: "300"
        // 5 分钟有效期
      });
      const resp = await serverFetch(authUrl, {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: body.toString(),
        timeout: 3e4,
        tag: "[evaluation auth]"
      });
      if (!resp.ok) {
        logger.error("[evaluation auth] \u963F\u91CC\u4E91 HTTP \u9519\u8BEF:", resp.status);
        return validateError(`\u8BC4\u6D4B\u670D\u52A1\u5F02\u5E38\uFF08${resp.status}\uFF09`, 502);
      }
      const respData = await resp.json();
      if (respData.code !== 0) {
        logger.error("[evaluation auth] \u963F\u91CC\u4E91\u8FD4\u56DE\u9519\u8BEF:", respData);
        return validateError(respData.message || "\u83B7\u53D6\u8BC4\u6D4B\u6388\u6743\u5931\u8D25", 502);
      }
      return validateSuccess({
        warrantId: respData.data.warrant_id,
        applicationId: appId,
        expireAt: respData.data.expire_at
      });
    } catch (err) {
      logger.error("[evaluation auth] \u8BF7\u6C42\u963F\u91CC\u4E91\u9274\u6743\u63A5\u53E3\u5931\u8D25:", err);
      return validateError("\u8BC4\u6D4B\u6388\u6743\u670D\u52A1\u6682\u65F6\u4E0D\u53EF\u7528", 502);
    }
  }
);

export { auth_post as default };
//# sourceMappingURL=auth.post.mjs.map
