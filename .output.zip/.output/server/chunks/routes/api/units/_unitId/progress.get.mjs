import { c as defineEventHandler, i as getRouterParam, v as validateError, g as getQuery, q as query, e as validateSuccess } from '../../../../_/nitro.mjs';
import { M as MATERIAL_EXPIRE, s as signUrl } from '../../../../_/oss.mjs';
import { m as mapProgressRow, D as DEFAULT_PROGRESS } from '../../../../_/progress.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/mysql2/promise.js';
import 'node:url';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/zod/index.js';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/jose/dist/webapi/index.js';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/ali-oss/lib/client.js';
import '../../../../_/fileLogger.mjs';
import 'node:fs/promises';

async function signFromMedia(objectKey, expires = MATERIAL_EXPIRE) {
  if (objectKey) return signUrl(objectKey, expires);
  return null;
}
const progress_get = defineEventHandler(async (event) => {
  var _a, _b;
  const userId = event.context.user.id;
  const unitId = Number(getRouterParam(event, "unitId"));
  if (isNaN(unitId)) {
    return validateError("\u65E0\u6548\u7684\u5355\u5143ID");
  }
  const q = getQuery(event);
  const page = Math.max(1, Number(q.page) || 1);
  const pageSize = Math.min(50, Math.max(1, Number(q.pageSize) || 10));
  const offset = (page - 1) * pageSize;
  const adminFlag = event.context.user.role === 1 ? 1 : 0;
  const units = await query(
    `SELECT u.*, m.object_key AS unit_media_key
     FROM unit u
     LEFT JOIN media m ON u.cover_media_id = m.id
     WHERE u.id = ?`,
    [unitId]
  );
  const unit = units[0];
  if (!unit) {
    return validateError("\u5355\u5143\u4E0D\u5B58\u5728", 404);
  }
  const visibilityWhere = `s.unit_id = ? AND s.deleted_at IS NULL AND (? = 1 OR s.is_public = 1 OR m.uploader_id = ?)`;
  const segments = await query(
    `SELECT s.id, s.title, s.sort_order AS sortOrder,
            m.object_key AS seg_media_key,
            (m.uploader_id = ?) AS isMine
     FROM segment s
     LEFT JOIN media m ON s.media_id = m.id
     WHERE ${visibilityWhere}
     ORDER BY isMine DESC, s.sort_order
     LIMIT ? OFFSET ?`,
    [userId, unitId, adminFlag, userId, pageSize, offset]
  );
  const countRows = await query(
    `SELECT COUNT(*) AS total
     FROM segment s
     LEFT JOIN media m ON s.media_id = m.id
     WHERE ${visibilityWhere}`,
    [unitId, adminFlag, userId]
  );
  const total = Number((_b = (_a = countRows[0]) == null ? void 0 : _a.total) != null ? _b : 0);
  const progressRows = await query(
    "SELECT * FROM user_progress WHERE user_id = ? AND segment_id IN (SELECT id FROM segment WHERE unit_id = ? AND deleted_at IS NULL)",
    [userId, unitId]
  );
  const progressMap = new Map(progressRows.map((r) => [r.segment_id, r]));
  const segmentsWithProgress = await Promise.all(
    segments.map(async (s) => ({
      id: s.id,
      title: s.title,
      audioUrl: await signFromMedia(s.seg_media_key, MATERIAL_EXPIRE),
      sortOrder: s.sortOrder,
      isMine: s.isMine === 1,
      progress: (() => {
        var _a2;
        const p = progressMap.get(s.id);
        const raw = p ? mapProgressRow(p) : { ...DEFAULT_PROGRESS };
        return {
          ...raw,
          updatedAt: raw.updatedAt instanceof Date ? raw.updatedAt.toISOString() : (_a2 = raw.updatedAt) != null ? _a2 : void 0
        };
      })()
    }))
  );
  const result = {
    unit: {
      id: unit.id,
      title: unit.title,
      description: unit.description,
      level: unit.level,
      sortOrder: unit.sort_order,
      audioUrl: await signFromMedia(unit.unit_media_key, MATERIAL_EXPIRE)
    },
    segments: segmentsWithProgress,
    pagination: { page, pageSize, total, hasMore: offset + pageSize < total }
  };
  return validateSuccess(result, "\u83B7\u53D6\u6210\u529F");
});

export { progress_get as default };
//# sourceMappingURL=progress.get.mjs.map
