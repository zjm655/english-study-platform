import { c as defineEventHandler, R as ROLE_ADMIN, v as validateError, i as getRouterParam, r as readValidatedBody, j as adminMaterialRecordReprocessSchema, q as query, u as useRuntimeConfig, l as logger, e as validateSuccess } from '../../../../../../_/nitro.mjs';
import { p as processAdminMaterial } from '../../../../../../_/adminUpload.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/mysql2/promise.js';
import 'node:url';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/zod/index.js';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/jose/dist/webapi/index.js';
import '../../../../../../_/audioMeta.mjs';
import '../../../../../../_/request.mjs';
import '../../../../../../_/fileLogger.mjs';
import 'node:fs/promises';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/ws/wrapper.mjs';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/music-metadata/lib/index.js';
import '../../../../../../_/oss.mjs';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/ali-oss/lib/client.js';

const reprocess_post = defineEventHandler(async (event) => {
  var _a, _b, _c, _d;
  const user = event.context.user;
  if (!user || user.role !== ROLE_ADMIN) {
    return validateError("\u65E0\u7BA1\u7406\u5458\u6743\u9650", 403);
  }
  const id = Number(getRouterParam(event, "id"));
  if (isNaN(id) || id <= 0) return validateError("\u65E0\u6548\u7684\u8BB0\u5F55ID");
  const body = await readValidatedBody(event, adminMaterialRecordReprocessSchema.safeParse);
  if (!body.success) {
    return validateError((_d = (_c = (_b = (_a = body.error) == null ? void 0 : _a.issues) == null ? void 0 : _b[0]) == null ? void 0 : _c.message) != null ? _d : "\u53C2\u6570\u6821\u9A8C\u5931\u8D25", 400);
  }
  const { unitId } = body.data;
  const rows = await query(
    "SELECT user_id, title, text_content, voice, is_public, status FROM material_upload_record WHERE id = ?",
    [id]
  );
  if (!rows.length) return validateError("\u8BB0\u5F55\u4E0D\u5B58\u5728", 404);
  const record = rows[0];
  if (record.status !== "failed") {
    return validateError("\u4EC5\u5931\u8D25\u8BB0\u5F55\u53EF\u91CD\u5904\u7406", 400);
  }
  const config = useRuntimeConfig();
  processAdminMaterial({
    userId: record.user_id,
    unitId,
    textContent: record.text_content,
    title: record.title,
    voice: record.voice,
    isPublic: record.is_public,
    bucket: config.oss.bucket || "",
    existingRecordId: id
  }).catch((err) => {
    logger.error("[admin reprocess] \u91CD\u5904\u7406\u5F02\u5E38:", err);
  });
  return validateSuccess(null, "\u91CD\u5904\u7406\u5DF2\u63D0\u4EA4");
});

export { reprocess_post as default };
//# sourceMappingURL=reprocess.post.mjs.map
