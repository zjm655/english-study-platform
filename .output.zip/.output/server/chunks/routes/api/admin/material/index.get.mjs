import { c as defineEventHandler, R as ROLE_ADMIN, v as validateError, k as adminMaterialRecordListSchema, g as getQuery, q as query, e as validateSuccess } from '../../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/mysql2/promise.js';
import 'node:url';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/zod/index.js';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/jose/dist/webapi/index.js';

const index_get = defineEventHandler(async (event) => {
  var _a, _b, _c, _d, _e, _f;
  const user = event.context.user;
  if (!user || user.role !== ROLE_ADMIN) {
    return validateError("\u65E0\u7BA1\u7406\u5458\u6743\u9650", 403);
  }
  const parsed = adminMaterialRecordListSchema.safeParse(getQuery(event));
  if (!parsed.success) {
    return validateError((_d = (_c = (_b = (_a = parsed.error) == null ? void 0 : _a.issues) == null ? void 0 : _b[0]) == null ? void 0 : _c.message) != null ? _d : "\u53C2\u6570\u6821\u9A8C\u5931\u8D25", 400);
  }
  const { page, pageSize, status, source, startDate, endDate } = parsed.data;
  const offset = (page - 1) * pageSize;
  const where = [];
  const listParams = [];
  const countParams = [];
  if (status) {
    where.push("r.status = ?");
    listParams.push(status);
    countParams.push(status);
  }
  if (source === "user") {
    where.push("u.role IS NOT NULL AND u.role != ?");
    listParams.push(ROLE_ADMIN);
    countParams.push(ROLE_ADMIN);
  } else if (source === "admin") {
    where.push("u.role = ?");
    listParams.push(ROLE_ADMIN);
    countParams.push(ROLE_ADMIN);
  }
  if (startDate) {
    where.push("r.createdAt >= ?");
    listParams.push(startDate + " 00:00:00");
    countParams.push(startDate + " 00:00:00");
  }
  if (endDate) {
    where.push("r.createdAt < ?");
    const nextDay = new Date(endDate);
    nextDay.setDate(nextDay.getDate() + 1);
    const nextDayStr = nextDay.toISOString().slice(0, 10);
    listParams.push(nextDayStr + " 00:00:00");
    countParams.push(nextDayStr + " 00:00:00");
  }
  const whereSql = where.length > 0 ? "WHERE " + where.join(" AND ") : "";
  const rows = await query(
    `SELECT r.id, r.title, r.status, r.error_message, r.segment_id,
            r.is_public, r.createdAt,
            COALESCE(u.account, '\u5DF2\u6CE8\u9500\u7528\u6237') AS username,
            u.role
     FROM material_upload_record r
     LEFT JOIN user u ON r.user_id = u.id
     ${whereSql}
     ORDER BY r.createdAt DESC, r.id DESC
     LIMIT ? OFFSET ?`,
    [...listParams, pageSize, offset]
  );
  const countRows = await query(
    `SELECT COUNT(*) AS total
     FROM material_upload_record r
     LEFT JOIN user u ON r.user_id = u.id
     ${whereSql}`,
    countParams
  );
  const total = Number((_f = (_e = countRows[0]) == null ? void 0 : _e.total) != null ? _f : 0);
  const list = rows.map((row) => ({
    id: row.id,
    title: row.title,
    status: row.status,
    error_message: row.error_message,
    segment_id: row.segment_id,
    is_public: row.is_public,
    username: row.username,
    source: row.role === ROLE_ADMIN ? "admin" : "user",
    createdAt: row.createdAt
  }));
  const result = { list, total, page, pageSize };
  return validateSuccess(result, "\u83B7\u53D6\u4E0A\u4F20\u8BB0\u5F55\u5217\u8868\u6210\u529F");
});

export { index_get as default };
//# sourceMappingURL=index.get.mjs.map
