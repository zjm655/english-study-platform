import { c as defineEventHandler, R as ROLE_ADMIN, v as validateError, i as getRouterParam, q as query, e as validateSuccess } from '../../../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/mysql2/promise.js';
import 'node:url';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/zod/index.js';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/jose/dist/webapi/index.js';

const _id__get = defineEventHandler(async (event) => {
  const user = event.context.user;
  if (!user || user.role !== ROLE_ADMIN) {
    return validateError("\u65E0\u7BA1\u7406\u5458\u6743\u9650", 403);
  }
  const id = Number(getRouterParam(event, "id"));
  if (isNaN(id) || id <= 0) return validateError("\u65E0\u6548\u7684\u8BB0\u5F55ID");
  const rows = await query(
    `SELECT r.id, r.user_id, r.title, r.text_content, r.voice,
            r.is_public, r.status, r.error_message, r.segment_id,
            r.createdAt, r.updatedAt,
            COALESCE(u.account, '\u5DF2\u6CE8\u9500\u7528\u6237') AS username,
            u.role
     FROM material_upload_record r
     LEFT JOIN user u ON r.user_id = u.id
     WHERE r.id = ?`,
    [id]
  );
  if (!rows.length) return validateError("\u8BB0\u5F55\u4E0D\u5B58\u5728", 404);
  const row = rows[0];
  const detail = {
    id: row.id,
    user_id: row.user_id,
    title: row.title,
    text_content: row.text_content,
    voice: row.voice,
    is_public: row.is_public,
    status: row.status,
    error_message: row.error_message,
    segment_id: row.segment_id,
    username: row.username,
    source: row.role === ROLE_ADMIN ? "admin" : "user",
    createdAt: row.createdAt,
    updatedAt: row.updatedAt
  };
  return validateSuccess(detail, "\u83B7\u53D6\u8BE6\u60C5\u6210\u529F");
});

export { _id__get as default };
//# sourceMappingURL=_id_.get.mjs.map
