import { c as defineEventHandler, R as ROLE_ADMIN, v as validateError, i as getRouterParam, q as query, w as withTransaction, l as logger, e as validateSuccess } from '../../../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/mysql2/promise.js';
import 'node:url';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/zod/index.js';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/jose/dist/webapi/index.js';

const _id__delete = defineEventHandler(async (event) => {
  var _a, _b;
  const user = event.context.user;
  if (!user || user.role !== ROLE_ADMIN) {
    return validateError("\u65E0\u7BA1\u7406\u5458\u6743\u9650", 403);
  }
  const id = Number(getRouterParam(event, "id"));
  if (isNaN(id) || id <= 0) return validateError("\u65E0\u6548\u7684\u8BB0\u5F55ID");
  const rows = await query(
    "SELECT segment_id FROM material_upload_record WHERE id = ?",
    [id]
  );
  if (!rows.length) return validateError("\u8BB0\u5F55\u4E0D\u5B58\u5728", 404);
  const segmentId = (_b = (_a = rows[0]) == null ? void 0 : _a.segment_id) != null ? _b : null;
  try {
    await withTransaction(async (conn) => {
      if (segmentId) {
        await conn.execute("DELETE FROM segment WHERE id = ?", [segmentId]);
      }
      await conn.execute("DELETE FROM material_upload_record WHERE id = ?", [id]);
    });
  } catch (err) {
    logger.error("[admin material record] \u5220\u9664\u5931\u8D25:", err);
    return validateError("\u5220\u9664\u5931\u8D25\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5", 500);
  }
  return validateSuccess(null, "\u5220\u9664\u6210\u529F");
});

export { _id__delete as default };
//# sourceMappingURL=_id_.delete.mjs.map
