import { c as defineEventHandler, R as ROLE_ADMIN, v as validateError, i as getRouterParam, q as query, e as validateSuccess } from '../../../../_/nitro.mjs';
import { l as logAdminOperation } from '../../../../_/adminLog.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/mysql2/promise.js';
import 'node:url';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/zod/index.js';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/jose/dist/webapi/index.js';

const _segId__delete = defineEventHandler(async (event) => {
  var _a;
  const user = event.context.user;
  if (!user || user.role !== ROLE_ADMIN) {
    return validateError("\u65E0\u7BA1\u7406\u5458\u6743\u9650", 403);
  }
  const segId = Number(getRouterParam(event, "segId"));
  if (!segId || isNaN(segId)) {
    return validateError("\u65E0\u6548\u7684\u7247\u6BB5ID");
  }
  const result = await query(
    "UPDATE segment SET deleted_at = NOW() WHERE id = ? AND deleted_at IS NULL",
    [segId]
  );
  const affectedRows = (_a = result.affectedRows) != null ? _a : 0;
  if (affectedRows === 0) {
    return validateError("\u6750\u6599\u4E0D\u5B58\u5728\u6216\u5DF2\u5220\u9664", 404);
  }
  await logAdminOperation(user.id, "segment.delete", "segment", segId);
  return validateSuccess(null, "\u5220\u9664\u6210\u529F");
});

export { _segId__delete as default };
//# sourceMappingURL=_segId_.delete.mjs.map
