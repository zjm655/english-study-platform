import { c as defineEventHandler, R as ROLE_ADMIN, v as validateError, x as readFormData, y as adminUploadSchema, u as useRuntimeConfig, e as validateSuccess } from '../../../../_/nitro.mjs';
import { p as processAdminMaterial, a as processAdminBatch } from '../../../../_/adminUpload.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/mysql2/promise.js';
import 'node:url';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/zod/index.js';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/jose/dist/webapi/index.js';
import '../../../../_/audioMeta.mjs';
import '../../../../_/request.mjs';
import '../../../../_/fileLogger.mjs';
import 'node:fs/promises';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/ws/wrapper.mjs';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/music-metadata/lib/index.js';
import '../../../../_/oss.mjs';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/ali-oss/lib/client.js';

const upload_post = defineEventHandler(async (event) => {
  var _a, _b, _c, _d, _e;
  const user = event.context.user;
  if (!user || user.role !== ROLE_ADMIN) {
    return validateError("\u65E0\u7BA1\u7406\u5458\u6743\u9650", 403);
  }
  const formData = await readFormData(event);
  const mode = formData.get("mode");
  const unitId = formData.get("unitId");
  const voice = formData.get("voice");
  const isPublic = formData.get("isPublic");
  const parsed = adminUploadSchema.safeParse({ mode, unitId, voice, isPublic });
  if (!parsed.success) {
    return validateError((_d = (_c = (_b = (_a = parsed.error) == null ? void 0 : _a.issues) == null ? void 0 : _b[0]) == null ? void 0 : _c.message) != null ? _d : "\u53C2\u6570\u6821\u9A8C\u5931\u8D25", 400);
  }
  const {
    mode: validMode,
    unitId: validUnitId,
    voice: validVoice,
    isPublic: validIsPublic
  } = parsed.data;
  const { oss } = useRuntimeConfig();
  const bucket = oss.bucket;
  const userId = user.id;
  let results;
  if (validMode === "single") {
    const textContent = formData.get("textContent");
    const title = formData.get("title");
    const audio = formData.get("audio");
    const trimmedText = (_e = textContent == null ? void 0 : textContent.trim()) != null ? _e : "";
    if (trimmedText.length < 10) {
      return validateError("\u6750\u6599\u6587\u672C\u4E0D\u80FD\u5C11\u4E8E10\u4E2A\u5B57\u7B26", 400);
    }
    if (trimmedText.length > 5e3) {
      return validateError("\u6750\u6599\u6587\u672C\u4E0D\u80FD\u8D85\u8FC75000\u4E2A\u5B57\u7B26", 400);
    }
    let audioBuffer;
    let audioFileName;
    if (audio && audio.size > 0) {
      audioBuffer = Buffer.from(await audio.arrayBuffer());
      audioFileName = audio.name;
    }
    const result = await processAdminMaterial({
      userId,
      unitId: validUnitId,
      textContent: trimmedText,
      title,
      voice: validVoice,
      isPublic: validIsPublic,
      bucket,
      audioBuffer,
      audioFileName
    });
    results = [{ ...result, index: 0 }];
  } else {
    const files = formData.getAll("files");
    if (!files.length) {
      return validateError("\u8BF7\u4E0A\u4F20\u81F3\u5C11\u4E00\u4E2A txt \u6587\u4EF6", 400);
    }
    if (files.length > 20) {
      return validateError("\u5355\u6B21\u6279\u91CF\u4E0A\u4F20\u4E0D\u80FD\u8D85\u8FC7 20 \u4E2A\u6587\u4EF6", 400);
    }
    const txtFiles = [];
    for (const file of files) {
      if (!file.name.endsWith(".txt")) continue;
      const content = await file.text();
      txtFiles.push({ name: file.name, content });
    }
    if (!txtFiles.length) {
      return validateError("\u672A\u627E\u5230 txt \u6587\u4EF6", 400);
    }
    results = await processAdminBatch({
      userId,
      unitId: validUnitId,
      voice: validVoice,
      isPublic: validIsPublic,
      bucket,
      files: txtFiles
    });
  }
  const successCount = results.filter((r) => r.success).length;
  const response = {
    results,
    summary: {
      total: results.length,
      success: successCount,
      failed: results.length - successCount
    }
  };
  return validateSuccess(response);
});

export { upload_post as default };
//# sourceMappingURL=upload.post.mjs.map
