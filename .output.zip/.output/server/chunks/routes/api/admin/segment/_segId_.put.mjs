import { c as defineEventHandler, R as ROLE_ADMIN, v as validateError, i as getRouterParam, n as readBody, o as adminSegmentUpdateSchema, q as query, w as withTransaction, l as logger, e as validateSuccess } from '../../../../_/nitro.mjs';
import { l as logAdminOperation } from '../../../../_/adminLog.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/mysql2/promise.js';
import 'node:url';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/zod/index.js';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/jose/dist/webapi/index.js';

const _segId__put = defineEventHandler(async (event) => {
  var _a, _b, _c, _d;
  const user = event.context.user;
  if (!user || user.role !== ROLE_ADMIN) {
    return validateError("\u65E0\u7BA1\u7406\u5458\u6743\u9650", 403);
  }
  const segId = Number(getRouterParam(event, "segId"));
  if (!segId || isNaN(segId)) {
    return validateError("\u65E0\u6548\u7684\u7247\u6BB5ID");
  }
  const body = await readBody(event);
  const parsed = adminSegmentUpdateSchema.safeParse(body);
  if (!parsed.success) {
    return validateError((_d = (_c = (_b = (_a = parsed.error) == null ? void 0 : _a.issues) == null ? void 0 : _b[0]) == null ? void 0 : _c.message) != null ? _d : "\u53C2\u6570\u6821\u9A8C\u5931\u8D25", 400);
  }
  const { title, textContent, translation, questions, vocabulary, isPublic } = parsed.data;
  const existing = await query(
    "SELECT id, is_public FROM segment WHERE id = ? AND deleted_at IS NULL",
    [segId]
  );
  if (existing.length === 0) {
    return validateError("\u6750\u6599\u4E0D\u5B58\u5728\u6216\u5DF2\u5220\u9664", 404);
  }
  const finalIsPublic = isPublic != null ? isPublic : existing[0].is_public;
  const finalTranslation = translation == null || translation === "" ? null : translation;
  const finalQuestions = questions == null || questions.length === 0 ? null : JSON.stringify(questions);
  try {
    await withTransaction(async (conn) => {
      var _a2, _b2, _c2, _d2;
      await conn.execute(
        `UPDATE segment
         SET title = ?, textContent = ?, translation = ?, questions = ?, is_public = ?
         WHERE id = ? AND deleted_at IS NULL`,
        [title, textContent, finalTranslation, finalQuestions, finalIsPublic, segId]
      );
      if (vocabulary != null) {
        const keepIds = vocabulary.filter((v) => v.id != null).map((v) => v.id);
        if (keepIds.length > 0) {
          const placeholders = keepIds.map(() => "?").join(", ");
          await conn.execute(
            `DELETE FROM vocabulary WHERE segment_id = ? AND id NOT IN (${placeholders})`,
            [segId, ...keepIds]
          );
        } else {
          await conn.execute("DELETE FROM vocabulary WHERE segment_id = ?", [segId]);
        }
        for (let i = 0; i < vocabulary.length; i++) {
          const v = vocabulary[i];
          const forms = (_a2 = v.forms) != null ? _a2 : null;
          const phonetic = (_b2 = v.phonetic) != null ? _b2 : null;
          const exampleSentence = (_c2 = v.exampleSentence) != null ? _c2 : null;
          const exampleTranslation = (_d2 = v.exampleTranslation) != null ? _d2 : null;
          if (v.id != null) {
            await conn.execute(
              `UPDATE vocabulary
               SET word = ?, forms = ?, phonetic = ?, meaning = ?,
                   exampleSentence = ?, exampleTranslation = ?, sort_order = ?
               WHERE id = ? AND segment_id = ?`,
              [
                v.word,
                forms,
                phonetic,
                v.meaning,
                exampleSentence,
                exampleTranslation,
                i,
                v.id,
                segId
              ]
            );
          } else {
            await conn.execute(
              `INSERT INTO vocabulary
                 (segment_id, word, forms, phonetic, meaning, exampleSentence, exampleTranslation, sort_order)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
              [segId, v.word, forms, phonetic, v.meaning, exampleSentence, exampleTranslation, i]
            );
          }
        }
      }
    });
  } catch (err) {
    logger.error("[admin segment] \u7F16\u8F91\u5931\u8D25:", err);
    return validateError("\u4FDD\u5B58\u5931\u8D25\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5", 500);
  }
  await logAdminOperation(user.id, "segment.update", "segment", segId, { title });
  return validateSuccess(null, "\u4FDD\u5B58\u6210\u529F");
});

export { _segId__put as default };
//# sourceMappingURL=_segId_.put.mjs.map
