import { c as defineEventHandler, R as ROLE_ADMIN, v as validateError, i as getRouterParam, q as query, e as validateSuccess } from '../../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/mysql2/promise.js';
import 'node:url';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/zod/index.js';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/jose/dist/webapi/index.js';

const _segId__get = defineEventHandler(async (event) => {
  var _a;
  const user = event.context.user;
  if (!user || user.role !== ROLE_ADMIN) {
    return validateError("\u65E0\u7BA1\u7406\u5458\u6743\u9650", 403);
  }
  const segId = Number(getRouterParam(event, "segId"));
  if (!segId || isNaN(segId)) {
    return validateError("\u65E0\u6548\u7684\u7247\u6BB5ID");
  }
  const segments = await query(
    `SELECT s.*, u.title AS unitTitle
     FROM segment s
     LEFT JOIN unit u ON s.unit_id = u.id
     WHERE s.id = ? AND s.deleted_at IS NULL`,
    [segId]
  );
  const segment = segments[0];
  if (!segment) {
    return validateError("\u6750\u6599\u4E0D\u5B58\u5728\u6216\u5DF2\u5220\u9664", 404);
  }
  const vocabRows = await query(
    "SELECT * FROM vocabulary WHERE segment_id = ? ORDER BY sort_order",
    [segId]
  );
  const vocabulary = vocabRows.map((v) => ({
    id: v.id,
    word: v.word,
    forms: v.forms,
    phonetic: v.phonetic,
    meaning: v.meaning,
    exampleSentence: v.exampleSentence,
    exampleTranslation: v.exampleTranslation
  }));
  const questions = Array.isArray(segment.questions) ? segment.questions : segment.questions ? JSON.parse(segment.questions) : [];
  const detail = {
    id: segment.id,
    title: segment.title,
    textContent: segment.textContent,
    translation: segment.translation,
    questions,
    isPublic: segment.is_public,
    unitId: segment.unit_id,
    unitTitle: (_a = segment.unitTitle) != null ? _a : "",
    vocabulary
  };
  return validateSuccess(detail, "\u83B7\u53D6\u6750\u6599\u8BE6\u60C5\u6210\u529F");
});

export { _segId__get as default };
//# sourceMappingURL=_segId_.get.mjs.map
