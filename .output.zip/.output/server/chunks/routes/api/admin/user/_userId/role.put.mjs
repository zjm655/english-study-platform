import { c as defineEventHandler, R as ROLE_ADMIN, v as validateError, i as getRouterParam, n as readBody, C as adminUserRoleSchema, q as query, e as validateSuccess } from '../../../../../_/nitro.mjs';
import { l as logAdminOperation } from '../../../../../_/adminLog.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/mysql2/promise.js';
import 'node:url';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/zod/index.js';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/jose/dist/webapi/index.js';

const role_put = defineEventHandler(async (event) => {
  var _a, _b, _c, _d, _e, _f;
  const user = event.context.user;
  if (!user || user.role !== ROLE_ADMIN) {
    return validateError("\u65E0\u7BA1\u7406\u5458\u6743\u9650", 403);
  }
  const userId = Number(getRouterParam(event, "userId"));
  if (!userId || isNaN(userId)) {
    return validateError("\u65E0\u6548\u7684\u7528\u6237ID");
  }
  const body = await readBody(event);
  const parsed = adminUserRoleSchema.safeParse(body);
  if (!parsed.success) {
    return validateError((_d = (_c = (_b = (_a = parsed.error) == null ? void 0 : _a.issues) == null ? void 0 : _b[0]) == null ? void 0 : _c.message) != null ? _d : "\u53C2\u6570\u6821\u9A8C\u5931\u8D25", 400);
  }
  const { role: targetRole } = parsed.data;
  if (userId === user.id) {
    return validateError("\u4E0D\u80FD\u4FEE\u6539\u81EA\u5DF1\u7684\u89D2\u8272", 400);
  }
  const targetRows = await query(
    "SELECT role FROM user WHERE id = ? AND deleted_at IS NULL",
    [userId]
  );
  if (targetRows.length === 0) {
    return validateError("\u7528\u6237\u4E0D\u5B58\u5728\u6216\u5DF2\u6CE8\u9500", 404);
  }
  const currentRole = targetRows[0].role;
  if (currentRole === targetRole) {
    return validateError("\u89D2\u8272\u65E0\u9700\u53D8\u66F4", 400);
  }
  if (currentRole === ROLE_ADMIN && targetRole === 0) {
    const countRows = await query(
      "SELECT COUNT(*) AS cnt FROM user WHERE role = 1 AND deleted_at IS NULL AND status = 1"
    );
    if (Number((_f = (_e = countRows[0]) == null ? void 0 : _e.cnt) != null ? _f : 0) <= 1) {
      return validateError("\u5FC5\u987B\u4FDD\u7559\u81F3\u5C11\u4E00\u4F4D\u7BA1\u7406\u5458\uFF0C\u65E0\u6CD5\u964D\u6743", 400);
    }
  }
  await query("UPDATE user SET role = ? WHERE id = ?", [targetRole, userId]);
  await logAdminOperation(user.id, "user.role.update", "user", userId, {
    before: currentRole,
    after: targetRole
  });
  const actionText = targetRole === ROLE_ADMIN ? "\u5DF2\u63D0\u5347\u4E3A\u7BA1\u7406\u5458" : "\u5DF2\u964D\u7EA7\u4E3A\u666E\u901A\u7528\u6237";
  return validateSuccess(null, actionText);
});

export { role_put as default };
//# sourceMappingURL=role.put.mjs.map
