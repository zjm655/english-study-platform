import { c as defineEventHandler, R as ROLE_ADMIN, v as validateError, i as getRouterParam, n as readBody, D as adminUserStatusSchema, q as query, e as validateSuccess } from '../../../../../_/nitro.mjs';
import { l as logAdminOperation } from '../../../../../_/adminLog.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/mysql2/promise.js';
import 'node:url';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/zod/index.js';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/jose/dist/webapi/index.js';

const status_put = defineEventHandler(async (event) => {
  var _a, _b, _c, _d, _e;
  const user = event.context.user;
  if (!user || user.role !== ROLE_ADMIN) {
    return validateError("\u65E0\u7BA1\u7406\u5458\u6743\u9650", 403);
  }
  const userId = Number(getRouterParam(event, "userId"));
  if (!userId || isNaN(userId)) {
    return validateError("\u65E0\u6548\u7684\u7528\u6237ID");
  }
  const body = await readBody(event);
  const parsed = adminUserStatusSchema.safeParse(body);
  if (!parsed.success) {
    return validateError((_d = (_c = (_b = (_a = parsed.error) == null ? void 0 : _a.issues) == null ? void 0 : _b[0]) == null ? void 0 : _c.message) != null ? _d : "\u53C2\u6570\u6821\u9A8C\u5931\u8D25", 400);
  }
  const { status } = parsed.data;
  if (userId === user.id) {
    return validateError(status === 0 ? "\u4E0D\u80FD\u5C01\u7981\u81EA\u5DF1" : "\u4E0D\u80FD\u5BF9\u81EA\u5DF1\u6267\u884C\u6B64\u64CD\u4F5C", 400);
  }
  const targetRows = await query(
    "SELECT id, role, status, account FROM user WHERE id = ? AND deleted_at IS NULL",
    [userId]
  );
  if (targetRows.length === 0) {
    return validateError("\u7528\u6237\u4E0D\u5B58\u5728\u6216\u5DF2\u6CE8\u9500", 404);
  }
  const target = targetRows[0];
  if (target.role === ROLE_ADMIN) {
    return validateError("\u4E0D\u80FD\u5BF9\u7BA1\u7406\u5458\u6267\u884C\u6B64\u64CD\u4F5C", 400);
  }
  if (target.status === status) {
    return validateError(status === 0 ? "\u8BE5\u7528\u6237\u5DF2\u5904\u4E8E\u5C01\u7981\u72B6\u6001" : "\u8BE5\u7528\u6237\u5DF2\u5904\u4E8E\u6B63\u5E38\u72B6\u6001", 400);
  }
  const result = await query(
    "UPDATE user SET status = ? WHERE id = ? AND deleted_at IS NULL",
    [status, userId]
  );
  const affectedRows = (_e = result.affectedRows) != null ? _e : 0;
  if (affectedRows === 0) {
    return validateError("\u64CD\u4F5C\u5931\u8D25\uFF0C\u7528\u6237\u53EF\u80FD\u5DF2\u6CE8\u9500", 400);
  }
  const action = status === 0 ? "user.ban" : "user.unban";
  await logAdminOperation(user.id, action, "user", userId, { account: target.account, status });
  return validateSuccess(null, status === 0 ? "\u5C01\u7981\u6210\u529F" : "\u89E3\u5C01\u6210\u529F");
});

export { status_put as default };
//# sourceMappingURL=status.put.mjs.map
