import { c as defineEventHandler, R as ROLE_ADMIN, v as validateError, i as getRouterParam, q as query, e as validateSuccess } from '../../../../_/nitro.mjs';
import { l as logAdminOperation } from '../../../../_/adminLog.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/mysql2/promise.js';
import 'node:url';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/zod/index.js';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/jose/dist/webapi/index.js';

const _userId__delete = defineEventHandler(async (event) => {
  var _a;
  const user = event.context.user;
  if (!user || user.role !== ROLE_ADMIN) {
    return validateError("\u65E0\u7BA1\u7406\u5458\u6743\u9650", 403);
  }
  const userId = Number(getRouterParam(event, "userId"));
  if (!userId || isNaN(userId)) {
    return validateError("\u65E0\u6548\u7684\u7528\u6237ID");
  }
  if (userId === user.id) {
    return validateError("\u4E0D\u80FD\u9500\u53F7\u81EA\u5DF1", 400);
  }
  const targetRows = await query(
    "SELECT id, role, account FROM user WHERE id = ? AND deleted_at IS NULL",
    [userId]
  );
  if (targetRows.length === 0) {
    return validateError("\u7528\u6237\u4E0D\u5B58\u5728\u6216\u5DF2\u6CE8\u9500", 404);
  }
  const target = targetRows[0];
  if (target.role === ROLE_ADMIN) {
    return validateError("\u4E0D\u80FD\u9500\u53F7\u7BA1\u7406\u5458", 400);
  }
  const result = await query(
    "UPDATE user SET deleted_at = NOW() WHERE id = ? AND deleted_at IS NULL",
    [userId]
  );
  const affectedRows = (_a = result.affectedRows) != null ? _a : 0;
  if (affectedRows === 0) {
    return validateError("\u7528\u6237\u4E0D\u5B58\u5728\u6216\u5DF2\u6CE8\u9500", 404);
  }
  await logAdminOperation(user.id, "user.delete", "user", userId, { account: target.account });
  return validateSuccess(null, "\u9500\u53F7\u6210\u529F");
});

export { _userId__delete as default };
//# sourceMappingURL=_userId_.delete.mjs.map
