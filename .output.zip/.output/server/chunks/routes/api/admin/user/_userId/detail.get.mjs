import { c as defineEventHandler, R as ROLE_ADMIN, v as validateError, i as getRouterParam, q as query, e as validateSuccess } from '../../../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/mysql2/promise.js';
import 'node:url';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/zod/index.js';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/jose/dist/webapi/index.js';

const detail_get = defineEventHandler(async (event) => {
  var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k;
  const user = event.context.user;
  if (!user || user.role !== ROLE_ADMIN) {
    return validateError("\u65E0\u7BA1\u7406\u5458\u6743\u9650", 403);
  }
  const userId = Number(getRouterParam(event, "userId"));
  if (!userId || isNaN(userId)) {
    return validateError("\u65E0\u6548\u7684\u7528\u6237ID");
  }
  const userRows = await query(
    "SELECT id, account, nickname, email, role, level, status, deleted_at AS deletedAt, createdAt FROM user WHERE id = ?",
    [userId]
  );
  if (userRows.length === 0) {
    return validateError("\u7528\u6237\u4E0D\u5B58\u5728", 404);
  }
  const targetUser = userRows[0];
  const statsPromise = query(
    `SELECT
       (SELECT COUNT(*) FROM user_progress WHERE user_id = ? AND phase2_done = 1 AND deleted_at IS NULL) AS totalSegmentsCompleted,
       (SELECT COUNT(*) FROM recording WHERE user_id = ? AND deleted_at IS NULL) AS totalRecordings,
       (SELECT ROUND(AVG(score), 1) FROM recording WHERE user_id = ? AND score IS NOT NULL AND deleted_at IS NULL) AS avgScore`,
    [userId, userId, userId]
  );
  const checkinPromise = query(
    "SELECT total_study_seconds AS totalStudySeconds, total_checkin_days AS totalCheckinDays, current_streak_days AS currentStreak FROM user_checkin_stats WHERE user_id = ?",
    [userId]
  );
  const progressPromise = query(
    `SELECT
       s.id AS segmentId, s.title AS segmentTitle,
       u.id AS unitId, u.title AS unitTitle,
       COALESCE(up.phase1_done, 0) AS phase1Done,
       COALESCE(up.phase2_done, 0) AS phase2Done,
       COALESCE(up.phase3_done, 0) AS phase3Done,
       COALESCE(up.phase4_done, 0) AS phase4Done,
       up.phase3_score AS phase3Score,
       up.phase4_score AS phase4Score
     FROM segment s
     JOIN unit u ON s.unit_id = u.id
     LEFT JOIN user_progress up ON up.segment_id = s.id AND up.user_id = ?
     WHERE s.deleted_at IS NULL
     ORDER BY u.sort_order, s.sort_order`,
    [userId]
  );
  const recordingsPromise = query(
    `SELECT r.id, r.phase, r.score, r.duration, s.title AS segmentTitle, r.createdAt
     FROM recording r
     JOIN segment s ON r.segment_id = s.id
     WHERE r.user_id = ? AND r.deleted_at IS NULL
     ORDER BY r.createdAt DESC
     LIMIT 20`,
    [userId]
  );
  const [statsRows, checkinRows, progressRows, recordingRows] = await Promise.all([
    statsPromise,
    checkinPromise,
    progressPromise,
    recordingsPromise
  ]);
  const stats = {
    totalSegmentsCompleted: Number((_b = (_a = statsRows[0]) == null ? void 0 : _a.totalSegmentsCompleted) != null ? _b : 0),
    totalRecordings: Number((_d = (_c = statsRows[0]) == null ? void 0 : _c.totalRecordings) != null ? _d : 0),
    avgScore: ((_e = statsRows[0]) == null ? void 0 : _e.avgScore) != null ? Number(statsRows[0].avgScore) : null,
    totalStudySeconds: Number((_g = (_f = checkinRows[0]) == null ? void 0 : _f.totalStudySeconds) != null ? _g : 0),
    totalCheckinDays: Number((_i = (_h = checkinRows[0]) == null ? void 0 : _h.totalCheckinDays) != null ? _i : 0),
    currentStreak: Number((_k = (_j = checkinRows[0]) == null ? void 0 : _j.currentStreak) != null ? _k : 0)
  };
  const unitMap = /* @__PURE__ */ new Map();
  for (const row of progressRows) {
    if (!unitMap.has(row.unitId)) {
      unitMap.set(row.unitId, {
        unitId: row.unitId,
        unitTitle: row.unitTitle,
        segments: []
      });
    }
    unitMap.get(row.unitId).segments.push({
      segmentId: row.segmentId,
      segmentTitle: row.segmentTitle,
      phase1Done: row.phase1Done === 1,
      phase2Done: row.phase2Done === 1,
      phase3Done: row.phase3Done === 1,
      phase4Done: row.phase4Done === 1,
      phase3Score: row.phase3Score,
      phase4Score: row.phase4Score
    });
  }
  const recordings = recordingRows.map((r) => ({
    id: r.id,
    phase: r.phase,
    score: r.score,
    duration: r.duration,
    segmentTitle: r.segmentTitle,
    createdAt: r.createdAt
  }));
  const result = {
    user: targetUser,
    stats,
    unitProgress: Array.from(unitMap.values()),
    recentRecordings: recordings
  };
  return validateSuccess(result, "\u83B7\u53D6\u7528\u6237\u8BE6\u60C5\u6210\u529F");
});

export { detail_get as default };
//# sourceMappingURL=detail.get.mjs.map
