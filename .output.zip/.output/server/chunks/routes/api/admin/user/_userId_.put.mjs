import { c as defineEventHandler, R as ROLE_ADMIN, v as validateError, i as getRouterParam, n as readBody, A as adminUserUpdateSchema, q as query, e as validateSuccess } from '../../../../_/nitro.mjs';
import { l as logAdminOperation } from '../../../../_/adminLog.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/mysql2/promise.js';
import 'node:url';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/zod/index.js';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/jose/dist/webapi/index.js';

const _userId__put = defineEventHandler(async (event) => {
  var _a, _b, _c, _d;
  const user = event.context.user;
  if (!user || user.role !== ROLE_ADMIN) {
    return validateError("\u65E0\u7BA1\u7406\u5458\u6743\u9650", 403);
  }
  const userId = Number(getRouterParam(event, "userId"));
  if (!userId || isNaN(userId)) {
    return validateError("\u65E0\u6548\u7684\u7528\u6237ID");
  }
  const body = await readBody(event);
  const parsed = adminUserUpdateSchema.safeParse(body);
  if (!parsed.success) {
    return validateError((_d = (_c = (_b = (_a = parsed.error) == null ? void 0 : _a.issues) == null ? void 0 : _b[0]) == null ? void 0 : _c.message) != null ? _d : "\u53C2\u6570\u6821\u9A8C\u5931\u8D25", 400);
  }
  const { nickname, email, level } = parsed.data;
  const targetRows = await query("SELECT id, nickname, email, level FROM user WHERE id = ? AND deleted_at IS NULL", [userId]);
  if (targetRows.length === 0) {
    return validateError("\u7528\u6237\u4E0D\u5B58\u5728\u6216\u5DF2\u6CE8\u9500", 404);
  }
  const target = targetRows[0];
  if (email !== void 0 && email != null && email !== target.email) {
    const dup = await query("SELECT id FROM user WHERE email = ? AND id != ?", [
      email,
      userId
    ]);
    if (dup.length > 0) {
      return validateError("\u8BE5\u90AE\u7BB1\u5DF2\u88AB\u5176\u4ED6\u7528\u6237\u4F7F\u7528", 400);
    }
  }
  const sets = [];
  const params = [];
  const before = {};
  const after = {};
  if (nickname !== void 0) {
    sets.push("nickname = ?");
    params.push(nickname);
    before.nickname = target.nickname;
    after.nickname = nickname;
  }
  if (email !== void 0) {
    sets.push("email = ?");
    params.push(email);
    before.email = target.email;
    after.email = email;
  }
  if (level !== void 0) {
    sets.push("level = ?");
    params.push(level);
    before.level = target.level;
    after.level = level;
  }
  if (sets.length === 0) {
    return validateError("\u6CA1\u6709\u9700\u8981\u4FEE\u6539\u7684\u5B57\u6BB5", 400);
  }
  await query(`UPDATE user SET ${sets.join(", ")} WHERE id = ?`, [...params, userId]);
  await logAdminOperation(user.id, "user.update", "user", userId, { before, after });
  return validateSuccess(null, "\u4FEE\u6539\u6210\u529F");
});

export { _userId__put as default };
//# sourceMappingURL=_userId_.put.mjs.map
