import { c as defineEventHandler, R as ROLE_ADMIN, v as validateError, m as adminOperationLogListSchema, g as getQuery, q as query, e as validateSuccess } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/mysql2/promise.js';
import 'node:url';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/zod/index.js';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/jose/dist/webapi/index.js';

const index_get = defineEventHandler(async (event) => {
  var _a, _b, _c, _d, _e, _f;
  const user = event.context.user;
  if (!user || user.role !== ROLE_ADMIN) {
    return validateError("\u65E0\u7BA1\u7406\u5458\u6743\u9650", 403);
  }
  const parsed = adminOperationLogListSchema.safeParse(getQuery(event));
  if (!parsed.success) {
    return validateError((_d = (_c = (_b = (_a = parsed.error) == null ? void 0 : _a.issues) == null ? void 0 : _b[0]) == null ? void 0 : _c.message) != null ? _d : "\u53C2\u6570\u6821\u9A8C\u5931\u8D25", 400);
  }
  const { page, pageSize, action, keyword } = parsed.data;
  const offset = (page - 1) * pageSize;
  const where = [];
  const params = [];
  if (action) {
    where.push("ol.action = ?");
    params.push(action);
  }
  if (keyword) {
    where.push("(ol.target_type LIKE ? OR CAST(ol.target_id AS CHAR) LIKE ?)");
    params.push(`%${keyword}%`, `%${keyword}%`);
  }
  const whereSql = where.length > 0 ? `WHERE ${where.join(" AND ")}` : "";
  const list = await query(
    `SELECT ol.id, ol.action, ol.target_type AS targetType, ol.target_id AS targetId,
            ol.detail, ol.createdAt, u.account AS adminAccount
     FROM admin_operation_log ol
     LEFT JOIN user u ON ol.admin_id = u.id
     ${whereSql}
     ORDER BY ol.createdAt DESC
     LIMIT ? OFFSET ?`,
    [...params, pageSize, offset]
  );
  const countRows = await query(
    `SELECT COUNT(*) AS total FROM admin_operation_log ol ${whereSql}`,
    params
  );
  const result = {
    list,
    total: Number((_f = (_e = countRows[0]) == null ? void 0 : _e.total) != null ? _f : 0),
    page,
    pageSize
  };
  return validateSuccess(result, "\u83B7\u53D6\u64CD\u4F5C\u65E5\u5FD7\u6210\u529F");
});

export { index_get as default };
//# sourceMappingURL=index.get.mjs.map
