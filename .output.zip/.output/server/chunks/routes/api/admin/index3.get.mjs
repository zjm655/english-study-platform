import { c as defineEventHandler, R as ROLE_ADMIN, v as validateError, h as adminStatsQuerySchema, g as getQuery, q as query, e as validateSuccess } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/mysql2/promise.js';
import 'node:url';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/zod/index.js';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/jose/dist/webapi/index.js';

const index_get = defineEventHandler(async (event) => {
  var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l;
  const user = event.context.user;
  if (!user || user.role !== ROLE_ADMIN) {
    return validateError("\u65E0\u7BA1\u7406\u5458\u6743\u9650", 403);
  }
  const parsed = adminStatsQuerySchema.safeParse(getQuery(event));
  if (!parsed.success) {
    return validateError((_d = (_c = (_b = (_a = parsed.error) == null ? void 0 : _a.issues) == null ? void 0 : _b[0]) == null ? void 0 : _c.message) != null ? _d : "\u53C2\u6570\u6821\u9A8C\u5931\u8D25", 400);
  }
  const { days } = parsed.data;
  const rangeCond = "createdAt >= DATE_SUB(CURDATE(), INTERVAL ? DAY)";
  const summaryRows = await query(
    `SELECT
       COUNT(*) AS totalCalls,
       ROUND(AVG(duration_ms)) AS avgDuration,
       ROUND(SUM(status_code >= 400) / COUNT(*) * 100, 2) AS errorRate,
       ROUND(SUM(business_code IS NOT NULL AND business_code != 200)
             / NULLIF(SUM(business_code IS NOT NULL), 0) * 100, 2) AS businessErrorRate,
       COUNT(DISTINCT user_id) AS activeUsers,
       SUM(user_id IS NULL) AS unauthCalls,
       SUM(createdAt >= CURDATE()) AS todayCalls
     FROM api_call_log
     WHERE ${rangeCond}`,
    [days]
  );
  const s = (_e = summaryRows[0]) != null ? _e : {};
  const summary = {
    totalCalls: Number((_f = s.totalCalls) != null ? _f : 0),
    todayCalls: Number((_g = s.todayCalls) != null ? _g : 0),
    errorRate: Number((_h = s.errorRate) != null ? _h : 0),
    businessErrorRate: Number((_i = s.businessErrorRate) != null ? _i : 0),
    avgDuration: Number((_j = s.avgDuration) != null ? _j : 0),
    activeUsers: Number((_k = s.activeUsers) != null ? _k : 0),
    unauthCalls: Number((_l = s.unauthCalls) != null ? _l : 0)
  };
  const trendRows = await query(
    `SELECT DATE_FORMAT(createdAt, '%Y-%m-%d') AS date,
            COUNT(*) AS count,
            SUM(status_code >= 400) AS errorCount,
            ROUND(AVG(duration_ms)) AS avgDuration
     FROM api_call_log
     WHERE ${rangeCond}
     GROUP BY DATE_FORMAT(createdAt, '%Y-%m-%d')
     ORDER BY date ASC`,
    [days]
  );
  const dailyTrend = trendRows.map((r) => ({
    date: String(r.date),
    count: Number(r.count),
    errorCount: Number(r.errorCount),
    avgDuration: Number(r.avgDuration)
  }));
  const topRows = await query(
    `SELECT path, method, COUNT(*) AS count, ROUND(AVG(duration_ms)) AS avgDuration
     FROM api_call_log
     WHERE ${rangeCond}
     GROUP BY path, method
     ORDER BY count DESC
     LIMIT 10`,
    [days]
  );
  const topPaths = topRows.map((r) => ({
    path: String(r.path),
    method: String(r.method),
    count: Number(r.count),
    avgDuration: Number(r.avgDuration)
  }));
  const errRows = await query(
    `SELECT path, method, COUNT(*) AS count, ROUND(AVG(duration_ms)) AS avgDuration
     FROM api_call_log
     WHERE ${rangeCond} AND status_code >= 400
     GROUP BY path, method
     ORDER BY count DESC
     LIMIT 10`,
    [days]
  );
  const errorPaths = errRows.map((r) => ({
    path: String(r.path),
    method: String(r.method),
    count: Number(r.count),
    avgDuration: Number(r.avgDuration)
  }));
  const result = { summary, dailyTrend, topPaths, errorPaths };
  return validateSuccess(result, "\u83B7\u53D6\u8FD0\u8425\u7EDF\u8BA1\u6210\u529F");
});

export { index_get as default };
//# sourceMappingURL=index3.get.mjs.map
