import { c as defineEventHandler, R as ROLE_ADMIN, v as validateError, h as adminStatsQuerySchema, g as getQuery, e as validateSuccess } from '../../../../_/nitro.mjs';
import { e as estimateServiceUsage } from '../../../../_/cloudEstimate.mjs';
import { g as getOssBucketStat } from '../../../../_/oss.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/mysql2/promise.js';
import 'node:url';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/zod/index.js';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/jose/dist/webapi/index.js';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/ali-oss/lib/client.js';
import '../../../../_/fileLogger.mjs';
import 'node:fs/promises';

const oss_get = defineEventHandler(async (event) => {
  var _a, _b, _c, _d;
  const user = event.context.user;
  if (!user || user.role !== ROLE_ADMIN) {
    return validateError("\u65E0\u7BA1\u7406\u5458\u6743\u9650", 403);
  }
  const parsed = adminStatsQuerySchema.safeParse(getQuery(event));
  if (!parsed.success) {
    return validateError((_d = (_c = (_b = (_a = parsed.error) == null ? void 0 : _a.issues) == null ? void 0 : _b[0]) == null ? void 0 : _c.message) != null ? _d : "\u53C2\u6570\u6821\u9A8C\u5931\u8D25", 400);
  }
  const { days } = parsed.data;
  const [estimate, bucketStat] = await Promise.all([
    estimateServiceUsage("oss", days),
    getOssBucketStat()
  ]);
  return validateSuccess({ estimate, bucketStat }, "\u83B7\u53D6 OSS \u7528\u91CF\u6570\u636E\u6210\u529F");
});

export { oss_get as default };
//# sourceMappingURL=oss.get.mjs.map
