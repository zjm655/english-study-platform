import { u as useRuntimeConfig, l as logger, f as logCloudServiceCall, c as defineEventHandler, R as ROLE_ADMIN, v as validateError, e as validateSuccess } from '../../../../_/nitro.mjs';
import { s as serverFetch } from '../../../../_/request.mjs';
import { f as fileLogError, a as fileLog } from '../../../../_/fileLogger.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/mysql2/promise.js';
import 'node:url';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/zod/index.js';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/jose/dist/webapi/index.js';
import 'node:fs/promises';

const CACHE_TTL = 5 * 60 * 1e3;
let cached = null;
async function getDeepSeekBalance() {
  var _a, _b, _c, _d;
  if (cached && Date.now() < cached.expireAt) {
    return cached.data;
  }
  const config = useRuntimeConfig();
  const ds = config.deepseek;
  if (!(ds == null ? void 0 : ds.apiKey) || !(ds == null ? void 0 : ds.baseUrl)) {
    return { success: false, error: "DeepSeek \u914D\u7F6E\u7F3A\u5931\uFF08apiKey / baseUrl\uFF09" };
  }
  const url = `${ds.baseUrl.replace(/\/+$/, "")}/user/balance`;
  let callStart = 0;
  try {
    callStart = Date.now();
    const resp = await serverFetch(url, {
      method: "GET",
      headers: {
        Accept: "application/json",
        Authorization: `Bearer ${ds.apiKey}`
      },
      timeout: 1e4,
      tag: "[deepseek]"
    });
    if (!resp.ok) {
      const body = await resp.text();
      logger.error(`[deepseek] \u4F59\u989D\u67E5\u8BE2\u8FD4\u56DE ${resp.status}: ${body}`);
      fileLogError("ai", "[deepseek] \u4F59\u989D\u67E5\u8BE2\u5931\u8D25", `HTTP ${resp.status}`);
      void logCloudServiceCall({
        service: "deepseek",
        operation: "checkBalance",
        success: false,
        durationMs: Date.now() - callStart,
        errorMessage: `HTTP ${resp.status}`
      });
      return { success: false, error: `DeepSeek API \u8FD4\u56DE ${resp.status}` };
    }
    const data = await resp.json();
    const balances = Array.isArray(data.balance_infos) ? data.balance_infos.map((b) => {
      var _a2, _b2, _c2, _d2;
      return {
        currency: (_a2 = b.currency) != null ? _a2 : "CNY",
        totalBalance: (_b2 = b.total_balance) != null ? _b2 : "0",
        grantedBalance: (_c2 = b.granted_balance) != null ? _c2 : "0",
        toppedUpBalance: (_d2 = b.topped_up_balance) != null ? _d2 : "0"
      };
    }) : [];
    const result = {
      success: true,
      isAvailable: (_a = data.is_available) != null ? _a : true,
      balances
    };
    cached = { data: result, expireAt: Date.now() + CACHE_TTL };
    fileLog("ai", "info", "[deepseek] \u4F59\u989D\u67E5\u8BE2\u6210\u529F", {
      isAvailable: result.isAvailable,
      count: balances.length
    });
    void logCloudServiceCall({
      service: "deepseek",
      operation: "checkBalance",
      success: true,
      durationMs: Date.now() - callStart
    });
    return result;
  } catch (err) {
    const e = err;
    void logCloudServiceCall({
      service: "deepseek",
      operation: "checkBalance",
      success: false,
      durationMs: callStart ? Date.now() - callStart : 0,
      errorMessage: String((_b = e == null ? void 0 : e.message) != null ? _b : err).substring(0, 500)
    });
    logger.error("[deepseek] \u4F59\u989D\u67E5\u8BE2\u5F02\u5E38:", err);
    fileLogError("ai", "[deepseek] \u4F59\u989D\u67E5\u8BE2\u5F02\u5E38", (_c = e == null ? void 0 : e.message) != null ? _c : String(err));
    return {
      success: false,
      error: ((_d = e == null ? void 0 : e.message) == null ? void 0 : _d.includes("timeout")) ? "DeepSeek \u4F59\u989D\u67E5\u8BE2\u8D85\u65F6" : "DeepSeek \u4F59\u989D\u67E5\u8BE2\u5931\u8D25"
    };
  }
}

const deepseek_get = defineEventHandler(async (event) => {
  const user = event.context.user;
  if (!user || user.role !== ROLE_ADMIN) {
    return validateError("\u65E0\u7BA1\u7406\u5458\u6743\u9650", 403);
  }
  const balance = await getDeepSeekBalance();
  return validateSuccess(
    { balance },
    balance.success ? "\u83B7\u53D6 DeepSeek \u4F59\u989D\u6210\u529F" : "DeepSeek \u4F59\u989D\u6682\u4E0D\u53EF\u7528"
  );
});

export { deepseek_get as default };
//# sourceMappingURL=deepseek.get.mjs.map
