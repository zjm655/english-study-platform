import { c as defineEventHandler, g as getQuery, v as validateError, q as query, e as validateSuccess } from '../../../../_/nitro.mjs';
import { z } from 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/zod/index.js';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/mysql2/promise.js';
import 'node:url';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/jose/dist/webapi/index.js';

const querySchema = z.object({
  service: z.enum(["oss", "nls", "deepseek"]),
  days: z.coerce.number().int().min(1).max(90).default(7)
});
const trend_get = defineEventHandler(async (event) => {
  const parsed = querySchema.safeParse(getQuery(event));
  if (!parsed.success) {
    return validateError("\u53C2\u6570\u9519\u8BEF\uFF1Aservice \u9700\u4E3A oss/nls/deepseek\uFF0Cdays \u9700\u4E3A 1-90");
  }
  const { service, days } = parsed.data;
  const rows = await query(
    `SELECT DATE(createdAt) as date,
            COUNT(*) as call_count,
            COALESCE(SUM(duration_ms), 0) as total_duration,
            COALESCE(SUM(total_tokens), 0) as total_tokens
     FROM cloud_service_call_log
     WHERE service = ? AND success = 1 AND createdAt >= DATE_SUB(CURDATE(), INTERVAL ? DAY)
     GROUP BY DATE(createdAt)
     ORDER BY date ASC`,
    [service, days]
  );
  const dates = [];
  const callCounts = [];
  const totalDurations = [];
  const totalTokens = [];
  for (const row of rows) {
    dates.push(row.date);
    callCounts.push(Number(row.call_count));
    totalDurations.push(Number(row.total_duration));
    totalTokens.push(Number(row.total_tokens));
  }
  return validateSuccess({
    service,
    days,
    dates,
    callCounts,
    totalDurations,
    totalTokens
  });
});

export { trend_get as default };
//# sourceMappingURL=trend.get.mjs.map
