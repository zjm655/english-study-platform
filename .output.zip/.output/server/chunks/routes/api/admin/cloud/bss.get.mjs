import { c as defineEventHandler, R as ROLE_ADMIN, v as validateError, g as getQuery, e as validateSuccess } from '../../../../_/nitro.mjs';
import { q as queryAccountBalance, a as queryBill } from '../../../../_/bss.mjs';
import { z } from 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/zod/index.js';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/mysql2/promise.js';
import 'node:url';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/jose/dist/webapi/index.js';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/@alicloud/pop-core/index.js';

const bssQuerySchema = z.object({
  billingCycle: z.string().regex(/^\d{4}-\d{2}$/, "\u8D26\u671F\u683C\u5F0F\u5E94\u4E3A YYYY-MM").optional()
});
const bss_get = defineEventHandler(async (event) => {
  var _a, _b, _c, _d, _e;
  const user = event.context.user;
  if (!user || user.role !== ROLE_ADMIN) {
    return validateError("\u65E0\u7BA1\u7406\u5458\u6743\u9650", 403);
  }
  const parsed = bssQuerySchema.safeParse(getQuery(event));
  if (!parsed.success) {
    return validateError((_d = (_c = (_b = (_a = parsed.error) == null ? void 0 : _a.issues) == null ? void 0 : _b[0]) == null ? void 0 : _c.message) != null ? _d : "\u53C2\u6570\u6821\u9A8C\u5931\u8D25", 400);
  }
  const now = /* @__PURE__ */ new Date();
  const billingCycle = (_e = parsed.data.billingCycle) != null ? _e : `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
  const [balance, bill] = await Promise.all([queryAccountBalance(), queryBill(billingCycle)]);
  return validateSuccess({ balance, bill }, "\u83B7\u53D6 BSS \u8D39\u7528\u6570\u636E\u6210\u529F");
});

export { bss_get as default };
//# sourceMappingURL=bss.get.mjs.map
