import { c as defineEventHandler, R as ROLE_ADMIN, v as validateError, p as adminSegmentListSchema, g as getQuery, q as query, e as validateSuccess } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/mysql2/promise.js';
import 'node:url';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/zod/index.js';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/jose/dist/webapi/index.js';

const index_get = defineEventHandler(async (event) => {
  var _a, _b, _c, _d, _e, _f;
  const user = event.context.user;
  if (!user || user.role !== ROLE_ADMIN) {
    return validateError("\u65E0\u7BA1\u7406\u5458\u6743\u9650", 403);
  }
  const parsed = adminSegmentListSchema.safeParse(getQuery(event));
  if (!parsed.success) {
    return validateError((_d = (_c = (_b = (_a = parsed.error) == null ? void 0 : _a.issues) == null ? void 0 : _b[0]) == null ? void 0 : _c.message) != null ? _d : "\u53C2\u6570\u6821\u9A8C\u5931\u8D25", 400);
  }
  const { page, pageSize, unitId, isPublic, keyword } = parsed.data;
  const offset = (page - 1) * pageSize;
  const where = ["s.deleted_at IS NULL"];
  const params = [];
  if (unitId !== void 0) {
    where.push("s.unit_id = ?");
    params.push(unitId);
  }
  if (isPublic !== void 0) {
    where.push("s.is_public = ?");
    params.push(isPublic);
  }
  if (keyword) {
    where.push("s.title LIKE ?");
    params.push(`%${keyword}%`);
  }
  const whereSql = where.join(" AND ");
  const list = await query(
    `SELECT s.id, s.title, s.unit_id AS unitId, u.title AS unitTitle,
            s.is_public AS isPublic, s.sort_order AS sortOrder, s.createdAt
     FROM segment s
     LEFT JOIN unit u ON s.unit_id = u.id
     WHERE ${whereSql}
     ORDER BY s.createdAt DESC, s.id DESC
     LIMIT ? OFFSET ?`,
    [...params, pageSize, offset]
  );
  const countRows = await query(
    `SELECT COUNT(*) AS total FROM segment s WHERE ${whereSql}`,
    params
  );
  const total = Number((_f = (_e = countRows[0]) == null ? void 0 : _e.total) != null ? _f : 0);
  const result = { list, total, page, pageSize };
  return validateSuccess(result, "\u83B7\u53D6\u6750\u6599\u5217\u8868\u6210\u529F");
});

export { index_get as default };
//# sourceMappingURL=index2.get.mjs.map
