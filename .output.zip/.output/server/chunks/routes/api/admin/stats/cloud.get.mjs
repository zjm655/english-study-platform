import { c as defineEventHandler, R as ROLE_ADMIN, v as validateError, e as validateSuccess } from '../../../../_/nitro.mjs';
import { q as queryAccountBalance } from '../../../../_/bss.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/mysql2/promise.js';
import 'node:url';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/zod/index.js';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/jose/dist/webapi/index.js';
import 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/@alicloud/pop-core/index.js';

const cloud_get = defineEventHandler(async (event) => {
  const user = event.context.user;
  if (!user || user.role !== ROLE_ADMIN) {
    return validateError("\u65E0\u7BA1\u7406\u5458\u6743\u9650", 403);
  }
  const balance = await queryAccountBalance();
  return validateSuccess(balance, balance.success ? "\u83B7\u53D6\u4E91\u8D26\u6237\u4F59\u989D\u6210\u529F" : "\u4E91\u8D26\u6237\u4F59\u989D\u6682\u4E0D\u53EF\u7528");
});

export { cloud_get as default };
//# sourceMappingURL=cloud.get.mjs.map
