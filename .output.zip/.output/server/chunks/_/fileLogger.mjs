import { mkdir, appendFile } from 'node:fs/promises';
import { join } from 'node:path';

const LOG_DIR = join(process.cwd(), "logs");
let dirReady = false;
function dateStr() {
  return (/* @__PURE__ */ new Date()).toLocaleDateString("sv-SE", { timeZone: "Asia/Shanghai" });
}
function timestamp() {
  return (/* @__PURE__ */ new Date()).toLocaleString("sv-SE", { timeZone: "Asia/Shanghai" });
}
function serialize(args) {
  return args.map((a) => {
    var _a;
    if (typeof a === "string") return a;
    if (a instanceof Error) return (_a = a.stack) != null ? _a : a.message;
    try {
      return JSON.stringify(a);
    } catch {
      return String(a);
    }
  }).join(" ");
}
async function fileLog(source, level, ...args) {
  try {
    if (!dirReady) {
      await mkdir(LOG_DIR, { recursive: true });
      dirReady = true;
    }
    const line = `[${timestamp()}][${level.toUpperCase()}][${source}] ${serialize(args)}
`;
    const date = dateStr();
    await appendFile(join(LOG_DIR, `${source}-${date}.log`), line, "utf-8");
    if (level.toLowerCase() === "error" && source !== "error") {
      await appendFile(join(LOG_DIR, `error-${date}.log`), line, "utf-8");
    }
  } catch {
  }
}
function fileLogError(source, ...args) {
  return fileLog(source, "error", ...args);
}

export { fileLog as a, fileLogError as f };
//# sourceMappingURL=fileLogger.mjs.map
