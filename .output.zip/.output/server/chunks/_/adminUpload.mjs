import { randomUUID } from 'node:crypto';
import { t as textToSpeech, e as extractAudioMeta, g as generateLearningContent, a as generateTitle } from './audioMeta.mjs';
import { u as uploadWithKey } from './oss.mjs';
import { z as pool, l as logger, w as withTransaction } from './nitro.mjs';

function parseTxtFile(content) {
  if (!content.trim()) {
    throw new Error("TXT \u6587\u4EF6\u5185\u5BB9\u4E3A\u7A7A");
  }
  const lines = content.split("\n");
  if (!lines[0].trim()) {
    return { title: null, textContent: content.trim() };
  }
  if (lines.length <= 1) {
    return { title: null, textContent: lines[0].trim() };
  }
  const title = lines[0].trim();
  const textContent = lines.slice(1).join("\n").trim();
  return { title, textContent };
}
const DIALOGUE_LINE_RE = /^[A-Z][a-z]*(?:\s+\d+)?\s*:/;
function isDialogueText(text) {
  if (!text.trim()) return false;
  const lines = text.split("\n");
  const nonEmptyLines = lines.filter((l) => l.trim());
  if (nonEmptyLines.length === 0) return false;
  let matchCount = 0;
  for (const line of nonEmptyLines) {
    if (DIALOGUE_LINE_RE.test(line.trim())) {
      matchCount++;
    }
  }
  return matchCount / nonEmptyLines.length > 0.3;
}

const ADMIN_MAX_DURATION = 600;
const ADMIN_MAX_SIZE = 5 * 1024 * 1024;
async function createUploadRecord(userId, title, textContent, voice, isPublic) {
  const [res] = await pool.execute(
    `INSERT INTO material_upload_record (user_id, title, text_content, voice, is_public, status)
     VALUES (?, ?, ?, ?, ?, 'processing')`,
    [userId, title, textContent, voice, isPublic]
  );
  return res.insertId;
}
async function updateRecordFailed(recordId, error) {
  await pool.execute(
    `UPDATE material_upload_record SET status = 'failed', error_message = ? WHERE id = ?`,
    [error.substring(0, 500), recordId]
  );
}
async function updateRecordSuccess(recordId, segmentId) {
  await pool.execute(
    `UPDATE material_upload_record SET status = 'success', segment_id = ? WHERE id = ?`,
    [segmentId, recordId]
  );
}
async function processAdminMaterial(params) {
  var _a;
  const {
    userId,
    unitId,
    textContent,
    title,
    voice,
    isPublic,
    bucket,
    audioBuffer,
    audioFileName
  } = params;
  if (isDialogueText(textContent)) {
    return { index: 0, success: false, error: "\u6750\u6599\u4E3A\u5BF9\u8BDD\u683C\u5F0F\uFF0C\u4E0D\u652F\u6301\u4E0A\u4F20" };
  }
  const fallbackTitle = textContent.length > 50 ? textContent.slice(0, 50) + "..." : textContent;
  let recordId;
  if (params.existingRecordId) {
    recordId = params.existingRecordId;
    try {
      await pool.execute(
        `UPDATE material_upload_record SET status = 'processing', error_message = NULL WHERE id = ?`,
        [recordId]
      );
    } catch (err) {
      logger.error("[admin upload] \u91CD\u7F6E\u8BB0\u5F55\u72B6\u6001\u5931\u8D25:", err);
      return { index: 0, success: false, error: "\u91CD\u7F6E\u8BB0\u5F55\u72B6\u6001\u5931\u8D25" };
    }
  } else {
    try {
      recordId = await createUploadRecord(
        userId,
        title || fallbackTitle,
        textContent,
        voice,
        isPublic
      );
    } catch (err) {
      logger.error("[admin upload] \u521B\u5EFA\u8BB0\u5F55\u5931\u8D25:", err);
      return { index: 0, success: false, error: "\u521B\u5EFA\u4E0A\u4F20\u8BB0\u5F55\u5931\u8D25" };
    }
  }
  try {
    let audioBuffer_;
    let mediaType;
    const ext = audioFileName ? ((_a = audioFileName.split(".").pop()) == null ? void 0 : _a.toLowerCase()) || "mp3" : "mp3";
    if (audioBuffer) {
      audioBuffer_ = audioBuffer;
      mediaType = "user_material";
    } else {
      const ttsResult = await textToSpeech(textContent, voice);
      if (!ttsResult.success || !ttsResult.audio) {
        await updateRecordFailed(recordId, "\u97F3\u9891\u751F\u6210\u5931\u8D25");
        return { index: 0, success: false, error: "\u97F3\u9891\u751F\u6210\u5931\u8D25" };
      }
      audioBuffer_ = ttsResult.audio;
      mediaType = "tts";
    }
    const ossKey = `audio/material/${randomUUID()}.${ext}`;
    try {
      await uploadWithKey(audioBuffer_, ossKey);
    } catch (err) {
      logger.error("[admin upload] OSS \u4E0A\u4F20\u5931\u8D25:", err);
      await updateRecordFailed(recordId, "\u6587\u4EF6\u4E0A\u4F20\u5931\u8D25");
      return { index: 0, success: false, error: "\u6587\u4EF6\u4E0A\u4F20\u5931\u8D25" };
    }
    const originalName = audioFileName || "tts.mp3";
    const [mediaRes] = await pool.execute(
      `INSERT INTO media (uploader_id, type, storage_type, bucket, object_key, original_name, mime_type, size_bytes, status)
       VALUES (?, ?, 'oss', ?, ?, ?, ?, ?, 1)`,
      [userId, mediaType, bucket, ossKey, originalName, `audio/${ext}`, audioBuffer_.length]
    );
    const segmentMediaId = mediaRes.insertId;
    const meta = await extractAudioMeta(audioBuffer_);
    if (!meta) {
      await pool.execute("UPDATE media SET status = 0 WHERE id = ?", [segmentMediaId]);
      await updateRecordFailed(recordId, "\u65E0\u6CD5\u89E3\u6790\u97F3\u9891\u4FE1\u606F");
      return { index: 0, success: false, error: "\u65E0\u6CD5\u89E3\u6790\u97F3\u9891\u4FE1\u606F" };
    }
    if (meta.duration > ADMIN_MAX_DURATION) {
      await pool.execute("UPDATE media SET status = 0 WHERE id = ?", [segmentMediaId]);
      await updateRecordFailed(recordId, `\u97F3\u9891\u65F6\u957F\u8D85\u9650: ${meta.duration.toFixed(1)}s`);
      return { index: 0, success: false, error: `\u97F3\u9891\u65F6\u957F\u8D85\u9650` };
    }
    if (meta.size > ADMIN_MAX_SIZE) {
      await pool.execute("UPDATE media SET status = 0 WHERE id = ?", [segmentMediaId]);
      await updateRecordFailed(recordId, `\u97F3\u9891\u5927\u5C0F\u8D85\u9650`);
      return { index: 0, success: false, error: "\u97F3\u9891\u5927\u5C0F\u8D85\u9650" };
    }
    await pool.execute("UPDATE media SET duration = ? WHERE id = ?", [
      meta.duration,
      segmentMediaId
    ]);
    const aiResult = await generateLearningContent(textContent);
    if (!aiResult.success || !aiResult.vocabulary || !aiResult.questions) {
      await pool.execute("UPDATE media SET status = 0 WHERE id = ?", [segmentMediaId]);
      await updateRecordFailed(recordId, "AI \u5185\u5BB9\u751F\u6210\u5931\u8D25");
      return { index: 0, success: false, error: "AI \u5185\u5BB9\u751F\u6210\u5931\u8D25" };
    }
    const vocabulary = aiResult.vocabulary;
    const questions = aiResult.questions;
    let finalTitle;
    if (title) {
      finalTitle = title;
    } else {
      const titleResult = await generateTitle(textContent);
      if (titleResult.success && titleResult.title) {
        finalTitle = titleResult.title;
      } else {
        logger.warn("[admin upload] \u6807\u9898\u751F\u6210\u5931\u8D25\uFF0C\u964D\u7EA7\u4E3A\u6587\u672C\u622A\u53D6:", titleResult.error);
        finalTitle = fallbackTitle;
      }
    }
    const segmentId = await withTransaction(async (conn) => {
      var _a2, _b, _c, _d, _e;
      const [segRes] = await conn.execute(
        `INSERT INTO segment (unit_id, title, textContent, translation, questions, is_public, media_id, sort_order)
         VALUES (?, ?, ?, ?, ?, ?, ?, 0)`,
        [
          unitId,
          finalTitle,
          textContent,
          (_a2 = aiResult.translation) != null ? _a2 : "",
          JSON.stringify(questions),
          isPublic,
          segmentMediaId
        ]
      );
      const newSegmentId = segRes.insertId;
      let vocabIndex = 0;
      for (const vocab of vocabulary) {
        let vocabMediaId = null;
        const vocabTts = await textToSpeech(vocab.word);
        if (vocabTts.success && vocabTts.audio) {
          const vocabKey = `audio/vocab/${randomUUID()}.mp3`;
          try {
            await uploadWithKey(vocabTts.audio, vocabKey);
          } catch {
          }
          const [vmRes] = await conn.execute(
            `INSERT INTO media (uploader_id, type, storage_type, bucket, object_key, mime_type, size_bytes, duration, status)
             VALUES (NULL, 'vocab_audio', 'oss', ?, ?, 'audio/mpeg', ?, 0, 1)`,
            [bucket, vocabKey, vocabTts.audio.length]
          );
          vocabMediaId = vmRes.insertId;
        }
        await conn.execute(
          `INSERT INTO vocabulary (segment_id, word, forms, phonetic, meaning, exampleSentence, exampleTranslation, media_id, sort_order)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            newSegmentId,
            vocab.word,
            (_b = vocab.forms) != null ? _b : null,
            (_c = vocab.phonetic) != null ? _c : null,
            vocab.meaning,
            (_d = vocab.exampleSentence) != null ? _d : null,
            (_e = vocab.exampleTranslation) != null ? _e : null,
            vocabMediaId,
            vocabIndex++
          ]
        );
      }
      return newSegmentId;
    });
    await updateRecordSuccess(recordId, segmentId);
    if (finalTitle !== fallbackTitle) {
      await pool.execute("UPDATE material_upload_record SET title = ? WHERE id = ?", [
        finalTitle,
        recordId
      ]);
    }
    logger.info(`[admin upload] \u6210\u529F record=${recordId} segment=${segmentId} title=${finalTitle}`);
    return { index: 0, success: true, segmentId, title: finalTitle };
  } catch (err) {
    logger.error("[admin upload] \u5904\u7406\u5931\u8D25:", err);
    try {
      await updateRecordFailed(recordId, "\u5904\u7406\u5931\u8D25");
    } catch {
    }
    return { index: 0, success: false, error: "\u5904\u7406\u5931\u8D25" };
  }
}
async function processAdminBatch(params) {
  const { userId, unitId, voice, isPublic, bucket, files } = params;
  const results = [];
  for (let i = 0; i < files.length; i++) {
    const file = files[i];
    const parsed = { title: null, textContent: "" };
    try {
      const r = parseTxtFile(file.content);
      parsed.title = r.title;
      parsed.textContent = r.textContent;
    } catch {
      results.push({ index: i, success: false, error: `\u6587\u4EF6 ${file.name} \u89E3\u6790\u5931\u8D25\uFF1A\u5185\u5BB9\u4E3A\u7A7A` });
      continue;
    }
    const result = await processAdminMaterial({
      userId,
      unitId,
      textContent: parsed.textContent,
      title: parsed.title,
      voice,
      isPublic,
      bucket
    });
    results.push({ ...result, index: i });
  }
  return results;
}

export { processAdminBatch as a, processAdminMaterial as p };
//# sourceMappingURL=adminUpload.mjs.map
