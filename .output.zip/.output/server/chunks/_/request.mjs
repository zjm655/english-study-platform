import { a as fileLog, f as fileLogError } from './fileLogger.mjs';
import { l as logger } from './nitro.mjs';

const DEFAULT_TIMEOUT = 3e4;
async function serverFetch(url, options = {}) {
  var _a;
  const { timeout = DEFAULT_TIMEOUT, tag = "[serverFetch]", ...init } = options;
  const method = (_a = init.method) != null ? _a : "GET";
  const start = Date.now();
  logger.info(`${tag} \u2192 ${method} ${url}`);
  try {
    const resp = await fetch(url, { ...init, signal: AbortSignal.timeout(timeout) });
    const ms = Date.now() - start;
    logger.info(`${tag} \u2190 ${resp.status} (${ms}ms)`);
    fileLog("api", resp.ok ? "info" : "error", `${tag} ${method} ${url} \u2192 ${resp.status} (${ms}ms)`);
    return resp;
  } catch (err) {
    const ms = Date.now() - start;
    const name = err instanceof Error ? err.name : "";
    const msg = err instanceof Error ? err.message : String(err);
    const isTimeout = /abort|timeout/i.test(name + msg);
    logger.error(`${tag} \u2717 ${method} ${url} \u5931\u8D25${isTimeout ? "\uFF08\u8D85\u65F6\uFF09" : ""} (${ms}ms): ${msg}`);
    fileLogError("api", `${tag} ${method} ${url} \u5931\u8D25${isTimeout ? "\uFF08\u8D85\u65F6\uFF09" : ""} (${ms}ms)`, msg);
    throw err;
  }
}

export { serverFetch as s };
//# sourceMappingURL=request.mjs.map
