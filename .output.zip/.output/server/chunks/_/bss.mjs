import { f as logCloudServiceCall, l as logger, u as useRuntimeConfig } from './nitro.mjs';
import RPCClient from 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/@alicloud/pop-core/index.js';

const BSS_ENDPOINT = "https://business.aliyuncs.com";
const BSS_API_VERSION = "2017-12-14";
let cachedClient = null;
function getClient() {
  if (cachedClient) return cachedClient;
  const config = useRuntimeConfig().bss;
  if (!(config == null ? void 0 : config.accessKeyId) || !(config == null ? void 0 : config.accessKeySecret)) return null;
  cachedClient = new RPCClient({
    endpoint: BSS_ENDPOINT,
    apiVersion: BSS_API_VERSION,
    accessKeyId: config.accessKeyId,
    accessKeySecret: config.accessKeySecret
  });
  return cachedClient;
}
async function queryAccountBalance() {
  var _a, _b;
  const client = getClient();
  if (!client) {
    return { success: false, error: "BSS AccessKey \u672A\u914D\u7F6E" };
  }
  let callStart = 0;
  try {
    callStart = Date.now();
    const res = await client.request("QueryAccountBalance", {});
    const data = res == null ? void 0 : res.Data;
    if (!data) {
      return { success: false, error: "BSS \u54CD\u5E94\u7ED3\u6784\u5F02\u5E38\uFF08\u65E0 Data \u5B57\u6BB5\uFF09" };
    }
    void logCloudServiceCall({
      service: "bss",
      operation: "queryAccountBalance",
      success: true,
      durationMs: Date.now() - callStart
    });
    return {
      success: true,
      availableAmount: data.AvailableAmount,
      availableCashAmount: data.AvailableCashAmount,
      creditAmount: data.CreditAmount,
      currency: data.Currency
    };
  } catch (err) {
    const e = err;
    logger.error("[bss] \u67E5\u8BE2\u8D26\u6237\u4F59\u989D\u5931\u8D25:", err);
    void logCloudServiceCall({
      service: "bss",
      operation: "queryAccountBalance",
      success: false,
      durationMs: callStart ? Date.now() - callStart : 0,
      errorMessage: ((e == null ? void 0 : e.code) ? `${e.code}: ${(_a = e.message) != null ? _a : ""}` : String(err)).substring(0, 500)
    });
    return {
      success: false,
      error: (e == null ? void 0 : e.code) ? `${e.code}: ${(_b = e.message) != null ? _b : ""}` : String(err)
    };
  }
}
async function queryBill(billingCycle) {
  var _a, _b, _c, _d, _e;
  const client = getClient();
  if (!client) {
    return { success: false, error: "BSS AccessKey \u672A\u914D\u7F6E" };
  }
  let callStart = 0;
  try {
    callStart = Date.now();
    const res = await client.request("QueryBill", {
      BillingCycle: billingCycle,
      PageSize: 100,
      PageNum: 1
    });
    const data = res == null ? void 0 : res.Data;
    if (!data) {
      return { success: false, error: "BSS \u54CD\u5E94\u7ED3\u6784\u5F02\u5E38\uFF08\u65E0 Data \u5B57\u6BB5\uFF09" };
    }
    const rawItems = (_b = (_a = data.Items) == null ? void 0 : _a.Item) != null ? _b : [];
    void logCloudServiceCall({
      service: "bss",
      operation: "queryBill",
      success: true,
      durationMs: Date.now() - callStart
    });
    return {
      success: true,
      billingCycle,
      totalCount: (_c = data.TotalCount) != null ? _c : rawItems.length,
      items: rawItems.map((i) => {
        var _a2, _b2, _c2, _d2, _e2, _f;
        return {
          productCode: (_a2 = i.ProductCode) != null ? _a2 : "",
          productName: (_b2 = i.ProductName) != null ? _b2 : "",
          subscriptionType: (_c2 = i.SubscriptionType) != null ? _c2 : "",
          pretaxAmount: Number((_d2 = i.PretaxAmount) != null ? _d2 : 0),
          deductedByCoupons: Number((_e2 = i.DeductedByCoupons) != null ? _e2 : 0),
          paymentAmount: Number((_f = i.PaymentAmount) != null ? _f : 0)
        };
      })
    };
  } catch (err) {
    const e = err;
    logger.error("[bss] \u67E5\u8BE2\u8D26\u5355\u5931\u8D25:", err);
    void logCloudServiceCall({
      service: "bss",
      operation: "queryBill",
      success: false,
      durationMs: callStart ? Date.now() - callStart : 0,
      errorMessage: ((e == null ? void 0 : e.code) ? `${e.code}: ${(_d = e.message) != null ? _d : ""}` : String(err)).substring(0, 500)
    });
    return {
      success: false,
      error: (e == null ? void 0 : e.code) ? `${e.code}: ${(_e = e.message) != null ? _e : ""}` : String(err)
    };
  }
}

export { queryBill as a, queryAccountBalance as q };
//# sourceMappingURL=bss.mjs.map
