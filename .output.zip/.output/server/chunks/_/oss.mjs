import { l as logger, f as logCloudServiceCall, u as useRuntimeConfig } from './nitro.mjs';
import OSS from 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/ali-oss/lib/client.js';
import { a as fileLog, f as fileLogError } from './fileLogger.mjs';

let client = null;
let internalClient = null;
const config = useRuntimeConfig().oss;
function buildOssOptions(options = {}) {
  const baseOptions = {
    ...config,
    secure: true,
    // 使用 HTTPS
    authorizationV4: true
  };
  const finalOptions = { ...baseOptions, ...options };
  if (!finalOptions.endpoint) {
    const internalSuffix = finalOptions.internal ? "-internal" : "";
    finalOptions.endpoint = `https://${config.region}${internalSuffix}.aliyuncs.com`;
  }
  return finalOptions;
}
function getClient() {
  if (!client) {
    client = new OSS(buildOssOptions());
  }
  return client;
}
function getInternalClient() {
  if (!internalClient) {
    internalClient = new OSS(
      buildOssOptions({
        internal: true
        // endpoint 会在 buildOssOptions 中自动添加 '-internal'
      })
    );
  }
  return internalClient;
}
const MATERIAL_EXPIRE = 2100;
const WORD_EXPIRE = 2100;
const RECORDING_EXPIRE = 2400;
async function uploadWithKey(fileBuffer, ossKey) {
  const client2 = getClient();
  const start = Date.now();
  try {
    const result = await client2.put(ossKey, fileBuffer);
    logger.info(`[OSS] \u4E0A\u4F20\u6210\u529F: ${ossKey} (${fileBuffer.length}B)`);
    fileLog("oss", "info", `[OSS] \u4E0A\u4F20\u6210\u529F: ${ossKey}`, { size: fileBuffer.length });
    void logCloudServiceCall({
      service: "oss",
      operation: "uploadWithKey",
      success: true,
      durationMs: Date.now() - start
    });
    return {
      url: result.url,
      name: result.name,
      size: fileBuffer.length
    };
  } catch (error) {
    const errMsg = error instanceof Error ? error.message : String(error);
    logger.error(`[OSS] \u4E0A\u4F20\u5931\u8D25: ${ossKey}, \u9519\u8BEF: ${errMsg}`);
    fileLogError("oss", `[OSS] \u4E0A\u4F20\u5931\u8D25: ${ossKey}`, errMsg);
    void logCloudServiceCall({
      service: "oss",
      operation: "uploadWithKey",
      success: false,
      durationMs: Date.now() - start,
      errorMessage: errMsg.substring(0, 500)
    });
    throw error;
  }
}
async function signUrl(rawUrl, expires = 1800, useInternal = false, queries = {}) {
  var _a;
  try {
    const idx = rawUrl.indexOf(".aliyuncs.com/");
    let key;
    if (idx !== -1) {
      key = (_a = rawUrl.substring(idx + ".aliyuncs.com/".length).split("?")[0]) != null ? _a : "";
    } else {
      key = rawUrl;
    }
    const decodedKey = decodeURIComponent(key);
    const client2 = useInternal ? getInternalClient() : getClient();
    const signedUrl = await client2.signatureUrlV4(
      "GET",
      expires,
      {
        headers: {},
        queries
      },
      decodedKey
    );
    logger.log(`[OSS] signUrl \u6210\u529F: ${rawUrl} (${useInternal ? "\u5185\u7F51" : "\u516C\u7F51"})`);
    fileLog("oss", "info", `[OSS] signUrl \u6210\u529F: ${rawUrl} (${useInternal ? "\u5185\u7F51" : "\u516C\u7F51"})`);
    return signedUrl;
  } catch (error) {
    const errMsg = error instanceof Error ? error.message : String(error);
    logger.error(`[OSS] signUrl \u5931\u8D25: ${rawUrl}, \u9519\u8BEF: ${errMsg}`);
    fileLogError("oss", `[OSS] signUrl \u5931\u8D25: ${rawUrl}`, errMsg);
    return rawUrl;
  }
}
async function getOssBucketStat() {
  var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p;
  try {
    const c = getClient();
    const bucket = config.bucket;
    const res = await c.getBucketStat(bucket);
    const stat = res == null ? void 0 : res.stat;
    if (!stat) {
      return { success: false, error: "OSS \u54CD\u5E94\u7ED3\u6784\u5F02\u5E38\uFF08\u65E0 stat \u5B57\u6BB5\uFF09" };
    }
    const result = {
      success: true,
      storage: Number((_a = stat.Storage) != null ? _a : 0),
      objectCount: Number((_b = stat.ObjectCount) != null ? _b : 0),
      standardStorage: Number((_c = stat.StandardStorage) != null ? _c : 0),
      standardObjectCount: Number((_d = stat.StandardObjectCount) != null ? _d : 0),
      multipartUploadCount: Number((_e = stat.MultipartUploadCount) != null ? _e : 0),
      lastModifiedTime: Number((_f = stat.LastModifiedTime) != null ? _f : 0),
      infrequentAccessStorage: Number((_g = stat.InfrequentAccessStorage) != null ? _g : 0),
      infrequentAccessObjectCount: Number((_h = stat.InfrequentAccessObjectCount) != null ? _h : 0),
      archiveStorage: Number((_i = stat.ArchiveStorage) != null ? _i : 0),
      archiveObjectCount: Number((_j = stat.ArchiveObjectCount) != null ? _j : 0),
      coldArchiveStorage: Number((_k = stat.ColdArchiveStorage) != null ? _k : 0),
      coldArchiveObjectCount: Number((_l = stat.ColdArchiveObjectCount) != null ? _l : 0),
      deepColdArchiveStorage: Number((_m = stat.DeepColdArchiveStorage) != null ? _m : 0),
      deepColdArchiveObjectCount: Number((_n = stat.DeepColdArchiveObjectCount) != null ? _n : 0)
    };
    fileLog("oss", "info", "[getOssBucketStat] \u67E5\u8BE2\u6210\u529F", {
      storage: result.storage,
      objectCount: result.objectCount
    });
    return result;
  } catch (err) {
    const e = err;
    logger.error("[oss] getBucketStat \u5931\u8D25:", err);
    fileLogError(
      "oss",
      "[getOssBucketStat] \u5931\u8D25",
      (e == null ? void 0 : e.code) ? `${e.code}: ${(_o = e.message) != null ? _o : ""}` : String(err)
    );
    return {
      success: false,
      error: (e == null ? void 0 : e.code) ? `${e.code}: ${(_p = e.message) != null ? _p : ""}` : String(err)
    };
  }
}

export { MATERIAL_EXPIRE as M, RECORDING_EXPIRE as R, WORD_EXPIRE as W, getOssBucketStat as g, signUrl as s, uploadWithKey as u };
//# sourceMappingURL=oss.mjs.map
