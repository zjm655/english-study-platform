import { u as useRuntimeConfig, l as logger, f as logCloudServiceCall } from './nitro.mjs';
import RPCClient from 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/@alicloud/pop-core/index.js';
import { f as fileLogError, a as fileLog } from './fileLogger.mjs';
import { s as serverFetch } from './request.mjs';

const TOKEN_EXPIRY_BUFFER = 60;
const TOKEN_ENDPOINT = "https://nls-meta.cn-shanghai.aliyuncs.com";
const TOKEN_API_VERSION = "2019-02-28";
let cachedToken = null;
function isTokenValid() {
  if (!cachedToken) return false;
  const nowSec = Date.now() / 1e3;
  return cachedToken.expireTime > nowSec + TOKEN_EXPIRY_BUFFER;
}
async function getToken(config) {
  if (isTokenValid()) {
    return cachedToken.token;
  }
  const client = new RPCClient({
    endpoint: TOKEN_ENDPOINT,
    apiVersion: TOKEN_API_VERSION,
    accessKeyId: config.accessKeyId,
    accessKeySecret: config.accessKeySecret
  });
  let callStart = 0;
  try {
    callStart = Date.now();
    const result = await client.request("CreateToken", {});
    const token = result.Token.Id;
    const expireTime = result.Token.ExpireTime;
    cachedToken = { token, expireTime };
    void logCloudServiceCall({
      service: "nls",
      operation: "createToken",
      success: true,
      durationMs: Date.now() - callStart
    });
    return token;
  } catch (err) {
    const errMsg = err instanceof Error ? err.message : String(err);
    void logCloudServiceCall({
      service: "nls",
      operation: "createToken",
      success: false,
      durationMs: callStart ? Date.now() - callStart : 0,
      errorMessage: errMsg.substring(0, 500)
    });
    throw err;
  }
}
async function speechToText(audioBuffer, format = "mp3") {
  var _a, _b, _c;
  if (!audioBuffer || audioBuffer.length === 0) {
    return { success: false, error: "\u97F3\u9891\u6570\u636E\u4E0D\u80FD\u4E3A\u7A7A" };
  }
  const config = useRuntimeConfig();
  const nls = config.nls;
  if (!(nls == null ? void 0 : nls.accessKeyId) || !(nls == null ? void 0 : nls.accessKeySecret) || !(nls == null ? void 0 : nls.gateway) || !(nls == null ? void 0 : nls.appKey)) {
    logger.error("[speechToText] NLS \u914D\u7F6E\u4E0D\u5B8C\u6574");
    fileLogError("nls", "[speechToText] NLS \u914D\u7F6E\u4E0D\u5B8C\u6574");
    return { success: false, error: "NLS \u914D\u7F6E\u7F3A\u5931" };
  }
  const fullConfig = {
    accessKeyId: nls.accessKeyId,
    accessKeySecret: nls.accessKeySecret,
    gateway: nls.gateway,
    appKey: nls.appKey
  };
  let token;
  try {
    token = await getToken(fullConfig);
  } catch (err) {
    const errMsg = err instanceof Error ? err.message : String(err);
    logger.error("[speechToText] Token \u83B7\u53D6\u5931\u8D25:", errMsg);
    fileLogError("nls", "[speechToText] Token \u83B7\u53D6\u5931\u8D25", errMsg);
    return { success: false, error: "Token \u83B7\u53D6\u5931\u8D25" };
  }
  const url = `https://${fullConfig.gateway}/stream/v1/FlashRecognizer?appkey=${fullConfig.appKey}&token=${token}&format=${format}&sample_rate=16000`;
  let callStart2 = 0;
  try {
    callStart2 = Date.now();
    const resp = await serverFetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/octet-stream"
      },
      body: new Uint8Array(audioBuffer),
      timeout: 6e4,
      tag: "[speechToText]"
    });
    const data = await resp.json();
    if (data.status !== 2e7) {
      const msg = data.message || `\u8BC6\u522B\u5931\u8D25\uFF08status: ${data.status}\uFF09`;
      logger.error("[speechToText] \u8BC6\u522B\u5931\u8D25:", msg);
      fileLogError("nls", "[speechToText] \u8BC6\u522B\u5931\u8D25", msg, { status: data.status });
      void logCloudServiceCall({
        service: "nls",
        operation: "speechToText",
        success: false,
        durationMs: Date.now() - callStart2,
        errorMessage: msg.substring(0, 500)
      });
      return { success: false, error: msg };
    }
    const sentences = (_b = (_a = data.flash_result) == null ? void 0 : _a.sentences) != null ? _b : [];
    const text = sentences.map((s) => s.text).join("");
    const duration = (_c = data.flash_result) == null ? void 0 : _c.duration;
    logger.info(
      `[speechToText] \u8BC6\u522B\u6210\u529F (${text.length}\u5B57${duration !== void 0 ? `, ${duration}ms` : ""})`
    );
    fileLog("nls", "info", "[speechToText] \u8BC6\u522B\u6210\u529F", { format, textLength: text.length, duration });
    void logCloudServiceCall({
      service: "nls",
      operation: "speechToText",
      success: true,
      durationMs: Date.now() - callStart2
    });
    return {
      success: true,
      text,
      ...duration !== void 0 ? { duration } : {}
    };
  } catch (err) {
    const errMsg = err instanceof Error ? err.message : String(err);
    logger.error("[speechToText] \u8BC6\u522B\u8BF7\u6C42\u5931\u8D25:", errMsg);
    fileLogError("nls", "[speechToText] \u8BC6\u522B\u8BF7\u6C42\u5931\u8D25", errMsg);
    void logCloudServiceCall({
      service: "nls",
      operation: "speechToText",
      success: false,
      durationMs: callStart2 ? Date.now() - callStart2 : 0,
      errorMessage: errMsg.substring(0, 500)
    });
    if (errMsg.includes("abort") || errMsg.includes("timeout") || errMsg.includes("Timeout")) {
      return { success: false, error: "\u8BED\u97F3\u8BC6\u522B\u8D85\u65F6" };
    }
    return { success: false, error: "\u8BED\u97F3\u8BC6\u522B\u8BF7\u6C42\u5931\u8D25" };
  }
}

export { speechToText as s };
//# sourceMappingURL=speechToText.mjs.map
