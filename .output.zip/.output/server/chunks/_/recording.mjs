function rowToRecording(row, audioPathOverride) {
  if (!row) return null;
  let wordScores = null;
  if (row.wordScores) {
    if (Array.isArray(row.wordScores)) {
      wordScores = row.wordScores;
    } else {
      try {
        wordScores = JSON.parse(row.wordScores);
      } catch {
        wordScores = null;
      }
    }
  }
  return {
    id: row.id,
    userId: row.user_id,
    segmentId: row.segment_id,
    phase: row.phase,
    audioPath: audioPathOverride != null ? audioPathOverride : null,
    score: row.score !== null ? Number(row.score) : null,
    feedback: row.feedback,
    recognizedText: row.recognizedText,
    wordScores,
    rawResult: row.rawResult,
    duration: row.duration !== null ? Number(row.duration) : null,
    createdAt: row.createdAt
  };
}

export { rowToRecording as r };
//# sourceMappingURL=recording.mjs.map
