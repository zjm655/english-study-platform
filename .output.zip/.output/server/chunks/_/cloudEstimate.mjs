import { q as query } from './nitro.mjs';

const PRODUCT_REGISTRY = {
  oss: {
    name: "OSS \u5BF9\u8C61\u5B58\u50A8",
    unit: "\u6B21",
    unitPrice: 1e-4,
    // Put 请求费 0.01 元/万次
    paths: [
      { pattern: "/api/recording", method: "POST" },
      { pattern: "/api/admin/segment/upload", method: "POST" }
    ]
  },
  nls: {
    name: "NLS \u667A\u80FD\u8BED\u97F3\u4EA4\u4E92",
    unit: "\u6B21",
    unitPrice: 0.083,
    // 每次约 2 分钟音频 × 2.5 元/小时 ≈ 0.083 元
    paths: [
      { pattern: "/api/segment/upload", method: "POST" },
      { pattern: "/api/recording", method: "POST" },
      // 录音上传也触发 ASR 校对
      { pattern: "/api/admin/segment/upload", method: "POST" }
    ]
  },
  edu: {
    name: "\u667A\u80FD\u79D1\u6559\u5E73\u53F0",
    unit: "\u6B21",
    unitPrice: 4e-3,
    // 0.004 元/次
    paths: [
      { pattern: "/api/evaluation/auth", method: "POST" }
      // /api/recording/%/analyze 仅将前端评测结果入库，后端未调用智能科教平台，已移除
    ]
  }
};
async function estimateServiceUsage(product, days) {
  var _a, _b;
  const config = PRODUCT_REGISTRY[product];
  if (!config) {
    return { totalCalls: 0, totalEstimatedCost: 0, unitPrice: 0, unit: "\u6B21", byPath: [], days };
  }
  const byPath = [];
  let totalCalls = 0;
  for (const p of config.paths) {
    const timeCond = "createdAt >= DATE_SUB(CURDATE(), INTERVAL ? DAY)";
    const sql = `SELECT COUNT(*) AS cnt FROM api_call_log WHERE ${timeCond} AND route_pattern = ? AND method = ?`;
    const rows = await query(sql, [days, p.pattern, p.method]);
    const count = Number((_b = (_a = rows[0]) == null ? void 0 : _a.cnt) != null ? _b : 0);
    totalCalls += count;
    byPath.push({
      path: p.pattern,
      method: p.method,
      count,
      unitPrice: config.unitPrice,
      estimatedCost: Math.round(count * config.unitPrice * 1e3) / 1e3
    });
  }
  return {
    totalCalls,
    totalEstimatedCost: Math.round(totalCalls * config.unitPrice * 1e3) / 1e3,
    unitPrice: config.unitPrice,
    unit: config.unit,
    byPath,
    days
  };
}

export { estimateServiceUsage as e };
//# sourceMappingURL=cloudEstimate.mjs.map
