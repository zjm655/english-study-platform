const DEFAULT_PROGRESS = {
  phase1_done: false,
  phase2_done: false,
  phase3_done: false,
  phase3_score: null,
  phase4_done: false,
  phase4_score: null
};
function mapProgressRow(row) {
  var _a;
  return {
    phase1_done: !!row.phase1_done,
    phase2_done: !!row.phase2_done,
    phase3_done: !!row.phase3_done,
    phase3_score: row.phase3_score ? Number(row.phase3_score) : null,
    phase4_done: !!row.phase4_done,
    phase4_score: row.phase4_score ? Number(row.phase4_score) : null,
    updatedAt: (_a = row.updatedAt) != null ? _a : null
  };
}

export { DEFAULT_PROGRESS as D, mapProgressRow as m };
//# sourceMappingURL=progress.mjs.map
