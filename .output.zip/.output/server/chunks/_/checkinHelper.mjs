function formatDate(d) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}
function formatDatetime(d) {
  return `${formatDate(d)} ${d.toTimeString().slice(0, 8)}`;
}
function isStreakBroken(lastCheckinTime, now) {
  if (!lastCheckinTime) return false;
  const lastDate = new Date(lastCheckinTime);
  if (Number.isNaN(lastDate.getTime())) return false;
  const lastStr = formatDate(lastDate);
  const todayStr = formatDate(now);
  const yesterday = new Date(now);
  yesterday.setDate(now.getDate() - 1);
  const yesterdayStr = formatDate(yesterday);
  return lastStr !== todayStr && lastStr !== yesterdayStr;
}
async function getStats(conn, userId) {
  const [rows] = await conn.execute(
    "SELECT * FROM user_checkin_stats WHERE user_id = ?",
    [userId]
  );
  const row = rows[0];
  if (!row) {
    return {
      totalCheckinDays: 0,
      lastCheckinTime: null,
      currentStreakDays: 0,
      maxStreakDays: 0,
      totalStudySeconds: 0
    };
  }
  return {
    totalCheckinDays: row.total_checkin_days,
    lastCheckinTime: row.last_checkin_time,
    currentStreakDays: row.current_streak_days,
    maxStreakDays: row.max_streak_days,
    totalStudySeconds: row.total_study_seconds
  };
}

export { formatDatetime as a, formatDate as f, getStats as g, isStreakBroken as i };
//# sourceMappingURL=checkinHelper.mjs.map
