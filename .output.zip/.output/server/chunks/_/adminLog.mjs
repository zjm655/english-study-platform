import { q as query, l as logger } from './nitro.mjs';

async function logAdminOperation(adminId, action, targetType, targetId, detail) {
  try {
    await query(
      `INSERT INTO admin_operation_log (admin_id, action, target_type, target_id, detail)
       VALUES (?, ?, ?, ?, ?)`,
      [adminId, action, targetType, targetId, detail ? JSON.stringify(detail) : null]
    );
  } catch (err) {
    logger.error("[admin log] \u64CD\u4F5C\u65E5\u5FD7\u5199\u5165\u5931\u8D25:", err);
  }
}

export { logAdminOperation as l };
//# sourceMappingURL=adminLog.mjs.map
