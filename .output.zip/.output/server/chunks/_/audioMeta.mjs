import { u as useRuntimeConfig, l as logger, f as logCloudServiceCall } from './nitro.mjs';
import { s as serverFetch } from './request.mjs';
import { a as fileLog, f as fileLogError } from './fileLogger.mjs';
import crypto from 'node:crypto';
import WebSocket from 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/ws/wrapper.mjs';
import { parseBuffer } from 'file://D:/%E5%85%B6%E4%BB%96/%E8%AE%B0%E5%BD%95/nuxt/%E8%8B%B1%E8%AF%AD%E5%B9%B3%E5%8F%B0/node_modules/music-metadata/lib/index.js';

const MAX_TEXT_LENGTH = 5e3;
const API_TIMEOUT = 3e4;
const MAX_TOKENS = 3e3;
const MIN_VOCAB = 1;
const MAX_VOCAB = 10;
const MIN_QUESTIONS = 1;
const MAX_QUESTIONS = 5;
const SYSTEM_PROMPT = `\u4F60\u662F\u4E00\u4E2A\u4E13\u4E1A\u7684\u82F1\u8BED\u6559\u5B66\u5185\u5BB9\u751F\u6210\u52A9\u624B\u3002\u6211\u4F1A\u7ED9\u4F60\u4E00\u6BB5\u82F1\u6587\u539F\u6587\uFF0C\u4F60\u9700\u8981\uFF1A

1. \u63D0\u4F9B\u51C6\u786E\u7684\u4E2D\u6587\u7FFB\u8BD1
2. \u9009\u51FA 3-5 \u4E2A\u91CD\u70B9\u8BCD\u6C47\uFF0C\u4E3A\u6BCF\u4E2A\u8BCD\u63D0\u4F9B\uFF1A
   - word: \u539F\u8BCD
   - forms: \u8BCD\u5F62\u53D8\u5316\uFF08\u9017\u53F7\u5206\u9694\uFF0C\u65E0\u5219\u7559\u7A7A\u5B57\u7B26\u4E32\uFF09
   - phonetic: \u97F3\u6807\uFF08IPA\u683C\u5F0F\uFF0C\u5982 /\u02C8\u0283\xE6do\u028A/\uFF09
   - meaning: \u4E2D\u6587\u91CA\u4E49\uFF08\u7B80\u6D01\u51C6\u786E\uFF09
   - exampleSentence: \u82F1\u6587\u4F8B\u53E5\uFF08\u4E0E\u539F\u6587\u4E0D\u540C\u7684\u65B0\u4F8B\u53E5\uFF09
   - exampleTranslation: \u4F8B\u53E5\u4E2D\u6587\u7FFB\u8BD1
3. \u751F\u6210 2 \u9053\u7406\u89E3\u9898\uFF0C\u6BCF\u9898 4 \u4E2A\u9009\u9879\uFF0C\u8003\u5BDF\u5BF9\u539F\u6587\u7684\u7406\u89E3

\u8BF7\u4EE5 JSON \u683C\u5F0F\u8FD4\u56DE\uFF0C\u683C\u5F0F\u5982\u4E0B\uFF1A
{
  "translation": "\u4E2D\u6587\u7FFB\u8BD1",
  "vocabulary": [
    {
      "word": "shadow",
      "forms": "shadows,shadowed,shadowing",
      "phonetic": "/\u02C8\u0283\xE6do\u028A/",
      "meaning": "n. \u5F71\u5B50 v. \u8DDF\u8E2A",
      "exampleSentence": "The shadow of the tree fell across the lawn.",
      "exampleTranslation": "\u6811\u7684\u5F71\u5B50\u843D\u5728\u8349\u576A\u4E0A\u3002"
    }
  ],
  "questions": [
    {
      "question": "What is the main idea of the passage?",
      "options": ["A. ...", "B. ...", "C. ...", "D. ..."],
      "answer": "B. ..."
    }
  ]
}

\u8981\u6C42\uFF1A
- \u7FFB\u8BD1\u8981\u81EA\u7136\u6D41\u7545\uFF0C\u7B26\u5408\u4E2D\u6587\u8868\u8FBE\u4E60\u60EF
- \u8BCD\u6C47\u5E94\u9009\u62E9\u539F\u6587\u4E2D\u8F83\u6709\u5B66\u4E60\u4EF7\u503C\u7684\u8BCD\uFF0C\u6309\u51FA\u73B0\u987A\u5E8F\u6392\u5217
- \u97F3\u6807\u4F7F\u7528 IPA \u56FD\u9645\u97F3\u6807\u683C\u5F0F
- \u4F8B\u53E5\u8981\u7B80\u6D01\u3001\u5730\u9053\uFF0C\u80FD\u4F53\u73B0\u8BE5\u8BCD\u7684\u7528\u6CD5
- \u9898\u76EE\u9009\u9879\u524D\u7F00 A/B/C/D\uFF0Canswer \u5B57\u6BB5\u9700\u5305\u542B\u5B8C\u6574\u9009\u9879\u6587\u672C
- \u53EA\u8FD4\u56DE JSON\uFF0C\u4E0D\u8981\u8FD4\u56DE\u4EFB\u4F55\u5176\u4ED6\u5185\u5BB9`;
function validateVocabulary(raw) {
  if (!Array.isArray(raw)) return null;
  const result = [];
  for (const item of raw) {
    if (!item || typeof item !== "object") continue;
    const obj = item;
    const word = typeof obj.word === "string" ? obj.word.trim() : "";
    if (!word) continue;
    const meaning = typeof obj.meaning === "string" ? obj.meaning.trim() : "";
    if (!meaning) continue;
    const forms = typeof obj.forms === "string" && obj.forms.trim() ? obj.forms.trim() : null;
    const phonetic = typeof obj.phonetic === "string" && obj.phonetic.trim() ? obj.phonetic.trim() : null;
    const exampleSentence = typeof obj.exampleSentence === "string" && obj.exampleSentence.trim() ? obj.exampleSentence.trim() : null;
    const exampleTranslation = typeof obj.exampleTranslation === "string" && obj.exampleTranslation.trim() ? obj.exampleTranslation.trim() : null;
    result.push({
      word,
      forms,
      phonetic,
      meaning,
      exampleSentence,
      exampleTranslation
    });
  }
  if (result.length < MIN_VOCAB || result.length > MAX_VOCAB) return null;
  return result;
}
function validateQuestions(raw) {
  if (!Array.isArray(raw)) return null;
  const result = [];
  for (const item of raw) {
    if (!item || typeof item !== "object") continue;
    const obj = item;
    const question = typeof obj.question === "string" ? obj.question.trim() : "";
    if (!question) continue;
    const options = Array.isArray(obj.options) ? obj.options.filter((o) => typeof o === "string" && o.trim().length > 0) : [];
    if (options.length < 2) continue;
    const answer = typeof obj.answer === "string" ? obj.answer.trim() : "";
    if (!answer) continue;
    result.push({ question, options, answer });
  }
  if (result.length < MIN_QUESTIONS || result.length > MAX_QUESTIONS) return null;
  return result;
}
async function generateLearningContent(text) {
  var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j;
  const trimmed = text.trim();
  if (!trimmed) {
    return { success: false, error: "\u6587\u672C\u4E0D\u80FD\u4E3A\u7A7A" };
  }
  if (trimmed.length > MAX_TEXT_LENGTH) {
    return { success: false, error: `\u6587\u672C\u957F\u5EA6\u8D85\u8FC7\u9650\u5236\uFF08\u6700\u5927 ${MAX_TEXT_LENGTH} \u5B57\u7B26\uFF09` };
  }
  const config = useRuntimeConfig();
  const ds = config.deepseek;
  if (!(ds == null ? void 0 : ds.apiKey) || !(ds == null ? void 0 : ds.baseUrl) || !(ds == null ? void 0 : ds.model)) {
    logger.error("[aiContent] DeepSeek \u914D\u7F6E\u4E0D\u5B8C\u6574");
    return { success: false, error: "AI \u670D\u52A1\u914D\u7F6E\u7F3A\u5931" };
  }
  const url = `${ds.baseUrl.replace(/\/+$/, "")}/chat/completions`;
  let callStart = 0;
  try {
    callStart = Date.now();
    const resp = await serverFetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${ds.apiKey}`
      },
      body: JSON.stringify({
        model: ds.model,
        messages: [
          { role: "system", content: SYSTEM_PROMPT },
          { role: "user", content: trimmed }
        ],
        temperature: 0.3,
        max_tokens: MAX_TOKENS
      }),
      timeout: API_TIMEOUT,
      tag: "[aiContent]"
    });
    if (!resp.ok) {
      const body = await resp.text();
      logger.error(`[aiContent] API \u8FD4\u56DE ${resp.status}: ${body}`);
      void logCloudServiceCall({
        service: "deepseek",
        operation: "generateContent",
        success: false,
        durationMs: Date.now() - callStart,
        errorMessage: `HTTP ${resp.status}`
      });
      return { success: false, error: "AI \u670D\u52A1\u6682\u65F6\u4E0D\u53EF\u7528" };
    }
    const data = await resp.json();
    if (data == null ? void 0 : data.usage) {
      fileLog("ai", "info", "[aiContent] Token \u7528\u91CF", {
        promptTokens: data.usage.prompt_tokens,
        completionTokens: data.usage.completion_tokens,
        totalTokens: data.usage.total_tokens
      });
    }
    void logCloudServiceCall({
      service: "deepseek",
      operation: "generateContent",
      success: true,
      durationMs: Date.now() - callStart,
      promptTokens: (_b = (_a = data == null ? void 0 : data.usage) == null ? void 0 : _a.prompt_tokens) != null ? _b : null,
      completionTokens: (_d = (_c = data == null ? void 0 : data.usage) == null ? void 0 : _c.completion_tokens) != null ? _d : null,
      totalTokens: (_f = (_e = data == null ? void 0 : data.usage) == null ? void 0 : _e.total_tokens) != null ? _f : null
    });
    const content = (_j = (_i = (_h = (_g = data == null ? void 0 : data.choices) == null ? void 0 : _g[0]) == null ? void 0 : _h.message) == null ? void 0 : _i.content) != null ? _j : "";
    if (!content) {
      logger.error("[aiContent] API \u8FD4\u56DE\u7A7A\u5185\u5BB9");
      return { success: false, error: "AI \u672A\u8FD4\u56DE\u6709\u6548\u5185\u5BB9" };
    }
    const cleaned = content.replace(/```json?\n?/g, "").replace(/```/g, "").trim();
    let parsed;
    try {
      parsed = JSON.parse(cleaned);
    } catch {
      logger.error("[aiContent] JSON \u89E3\u6790\u5931\u8D25:", cleaned.substring(0, 200));
      return { success: false, error: "AI \u751F\u6210\u5185\u5BB9\u89E3\u6790\u5931\u8D25" };
    }
    const translation = typeof parsed.translation === "string" ? parsed.translation.trim() : "";
    if (!translation) {
      logger.error("[aiContent] \u7FFB\u8BD1\u5B57\u6BB5\u7F3A\u5931\u6216\u4E3A\u7A7A");
      return { success: false, error: "AI \u751F\u6210\u5185\u5BB9\u4E0D\u5B8C\u6574\uFF08\u7F3A\u5C11\u7FFB\u8BD1\uFF09" };
    }
    const vocabulary = validateVocabulary(parsed.vocabulary);
    if (!vocabulary) {
      logger.error("[aiContent] \u8BCD\u6C47\u6821\u9A8C\u5931\u8D25");
      return { success: false, error: "AI \u751F\u6210\u5185\u5BB9\u4E0D\u5B8C\u6574\uFF08\u8BCD\u6C47\u683C\u5F0F\u9519\u8BEF\uFF09" };
    }
    const questions = validateQuestions(parsed.questions);
    if (!questions) {
      logger.error("[aiContent] \u9898\u76EE\u6821\u9A8C\u5931\u8D25");
      return { success: false, error: "AI \u751F\u6210\u5185\u5BB9\u4E0D\u5B8C\u6574\uFF08\u9898\u76EE\u683C\u5F0F\u9519\u8BEF\uFF09" };
    }
    logger.info(`[aiContent] \u5B66\u4E60\u5185\u5BB9\u751F\u6210\u6210\u529F (\u8BCD\u6C47${vocabulary.length}/\u9898\u76EE${questions.length})`);
    fileLog("ai", "info", "[aiContent] \u5B66\u4E60\u5185\u5BB9\u751F\u6210\u6210\u529F", {
      textLength: trimmed.length,
      vocabCount: vocabulary.length,
      questionCount: questions.length
    });
    return {
      success: true,
      translation,
      vocabulary,
      questions
    };
  } catch (err) {
    const errMsg = err instanceof Error ? err.message : String(err);
    void logCloudServiceCall({
      service: "deepseek",
      operation: "generateContent",
      success: false,
      durationMs: callStart ? Date.now() - callStart : 0,
      errorMessage: errMsg.substring(0, 500)
    });
    if (errMsg.includes("abort") || errMsg.includes("timeout") || errMsg.includes("Timeout")) {
      logger.error("[aiContent] \u751F\u6210\u8D85\u65F6");
      fileLogError("ai", "[aiContent] \u5B66\u4E60\u5185\u5BB9\u751F\u6210\u8D85\u65F6", errMsg);
      return { success: false, error: "AI \u751F\u6210\u8D85\u65F6" };
    }
    logger.error("[aiContent] \u751F\u6210\u5931\u8D25:", errMsg);
    fileLogError("ai", "[aiContent] \u5B66\u4E60\u5185\u5BB9\u751F\u6210\u5931\u8D25", errMsg);
    return { success: false, error: `AI \u5185\u5BB9\u751F\u6210\u5931\u8D25: ${errMsg}` };
  }
}
const TITLE_SYSTEM_PROMPT = `\u4F60\u662F\u4E00\u4F4D\u82F1\u8BED\u6559\u80B2\u5185\u5BB9\u7F16\u8F91\u3002\u8BF7\u6839\u636E\u4EE5\u4E0B\u82F1\u6587\u5B66\u4E60\u6750\u6599\uFF0C\u751F\u6210\u4E00\u4E2A\u7B80\u6D01\u3001\u51C6\u786E\u3001\u5438\u5F15\u4EBA\u7684\u4E2D\u6587\u6807\u9898\uFF08\u4E0D\u8D85\u8FC7 20 \u4E2A\u5B57\uFF09\u3002\u6807\u9898\u5E94\u6982\u62EC\u6750\u6599\u4E3B\u9898\uFF0C\u9002\u5408\u5B66\u4E60\u8005\u5FEB\u901F\u8BC6\u522B\u5185\u5BB9\u3002\u53EA\u8FD4\u56DE\u6807\u9898\u6587\u672C\uFF0C\u4E0D\u8981\u8FD4\u56DE\u4EFB\u4F55\u5176\u4ED6\u5185\u5BB9\u3002`;
const TITLE_API_TIMEOUT = 1e4;
const TITLE_MAX_TOKENS = 100;
async function generateTitle(text) {
  var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j;
  const trimmed = text.trim();
  if (!trimmed) {
    return { success: false, error: "\u6587\u672C\u4E0D\u80FD\u4E3A\u7A7A" };
  }
  const config = useRuntimeConfig();
  const ds = config.deepseek;
  if (!(ds == null ? void 0 : ds.apiKey) || !(ds == null ? void 0 : ds.baseUrl) || !(ds == null ? void 0 : ds.model)) {
    logger.error("[aiContent] DeepSeek \u914D\u7F6E\u4E0D\u5B8C\u6574");
    return { success: false, error: "AI \u670D\u52A1\u914D\u7F6E\u7F3A\u5931" };
  }
  const url = `${ds.baseUrl.replace(/\/+$/, "")}/chat/completions`;
  let callStart = 0;
  try {
    callStart = Date.now();
    const resp = await serverFetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${ds.apiKey}`
      },
      body: JSON.stringify({
        model: ds.model,
        messages: [
          { role: "system", content: TITLE_SYSTEM_PROMPT },
          { role: "user", content: trimmed.substring(0, 500) }
        ],
        temperature: 0.3,
        max_tokens: TITLE_MAX_TOKENS
      }),
      timeout: TITLE_API_TIMEOUT,
      tag: "[aiContent]"
    });
    if (!resp.ok) {
      const body = await resp.text();
      logger.error(`[aiContent] \u6807\u9898\u751F\u6210 API \u8FD4\u56DE ${resp.status}: ${body}`);
      void logCloudServiceCall({
        service: "deepseek",
        operation: "generateTitle",
        success: false,
        durationMs: Date.now() - callStart,
        errorMessage: `HTTP ${resp.status}`
      });
      return { success: false, error: "AI \u670D\u52A1\u6682\u65F6\u4E0D\u53EF\u7528" };
    }
    const data = await resp.json();
    if (data == null ? void 0 : data.usage) {
      fileLog("ai", "info", "[aiContent:title] Token \u7528\u91CF", {
        promptTokens: data.usage.prompt_tokens,
        completionTokens: data.usage.completion_tokens,
        totalTokens: data.usage.total_tokens
      });
    }
    void logCloudServiceCall({
      service: "deepseek",
      operation: "generateTitle",
      success: true,
      durationMs: Date.now() - callStart,
      promptTokens: (_b = (_a = data == null ? void 0 : data.usage) == null ? void 0 : _a.prompt_tokens) != null ? _b : null,
      completionTokens: (_d = (_c = data == null ? void 0 : data.usage) == null ? void 0 : _c.completion_tokens) != null ? _d : null,
      totalTokens: (_f = (_e = data == null ? void 0 : data.usage) == null ? void 0 : _e.total_tokens) != null ? _f : null
    });
    let title = (_j = (_i = (_h = (_g = data == null ? void 0 : data.choices) == null ? void 0 : _g[0]) == null ? void 0 : _h.message) == null ? void 0 : _i.content) != null ? _j : "";
    if (!title) {
      logger.error("[aiContent] \u6807\u9898\u751F\u6210\u8FD4\u56DE\u7A7A\u5185\u5BB9");
      return { success: false, error: "AI \u672A\u8FD4\u56DE\u6709\u6548\u5185\u5BB9" };
    }
    title = title.replace(/^["']|["']$/g, "").replace(/\n/g, " ").trim();
    if (!title) {
      return { success: false, error: "AI \u8FD4\u56DE\u6807\u9898\u4E3A\u7A7A" };
    }
    logger.info(`[aiContent] \u6807\u9898\u751F\u6210\u6210\u529F: ${title}`);
    fileLog("ai", "info", "[aiContent] \u6807\u9898\u751F\u6210\u6210\u529F", { title });
    return { success: true, title };
  } catch (err) {
    const errMsg = err instanceof Error ? err.message : String(err);
    void logCloudServiceCall({
      service: "deepseek",
      operation: "generateTitle",
      success: false,
      durationMs: callStart ? Date.now() - callStart : 0,
      errorMessage: errMsg.substring(0, 500)
    });
    if (errMsg.includes("abort") || errMsg.includes("timeout") || errMsg.includes("Timeout")) {
      logger.error("[aiContent] \u6807\u9898\u751F\u6210\u8D85\u65F6");
      fileLogError("ai", "[aiContent] \u6807\u9898\u751F\u6210\u8D85\u65F6", errMsg);
      return { success: false, error: "AI \u751F\u6210\u8D85\u65F6" };
    }
    logger.error("[aiContent] \u6807\u9898\u751F\u6210\u5931\u8D25:", errMsg);
    fileLogError("ai", "[aiContent] \u6807\u9898\u751F\u6210\u5931\u8D25", errMsg);
    return { success: false, error: `\u6807\u9898\u751F\u6210\u5931\u8D25: ${errMsg}` };
  }
}

const WSS_BASE = "wss://speech.platform.bing.com/consumer/speech/synthesize/readaloud/edge/v1";
const TRUSTED_CLIENT_TOKEN = "6A5AA1D4EAFF4E9FB37E23D68491D6F4";
const CHROMIUM_VERSION = "143.0.3650.75";
const DEFAULT_VOICE = "en-US-AriaNeural";
const CONNECT_TIMEOUT = 3e4;
const MAX_CHUNK_BYTES = 4096;
const WIN_EPOCH_OFFSET = 11644473600;
function generateSecMsGec() {
  const ticks = Date.now() / 1e3;
  const adjustedTicks = ticks + WIN_EPOCH_OFFSET;
  const flooredTicks = adjustedTicks - adjustedTicks % 300;
  const nanos100 = Math.floor(flooredTicks * 1e9 / 100);
  const payload = `${nanos100}${TRUSTED_CLIENT_TOKEN}`;
  return crypto.createHash("sha256").update(payload, "ascii").digest("hex").toUpperCase();
}
function toFullVoiceName(shortName) {
  const match = /^([a-z]{2}-[A-Z]{2})-(.+)$/.exec(shortName);
  if (!match) return shortName;
  return `Microsoft Server Speech Text to Speech Voice (${match[1]}, ${match[2]})`;
}
function escapeXml(text) {
  return text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");
}
function sanitizeText(text) {
  const sanitized = text.replace(/[\p{Cc}]/gu, (char) => {
    return char === "	" || char === "\n" || char === "\r" ? char : " ";
  });
  return escapeXml(sanitized);
}
function splitText(text, maxBytes = MAX_CHUNK_BYTES) {
  if (Buffer.byteLength(text, "utf-8") <= maxBytes) {
    return [text];
  }
  const chunks = [];
  let remaining = text;
  while (remaining.length > 0) {
    if (Buffer.byteLength(remaining, "utf-8") <= maxBytes) {
      chunks.push(remaining);
      break;
    }
    let splitPos = maxBytes;
    while (splitPos > 0) {
      const byteLen = Buffer.byteLength(remaining.slice(0, splitPos), "utf-8");
      if (byteLen <= maxBytes) break;
      splitPos--;
    }
    let bestPos = splitPos;
    for (let i = splitPos; i >= Math.max(splitPos - 200, 0); i--) {
      const ch = remaining[i];
      if (ch === "\n" || ch === " ") {
        bestPos = i + 1;
        break;
      }
    }
    const chunk = remaining.slice(0, bestPos);
    const lastAmp = chunk.lastIndexOf("&");
    const lastSemi = chunk.lastIndexOf(";");
    if (lastAmp !== -1 && lastSemi < lastAmp) {
      bestPos = lastAmp;
    }
    chunks.push(remaining.slice(0, bestPos));
    remaining = remaining.slice(bestPos);
  }
  return chunks;
}
function buildSsml(text, fullVoice) {
  return `<speak version='1.0' xmlns='http://www.w3.org/2001/10/synthesis' xml:lang='en-US'>
  <voice name='${fullVoice}'>
    <prosody pitch='+0Hz' rate='+0%' volume='+0%'>
      ${text}
    </prosody>
  </voice>
</speak>`;
}
function toEdgeTimestamp() {
  const d = /* @__PURE__ */ new Date();
  const days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  const months = [
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
    "Dec"
  ];
  const pad = (n) => String(n).padStart(2, "0");
  return `${days[d.getUTCDay()]} ${months[d.getUTCMonth()]} ${d.getUTCDate()} ${d.getUTCFullYear()} ${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}:${pad(d.getUTCSeconds())} GMT+0000 (Coordinated Universal Time)`;
}
function buildConfigMessage() {
  const timestamp = toEdgeTimestamp();
  const headers = [
    `X-Timestamp:${timestamp}\r
`,
    "Content-Type:application/json; charset=utf-8\r\n",
    "Path:speech.config\r\n",
    "\r\n",
    '{"context":{"synthesis":{"audio":{"metadataoptions":{"sentenceBoundaryEnabled":"true","wordBoundaryEnabled":"false"},"outputFormat":"audio-24khz-48kbitrate-mono-mp3"}}}}\r\n'
  ];
  return headers.join("");
}
function buildSsmlMessage(requestId, ssml) {
  const timestamp = toEdgeTimestamp();
  const headers = [
    `X-RequestId:${requestId}\r
`,
    "Content-Type:application/ssml+xml\r\n",
    `X-Timestamp:${timestamp}Z\r
`,
    "Path:ssml\r\n",
    "\r\n",
    `${ssml}\r
`
  ];
  return headers.join("");
}
function generateWsUrl() {
  const connectionId = crypto.randomUUID().replace(/-/g, "");
  const secMsGec = generateSecMsGec();
  return [
    `${WSS_BASE}?TrustedClientToken=${TRUSTED_CLIENT_TOKEN}`,
    `&ConnectionId=${connectionId}`,
    `&Sec-MS-GEC=${secMsGec}`,
    `&Sec-MS-GEC-Version=1-${CHROMIUM_VERSION}`
  ].join("");
}
function generateRequestId() {
  return crypto.randomUUID().replace(/-/g, "");
}
function parseMessagePath(message) {
  const match = /^Path:(.+?)(\r\n|$)/m.exec(message);
  if (!match || !match[1]) return null;
  return match[1].trim();
}
function extractAudioData(data) {
  if (data.length < 2) return null;
  const headerLength = data.readUInt16BE(0);
  const payloadStart = headerLength + 2;
  if (data.length <= payloadStart) {
    return null;
  }
  return data.slice(payloadStart);
}
async function textToSpeech(text, voice = DEFAULT_VOICE) {
  const trimmed = text.trim();
  if (!trimmed) {
    return { success: false, error: "\u6587\u672C\u4E0D\u80FD\u4E3A\u7A7A" };
  }
  const start = Date.now();
  const fullVoice = toFullVoiceName(voice);
  const sanitized = sanitizeText(trimmed);
  const chunks = splitText(sanitized);
  const url = generateWsUrl();
  const wsHeaders = {
    Pragma: "no-cache",
    "Cache-Control": "no-cache",
    Origin: "chrome-extension://jdiccldimpdaibmpdkjnbmckianbfold",
    "User-Agent": `Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${CHROMIUM_VERSION} Safari/537.36 Edg/${CHROMIUM_VERSION}`,
    "Accept-Language": "en-US,en;q=0.9"
  };
  let ws = null;
  const audioChunks = [];
  try {
    ws = await new Promise((resolve, reject) => {
      const socket = new WebSocket(url, { headers: wsHeaders });
      const timeout = setTimeout(() => {
        socket.terminate();
        reject(new Error("\u8FDE\u63A5\u8D85\u65F6"));
      }, CONNECT_TIMEOUT);
      socket.on("open", () => {
        clearTimeout(timeout);
        resolve(socket);
      });
      socket.on("error", (err) => {
        clearTimeout(timeout);
        reject(err);
      });
    });
    ws.send(buildConfigMessage());
    await new Promise((resolve) => setTimeout(resolve, 100));
    for (let i = 0; i < chunks.length; i++) {
      const requestId = generateRequestId();
      const chunk = chunks[i];
      if (!chunk) break;
      const ssml = buildSsml(chunk, fullVoice);
      const ssmlMessage = buildSsmlMessage(requestId, ssml);
      await new Promise((resolve, reject) => {
        const timeout = setTimeout(() => {
          reject(new Error("TTS \u8F6C\u6362\u8D85\u65F6"));
        }, CONNECT_TIMEOUT);
        let turnEnded = false;
        const onMessage = (data, isBinary) => {
          if (!isBinary) {
            const text2 = data.toString("utf-8");
            const path = parseMessagePath(text2);
            if (path === "turn.end") {
              turnEnded = true;
              clearTimeout(timeout);
              ws.off("message", onMessage);
              ws.off("error", onError);
              ws.off("close", onClose);
              resolve();
            }
          } else {
            const audioData = extractAudioData(data);
            if (audioData && audioData.length > 0) {
              audioChunks.push(audioData);
            }
          }
        };
        const onError = (err) => {
          clearTimeout(timeout);
          ws.off("message", onMessage);
          ws.off("error", onError);
          ws.off("close", onClose);
          reject(err);
        };
        const onClose = () => {
          clearTimeout(timeout);
          ws.off("message", onMessage);
          ws.off("error", onError);
          ws.off("close", onClose);
          if (!turnEnded) {
            reject(new Error("WebSocket \u8FDE\u63A5\u610F\u5916\u5173\u95ED"));
          }
        };
        ws.on("message", onMessage);
        ws.on("error", onError);
        ws.on("close", onClose);
        ws.send(ssmlMessage);
      });
    }
    if (audioChunks.length === 0) {
      logger.error("[tts] \u8F6C\u6362\u5931\u8D25: \u672A\u8FD4\u56DE\u97F3\u9891\u6570\u636E");
      fileLogError("tts", "[tts] \u8F6C\u6362\u5931\u8D25: \u672A\u8FD4\u56DE\u97F3\u9891\u6570\u636E", { textLength: trimmed.length });
      return { success: false, error: "TTS \u8F6C\u6362\u672A\u8FD4\u56DE\u97F3\u9891\u6570\u636E" };
    }
    const audio = Buffer.concat(audioChunks);
    const ms = Date.now() - start;
    logger.info(`[tts] \u8F6C\u6362\u6210\u529F (${ms}ms, ${audio.length}B)`);
    fileLog("tts", "info", "[tts] \u8F6C\u6362\u6210\u529F", {
      ms,
      audioBytes: audio.length,
      textLength: trimmed.length
    });
    void logCloudServiceCall({
      service: "tts",
      operation: "textToSpeech",
      success: true,
      durationMs: ms
    });
    return { success: true, audio };
  } catch (err) {
    const errMsg = err instanceof Error ? err.message : String(err);
    const ms = Date.now() - start;
    logger.error("[tts] \u8F6C\u6362\u5931\u8D25:", errMsg);
    fileLogError("tts", `[tts] \u8F6C\u6362\u5931\u8D25 (${ms}ms)`, errMsg, { textLength: trimmed.length });
    void logCloudServiceCall({
      service: "tts",
      operation: "textToSpeech",
      success: false,
      durationMs: ms,
      errorMessage: errMsg.substring(0, 500)
    });
    if (errMsg.includes("403") || errMsg.includes("ECONNREFUSED") || errMsg.includes("\u8FDE\u63A5\u8D85\u65F6")) {
      return { success: false, error: "TTS \u670D\u52A1\u8FDE\u63A5\u5931\u8D25\uFF0C\u53EF\u80FD\u9700\u8981\u4EE3\u7406" };
    }
    if (errMsg.includes("\u8D85\u65F6")) {
      return { success: false, error: "TTS \u8F6C\u6362\u8D85\u65F6" };
    }
    return { success: false, error: `TTS \u8F6C\u6362\u5931\u8D25: ${errMsg}` };
  } finally {
    if (ws && (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING)) {
      ws.close();
    }
  }
}

async function extractAudioMeta(audioBuffer) {
  var _a;
  try {
    const metadata = await parseBuffer(audioBuffer, { mimeType: "audio/mpeg" });
    const seconds = (_a = metadata.format.duration) != null ? _a : null;
    if (seconds === null) return null;
    return {
      duration: Math.round(seconds * 100) / 100,
      size: audioBuffer.length
    };
  } catch (err) {
    logger.error("[audioMeta] \u5143\u6570\u636E\u63D0\u53D6\u5931\u8D25:", err instanceof Error ? err.message : err);
    return null;
  }
}

export { generateTitle as a, extractAudioMeta as e, generateLearningContent as g, textToSpeech as t };
//# sourceMappingURL=audioMeta.mjs.map
