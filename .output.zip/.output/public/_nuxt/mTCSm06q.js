import{q as e,an as n}from"./By0mwfYZ.js";const a=async t=>{const s=t?`?level=${t}`:"";return e(`${n}${s}`,{method:"GET"})};export{a as g};
