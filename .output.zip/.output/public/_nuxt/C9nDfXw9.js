import{I as n}from"./CCXvotB9.js";function s(){if(!arguments.length)return[];var r=arguments[0];return n(r)?r:[r]}function u(r,a,t=.03){return r-a>t}export{s as c,u as i};
