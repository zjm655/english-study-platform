import{d as a,am as e}from"./By0mwfYZ.js";const s=a({__name:"index",setup(n){return e("/admin/cloud/oss",{}),()=>{}}});export{s as default};
