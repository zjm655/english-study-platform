import{d as e,bh as s}from"./By0mwfYZ.js";const a=e({__name:"[...slug]",setup(o){throw s({statusCode:404,message:"您访问的页面不存在"})}});export{a as default};
