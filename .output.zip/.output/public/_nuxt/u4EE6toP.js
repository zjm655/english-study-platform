import{q as s,b4 as r}from"./By0mwfYZ.js";const o=async()=>s(r,{method:"GET"}),a=async e=>s(r,{method:"PUT",body:e});export{o as g,a as p};
